-- Mar 24, 2010 10:31:45 PM COT
-- BF1761985_Val Rule AD_Table Client+Org Access is incorrect defined
UPDATE AD_Val_Rule SET Code='AD_Table.AccessLevel IN (''2'',''3'',''6'',''7'') AND AD_Table.IsView=''N''',Updated=TO_DATE('2010-03-24 22:31:45','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Val_Rule_ID=256
;

-- Mar 24, 2010 10:32:12 PM COT
UPDATE AD_Tab SET TabLevel=1,Updated=TO_DATE('2010-03-24 22:32:12','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Tab_ID=776
;

