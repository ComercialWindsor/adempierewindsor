-- Dec 1, 2009 7:55:39 PM CET
-- FR[2907059] - Add System Configurator to Favourites
-- https://sourceforge.net/tracker/?func=detail&aid=2907059&group_id=176962&atid=883808
INSERT INTO AD_TreeBar (AD_Tree_ID,AD_User_ID,Node_ID, AD_Client_ID,AD_Org_ID, IsActive,Created,CreatedBy,Updated,UpdatedBy)VALUES (10,100,50008,0,0,'Y',SysDate,100,SysDate,100)
;

