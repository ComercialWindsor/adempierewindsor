-- Apr 18, 2010 10:38:04 AM COT
-- FR2988993_Displaying 1 instead of 99999
INSERT INTO AD_SysConfig (AD_Client_ID,AD_Org_ID,AD_SysConfig_ID,ConfigurationLevel,Created,CreatedBy,Description,EntityType,IsActive,Name,Updated,UpdatedBy,Value) VALUES (0,0,50043,'C',TO_DATE('2010-04-18 10:38:03','YYYY-MM-DD HH24:MI:SS'),100,'Quantity to show for services in InfoProduct window','D','Y','QTY_TO_SHOW_FOR_SERVICES',TO_DATE('2010-04-18 10:38:03','YYYY-MM-DD HH24:MI:SS'),100,'99999')
;

