-- Apr 16, 2010 11:03:57 PM CEST
-- BF [2872924] - Window Customization tabs
-- https://sourceforge.net/tracker/?func=detail&atid=879335&aid=2872924&group_id=176962
UPDATE AD_Window SET IsBetaFunctionality='Y',Updated=TO_DATE('2010-04-16 23:03:57','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Window_ID=229
;

-- Apr 16, 2010 11:05:17 PM CEST
-- BF [2872924] - Window Customization tabs
-- https://sourceforge.net/tracker/?func=detail&atid=879335&aid=2872924&group_id=176962
UPDATE AD_Table SET AccessLevel='6',Updated=TO_DATE('2010-04-16 23:05:17','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Table_ID=466
;

-- Apr 16, 2010 11:05:50 PM CEST
-- BF [2872924] - Window Customization tabs
-- https://sourceforge.net/tracker/?func=detail&atid=879335&aid=2872924&group_id=176962
UPDATE AD_Table SET AccessLevel='6',Updated=TO_DATE('2010-04-16 23:05:50','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Table_ID=464
;

