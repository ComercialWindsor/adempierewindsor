-- Dec 10, 2009 9:05:19 PM COT
-- 2904134_Cannot define the print format for a check
UPDATE AD_Ref_List SET IsActive='Y',Updated=TO_DATE('2009-12-10 21:05:19','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Ref_List_ID=332
;

-- Dec 10, 2009 9:05:37 PM COT
UPDATE AD_Ref_List SET IsActive='Y',Updated=TO_DATE('2009-12-10 21:05:37','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Ref_List_ID=652
;

-- Dec 10, 2009 9:05:48 PM COT
UPDATE AD_Ref_List SET IsActive='Y',Updated=TO_DATE('2009-12-10 21:05:48','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Ref_List_ID=333
;

-- Dec 10, 2009 9:06:15 PM COT
UPDATE AD_Ref_List SET IsActive='Y',Updated=TO_DATE('2009-12-10 21:06:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Ref_List_ID=337
;

-- Dec 10, 2009 9:06:27 PM COT
UPDATE AD_Ref_List SET IsActive='Y',Updated=TO_DATE('2009-12-10 21:06:27','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Ref_List_ID=335
;

