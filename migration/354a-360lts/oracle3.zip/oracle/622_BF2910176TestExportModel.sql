-- Dec 1, 2009 10:41:32 PM CST
-- Replication Stabilization
UPDATE AD_Process SET IsActive='Y', IsBetaFunctionality='N',Updated=TO_DATE('2009-12-01 22:41:32','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Process_ID=53085
;

-- Dec 1, 2009 10:41:33 PM CST
-- Replication Stabilization
UPDATE AD_Menu SET Description='Create multiple Export Format based in a Window', IsActive='Y', Name='Export Format Generator',Updated=TO_DATE('2009-12-01 22:41:33','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Menu_ID=53125
;

-- Dec 1, 2009 10:42:43 PM CST
-- Replication Stabilization
UPDATE AD_Menu SET IsActive='Y',Updated=TO_DATE('2009-12-01 22:42:43','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Menu_ID=53130
;

-- Dec 1, 2009 10:43:39 PM CST
-- Replication Stabilization
UPDATE AD_Process SET IsActive='Y',Updated=TO_DATE('2009-12-01 22:43:39','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Process_ID=53089
;

-- Dec 1, 2009 10:44:32 PM CST
-- Replication Stabilization
UPDATE AD_Process SET Classname='org.adempiere.process.rpl.imp.ModelImporter',Updated=TO_DATE('2009-12-01 22:44:32','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Process_ID=53074
;

-- Dec 1, 2009 10:44:50 PM CST
-- Replication Stabilization
UPDATE AD_Window SET IsBetaFunctionality='N',Updated=TO_DATE('2009-12-01 22:44:50','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Window_ID=53025
;

-- Dec 1, 2009 10:44:58 PM CST
-- Replication Stabilization
UPDATE AD_Window SET IsSOTrx='N',Updated=TO_DATE('2009-12-01 22:44:58','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Window_ID=53025
;

-- Dec 1, 2009 10:45:26 PM CST
-- Replication Stabilization
UPDATE AD_Field SET IsActive='Y',Updated=TO_DATE('2009-12-01 22:45:26','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=55417
;

-- Dec 1, 2009 10:58:44 PM CST
-- Replication Stabilization
UPDATE AD_Field SET SeqNo=120,IsDisplayed='Y' WHERE AD_Field_ID=55417
;

-- Dec 1, 2009 10:58:44 PM CST
-- Replication Stabilization
UPDATE AD_Field SET SeqNo=130,IsDisplayed='Y' WHERE AD_Field_ID=54570
;

-- Dec 1, 2009 10:58:51 PM CST
-- Replication Stabilization
UPDATE AD_Field SET Included_Tab_ID=53086,Updated=TO_DATE('2009-12-01 22:58:51','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=54570
;

-- Dec 1, 2009 10:59:21 PM CST
-- Replication Stabilization
UPDATE AD_Tab SET IsSingleRow='N',Updated=TO_DATE('2009-12-01 22:59:21','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Tab_ID=53086
;

