-- Nov 26, 2009 11:54:58 AM COT
-- FR2880682-Moved Window Inventory Move
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=167
;

-- Nov 26, 2009 11:54:58 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=357
;

-- Nov 26, 2009 11:54:58 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=229
;

-- Nov 26, 2009 11:54:58 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=412
;

-- Nov 26, 2009 11:54:58 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=256
;

-- Nov 26, 2009 11:54:58 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=197
;

-- Nov 26, 2009 11:54:58 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=477
;

-- Nov 26, 2009 11:54:58 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=181
;

-- Nov 26, 2009 11:54:58 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=8, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=179
;

-- Nov 26, 2009 11:54:58 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=9, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=503
;

-- Nov 26, 2009 11:54:58 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=10, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=196
;

-- Nov 26, 2009 11:54:58 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=11, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=228
;

-- Nov 26, 2009 11:54:58 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=12, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=479
;

-- Nov 26, 2009 11:54:58 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=13, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=482
;

-- Nov 26, 2009 11:54:58 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=14, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=481
;

-- Nov 26, 2009 11:54:58 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=15, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=411
;

-- Nov 26, 2009 11:54:58 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=16, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=537
;

-- Nov 26, 2009 11:54:58 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=17, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=311
;

-- Nov 26, 2009 11:54:58 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=18, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=292
;

-- Nov 26, 2009 11:54:58 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=19, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=504
;

-- Nov 26, 2009 11:54:58 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=20, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=515
;

-- Nov 26, 2009 11:54:58 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=21, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=545
;

-- Nov 26, 2009 11:56:14 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=268
;

-- Nov 26, 2009 11:56:14 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=125
;

-- Nov 26, 2009 11:56:14 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=422
;

-- Nov 26, 2009 11:56:14 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=107
;

-- Nov 26, 2009 11:56:14 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=130
;

-- Nov 26, 2009 11:56:14 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=188
;

-- Nov 26, 2009 11:56:14 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=227
;

-- Nov 26, 2009 11:56:14 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=381
;

-- Nov 26, 2009 11:56:14 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=8, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=126
;

-- Nov 26, 2009 11:56:14 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=9, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=421
;

-- Nov 26, 2009 11:56:14 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=10, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=534
;

-- Nov 26, 2009 11:56:14 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=11, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53024
;

-- Nov 26, 2009 11:56:14 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=12, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=267
;

-- Nov 26, 2009 11:56:14 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=13, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=490
;

-- Nov 26, 2009 11:56:14 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=14, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=132
;

-- Nov 26, 2009 11:56:14 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=15, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=310
;

-- Nov 26, 2009 11:56:14 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=16, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=128
;

-- Nov 26, 2009 11:56:14 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=17, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=585
;

-- Nov 26, 2009 11:56:14 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=18, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=187
;

-- Nov 26, 2009 11:56:14 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=19, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53210
;

-- Nov 26, 2009 11:56:14 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=20, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53211
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=167
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=357
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=229
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=412
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=256
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=197
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=477
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=181
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=8, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=179
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=9, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=503
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=10, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=196
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=11, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=228
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=12, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=479
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=13, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=482
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=14, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=481
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=15, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53028
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=16, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=411
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=17, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=537
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=18, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=311
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=19, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=292
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=20, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=504
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=21, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=515
;

-- Nov 26, 2009 11:57:33 AM COT
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=22, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=545
;

