-- Apr 19, 2010 5:37:09 PM COT
-- 2987531_Cannot search on Posted field
UPDATE AD_Column SET AD_Reference_Value_ID=234,Updated=TO_DATE('2010-04-19 17:37:09','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=56347
;

-- Apr 19, 2010 5:43:13 PM COT
UPDATE AD_Column SET AD_Reference_ID=28, AD_Reference_Value_ID=234,Updated=TO_DATE('2010-04-19 17:43:13','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=57934
;

-- Apr 19, 2010 5:44:04 PM COT
UPDATE AD_Column SET AD_Reference_ID=17, AD_Reference_Value_ID=234,Updated=TO_DATE('2010-04-19 17:44:04','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=58179
;

