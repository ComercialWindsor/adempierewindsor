-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=167
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=357
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=229
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=412
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=256
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=197
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=477
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=179
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=8, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=503
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=9, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=196
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=10, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=228
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=11, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=479
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=12, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=482
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=13, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=481
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=14, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=411
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=15, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53253
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=16, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=537
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=17, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=311
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=18, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=292
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=19, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=504
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=20, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=515
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=357, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=545
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=357, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=355
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=357, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=354
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=357, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=359
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=357, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=353
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=357, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=356
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=357, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=358
;

-- Dec 1, 2009 6:24:20 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=357, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=565
;

-- Dec 1, 2009 6:24:30 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=357, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=355
;

-- Dec 1, 2009 6:24:30 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=357, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=354
;

-- Dec 1, 2009 6:24:30 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=357, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=359
;

-- Dec 1, 2009 6:24:30 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=357, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=353
;

-- Dec 1, 2009 6:24:30 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=357, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=545
;

-- Dec 1, 2009 6:24:30 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=357, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=356
;

-- Dec 1, 2009 6:24:30 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=357, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=358
;

-- Dec 1, 2009 6:24:30 PM CET
-- FR [2907017] - Move ASI window to Material Management-->Product Attribu
UPDATE AD_TreeNodeMM SET Parent_ID=357, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=565
;

