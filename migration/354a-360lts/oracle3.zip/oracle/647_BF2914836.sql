-- Dec 15, 2009 5:46:57 PM COT
-- 2914836_Correct Reference for AmountTendered AmountRefunded
UPDATE AD_Column SET AD_Reference_ID=12,Updated=TO_DATE('2009-12-15 17:46:57','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=52065
;

-- Dec 15, 2009 5:47:03 PM COT
UPDATE AD_Column SET AD_Reference_ID=12,Updated=TO_DATE('2009-12-15 17:47:03','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=52064
;

