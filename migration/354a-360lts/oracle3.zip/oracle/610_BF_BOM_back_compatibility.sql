SET SQLBLANKLINES ON
SET DEFINE OFF

-- Nov 26, 2009 11:22:12 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53023
;

-- Nov 26, 2009 11:22:12 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53025
;

-- Nov 26, 2009 11:22:12 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53026
;

-- Nov 26, 2009 11:22:12 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53027
;

-- Nov 26, 2009 11:22:12 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=426
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=167
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=357
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=229
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=412
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=256
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=197
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=477
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=181
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=8, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=179
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=9, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=503
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=10, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=196
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=11, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=228
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=12, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=479
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=13, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=482
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=14, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=481
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=15, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=426
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=16, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53028
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=17, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=411
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=18, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=537
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=19, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=311
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=20, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=292
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=21, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=504
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=22, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=515
;

-- Nov 26, 2009 11:22:36 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=183, SeqNo=23, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=545
;

-- Nov 26, 2009 11:22:45 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53015
;

-- Nov 26, 2009 11:22:45 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53016
;

-- Nov 26, 2009 11:22:45 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53028
;

-- Nov 26, 2009 11:22:45 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53029
;

-- Nov 26, 2009 11:22:45 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53052
;

-- Nov 26, 2009 11:22:45 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53066
;

-- Nov 26, 2009 11:22:45 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53071
;

-- Nov 26, 2009 11:22:45 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53074
;

-- Nov 26, 2009 11:23:23 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53015
;

-- Nov 26, 2009 11:23:23 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53016
;

-- Nov 26, 2009 11:23:23 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53028
;

-- Nov 26, 2009 11:23:23 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53028
;

-- Nov 26, 2009 11:23:23 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53029
;

-- Nov 26, 2009 11:23:23 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53052
;

-- Nov 26, 2009 11:23:23 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53066
;

-- Nov 26, 2009 11:23:23 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53071
;

-- Nov 26, 2009 11:23:23 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=8, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53074
;

-- Nov 26, 2009 11:23:27 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53015
;

-- Nov 26, 2009 11:23:27 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53016
;

-- Nov 26, 2009 11:23:27 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53028
;

-- Nov 26, 2009 11:23:27 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53028
;

-- Nov 26, 2009 11:23:27 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53029
;

-- Nov 26, 2009 11:23:27 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53052
;

-- Nov 26, 2009 11:23:27 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53066
;

-- Nov 26, 2009 11:23:27 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53071
;

-- Nov 26, 2009 11:23:27 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53014, SeqNo=8, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53074
;

-- Nov 26, 2009 11:23:32 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53028
;

-- Nov 26, 2009 11:23:32 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53023
;

-- Nov 26, 2009 11:23:32 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53025
;

-- Nov 26, 2009 11:23:32 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53026
;

-- Nov 26, 2009 11:23:32 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53027
;

-- Nov 26, 2009 11:23:38 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53028
;

-- Nov 26, 2009 11:23:38 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53023
;


-- Nov 26, 2009 11:23:38 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53025
;

-- Nov 26, 2009 11:23:38 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53026
;

-- Nov 26, 2009 11:23:38 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53028
;

-- Nov 26, 2009 11:23:38 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53027
;

-- Nov 26, 2009 11:23:40 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53023
;

-- Nov 26, 2009 11:23:40 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53025
;

-- Nov 26, 2009 11:23:40 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53026
;

-- Nov 26, 2009 11:23:40 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53027
;

-- Nov 26, 2009 11:23:40 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53028
;

-- Nov 26, 2009 11:23:40 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53027
;

-- Nov 26, 2009 11:24:07 AM CST
-- Libero Manufacturing
UPDATE AD_Menu SET IsActive='Y',Updated=TO_DATE('2009-11-26 11:24:07','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Menu_ID=426
;

-- Nov 26, 2009 11:27:16 AM CST
-- Libero Manufacturing
INSERT INTO AD_Tab (AD_Client_ID,AD_Org_ID,AD_Tab_ID,AD_Table_ID,AD_Window_ID,Created,CreatedBy,Description,EntityType,HasTree,Help,ImportFields,IsActive,IsAdvancedTab,IsInfoTab,IsInsertRecord,IsReadOnly,IsSingleRow,IsSortTab,IsTranslationTab,Name,Processing,SeqNo,TabLevel,Updated,UpdatedBy) VALUES (0,0,53286,53018,140,TO_DATE('2009-11-26 11:27:15','YYYY-MM-DD HH24:MI:SS'),0,'Bill of Material product lines','EE01','N','The Bill of Materials tab defines those products that are generated from other products.  A Bill of Material (BOM) is one or more Products or BOMs.

Available Quantity:
- Stored BOMs have to be created via "Production"
- The available quantity of a non-stored BOMs is dynamically calculated
- The attribute "Stored" is defined in the "Product" tab

Price:
- BOMs must be listed in Pricelists
- If the price is 0.00, the price is dynamically calculated

Printing:
- Usually, only the BOM information is printed
- For invoices, delivery slips and pick lists, you have the option to print the details
- In the details, the quantity is listed - and the price, if this is dynamically calculated','N','Y','N','N','Y','N','N','N','N','BOM','N',150,0,TO_DATE('2009-11-26 11:27:15','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:27:16 AM CST
-- Libero Manufacturing
INSERT INTO AD_Tab_Trl (AD_Language,AD_Tab_ID, CommitWarning,Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Tab_ID, t.CommitWarning,t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Tab t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Tab_ID=53286 AND NOT EXISTS (SELECT * FROM AD_Tab_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Tab_ID=t.AD_Tab_ID)
;

-- Nov 26, 2009 11:28:26 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,DisplayLength,EntityType,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53335,58082,0,53286,TO_DATE('2009-11-26 11:28:25','YYYY-MM-DD HH24:MI:SS'),0,1,'EE01','Y','Y','N','N','N','N','N','N','Process Now',0,0,TO_DATE('2009-11-26 11:28:25','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:28:26 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58082 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:28:27 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53331,58083,0,53286,TO_DATE('2009-11-26 11:28:26','YYYY-MM-DD HH24:MI:SS'),0,'Client/Tenant for this installation.',22,'EE01','A Client is a company or a legal entity. You cannot share data between Clients. Tenant is a synonym for Client.','Y','Y','Y','N','N','N','N','N','Client',10,0,TO_DATE('2009-11-26 11:28:26','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:28:27 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58083 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:28:28 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53341,58084,0,53286,TO_DATE('2009-11-26 11:28:27','YYYY-MM-DD HH24:MI:SS'),0,'Organizational entity within client',22,'EE01','An organization is a unit of your client or legal entity - examples are store, department. You can share data between organizations.','Y','Y','Y','N','N','N','N','Y','Organization',20,0,TO_DATE('2009-11-26 11:28:27','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:28:28 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58084 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:28:28 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53333,58085,0,53286,TO_DATE('2009-11-26 11:28:28','YYYY-MM-DD HH24:MI:SS'),0,'Product, Service, Item',22,'EE01','Identifies an item which is either purchased or sold in this organization.','Y','Y','Y','N','N','N','N','N','Product',30,0,TO_DATE('2009-11-26 11:28:28','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:28:28 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58085 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:28:29 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53340,58086,0,53286,TO_DATE('2009-11-26 11:28:28','YYYY-MM-DD HH24:MI:SS'),0,'Product Attribute Set Instance',22,'EE01','The values of the actual Product Attribute Instances.  The product level attributes are defined on Product level.','Y','Y','Y','N','N','N','N','Y','Attribute Set Instance',40,0,TO_DATE('2009-11-26 11:28:28','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:28:29 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58086 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:28:30 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53321,58087,0,53286,TO_DATE('2009-11-26 11:28:29','YYYY-MM-DD HH24:MI:SS'),0,'Search key for the record in the format required - must be unique',22,'EE01','A search key allows you a fast method of finding a particular record.
If you leave the search key empty, the system automatically creates a numeric number.  The document sequence used for this fallback number is defined in the "Maintain Sequence" window with the name "DocumentNo_<TableName>", where TableName is the actual name of the table (e.g. C_Order).','Y','Y','Y','N','N','N','N','N','Search Key',50,0,TO_DATE('2009-11-26 11:28:29','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:28:30 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58087 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:28:30 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53344,58088,0,53286,TO_DATE('2009-11-26 11:28:30','YYYY-MM-DD HH24:MI:SS'),0,'Unit of Measure',22,'EE01','The UOM defines a unique non monetary Unit of Measure','Y','Y','Y','N','N','N','N','Y','UOM',60,0,TO_DATE('2009-11-26 11:28:30','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:28:30 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58088 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:28:31 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53322,58089,0,53286,TO_DATE('2009-11-26 11:28:30','YYYY-MM-DD HH24:MI:SS'),0,'Alphanumeric identifier of the entity',120,'EE01','The name of an entity (record) is used as an default search option in addition to the search key. The name is up to 60 characters in length.','Y','Y','Y','N','N','N','N','N','Name',70,0,TO_DATE('2009-11-26 11:28:30','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:28:31 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58089 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:28:31 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53325,58090,0,53286,TO_DATE('2009-11-26 11:28:31','YYYY-MM-DD HH24:MI:SS'),0,'Optional short description of the record',510,'EE01','A description is limited to 255 characters.','Y','Y','Y','N','N','N','N','N','Description',80,0,TO_DATE('2009-11-26 11:28:31','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:28:31 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58090 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:28:32 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53329,58091,0,53286,TO_DATE('2009-11-26 11:28:31','YYYY-MM-DD HH24:MI:SS'),0,'Comment or Hint',2000,'EE01','The Help field contains a hint, comment or help about the use of this item.','Y','Y','Y','N','N','N','N','N','Comment/Help',90,0,TO_DATE('2009-11-26 11:28:31','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:28:32 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58091 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:28:33 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53330,58092,0,53286,TO_DATE('2009-11-26 11:28:32','YYYY-MM-DD HH24:MI:SS'),0,'The record is active in the system',1,'EE01','There are two methods of making records unavailable in the system: One is to delete the record, the other is to de-activate the record. A de-activated record is not available for selection, but available for reports.
There are two reasons for de-activating and not deleting records:
(1) The system requires the record for audit purposes.
(2) The record is referenced by other records. E.g., you cannot delete a Business Partner, if there are invoices for this partner record existing. You de-activate the Business Partner and prevent that this record is used for future entries.','Y','Y','Y','N','N','N','N','N','Active',100,0,TO_DATE('2009-11-26 11:28:32','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:28:33 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58092 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:28:33 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53332,58093,0,53286,TO_DATE('2009-11-26 11:28:33','YYYY-MM-DD HH24:MI:SS'),0,'Bill of Materials (Engineering) Change Notice (Version)',10,'EE01','Y','Y','Y','N','N','N','N','Y','Change Notice',110,0,TO_DATE('2009-11-26 11:28:33','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:28:33 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58093 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:28:34 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53323,58094,0,53286,TO_DATE('2009-11-26 11:28:33','YYYY-MM-DD HH24:MI:SS'),0,'Document sequence number of the document',22,'EE01','The document number is usually automatically generated by the system and determined by the document type of the document. If the document is not saved, the preliminary number is displayed in "<>".

If the document type of your document has no automatic document sequence defined, the field is empty if you create a new document. This is for documents which usually have an external number (like vendor invoice).  If you leave the field empty, the system will generate a document number for you. The document sequence used for this fallback number is defined in the "Maintain Sequence" window with the name "DocumentNo_<TableName>", where TableName is the actual name of the table (e.g. C_Order).','Y','Y','Y','N','N','N','N','N','Document No',120,0,TO_DATE('2009-11-26 11:28:33','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:28:34 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58094 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:28:34 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,DisplayLength,EntityType,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53324,58095,0,53286,TO_DATE('2009-11-26 11:28:34','YYYY-MM-DD HH24:MI:SS'),0,10,'EE01','Y','Y','Y','N','N','N','N','Y','Revision',130,0,TO_DATE('2009-11-26 11:28:34','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:28:34 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58095 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:28:35 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53338,58096,0,53286,TO_DATE('2009-11-26 11:28:34','YYYY-MM-DD HH24:MI:SS'),0,'Valid from including this date (first day)',7,'EE01','The Valid From date indicates the first day of a date range','Y','Y','Y','N','N','N','N','N','Valid from',140,0,TO_DATE('2009-11-26 11:28:34','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:28:35 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58096 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:28:36 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53339,58097,0,53286,TO_DATE('2009-11-26 11:28:35','YYYY-MM-DD HH24:MI:SS'),0,'Valid to including this date (last day)',7,'EE01','The Valid To date indicates the last day of a date range','Y','Y','Y','N','N','N','N','Y','Valid to',150,0,TO_DATE('2009-11-26 11:28:35','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:28:36 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58097 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:28:36 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53342,58098,0,53286,TO_DATE('2009-11-26 11:28:36','YYYY-MM-DD HH24:MI:SS'),0,'Type of BOM',1,'EE01','The type of Bills of Materials determines the state','Y','Y','Y','N','N','N','N','N','BOM Type',160,0,TO_DATE('2009-11-26 11:28:36','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:28:36 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58098 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:28:37 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53343,58099,0,53286,TO_DATE('2009-11-26 11:28:36','YYYY-MM-DD HH24:MI:SS'),0,'The use of the Bill of Material',1,'EE01','By default the Master BOM is used, if the alternatives are not defined','Y','Y','Y','N','N','N','N','Y','BOM Use',170,0,TO_DATE('2009-11-26 11:28:36','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:28:37 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58099 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:28:38 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Included_Tab_ID,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53334,58100,0,53286,TO_DATE('2009-11-26 11:28:37','YYYY-MM-DD HH24:MI:SS'),0,'BOM & Formula',22,'EE01',53029,'Y','Y','Y','N','N','N','N','N','BOM & Formula',180,0,TO_DATE('2009-11-26 11:28:37','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:28:38 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58100 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:28:43 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53326,58101,0,53286,TO_DATE('2009-11-26 11:28:38','YYYY-MM-DD HH24:MI:SS'),0,'Copy BOM Lines from an exising BOM',1,'EE01','Copy BOM Lines from an exising BOM. The BOM being copied to, must not have any existing BOM Lines.','Y','N','Y','N','N','N','N','N','Copy BOM Lines From',190,0,TO_DATE('2009-11-26 11:28:38','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:28:43 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58101 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:30:45 AM CST
-- Libero Manufacturing
INSERT INTO AD_Tab (AD_Client_ID,AD_Org_ID,AD_Tab_ID,AD_Table_ID,AD_Window_ID,Created,CreatedBy,Description,EntityType,HasTree,Help,ImportFields,IsActive,IsAdvancedTab,IsInfoTab,IsInsertRecord,IsReadOnly,IsSingleRow,IsSortTab,IsTranslationTab,Name,Processing,SeqNo,TabLevel,Updated,UpdatedBy) VALUES (0,0,53287,53018,140,TO_DATE('2009-11-26 11:30:43','YYYY-MM-DD HH24:MI:SS'),0,'Components','EE01','N','Components of Bill fo Material','N','Y','N','N','Y','N','N','N','N','Components','N',160,1,TO_DATE('2009-11-26 11:30:43','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:30:45 AM CST
-- Libero Manufacturing
INSERT INTO AD_Tab_Trl (AD_Language,AD_Tab_ID, CommitWarning,Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Tab_ID, t.CommitWarning,t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Tab t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Tab_ID=53287 AND NOT EXISTS (SELECT * FROM AD_Tab_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Tab_ID=t.AD_Tab_ID)
;

-- Nov 26, 2009 11:31:30 AM CST
-- Libero Manufacturing
UPDATE AD_Tab SET AD_Table_ID=53019,Updated=TO_DATE('2009-11-26 11:31:30','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Tab_ID=53287
;

-- Nov 26, 2009 11:31:38 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53346,58102,0,53287,TO_DATE('2009-11-26 11:31:37','YYYY-MM-DD HH24:MI:SS'),0,'Organizational entity within client',22,'EE01','An organization is a unit of your client or legal entity - examples are store, department. You can share data between organizations.','Y','Y','N','N','N','N','N','Y','Organization',0,0,TO_DATE('2009-11-26 11:31:37','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:38 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58102 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:39 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53373,58103,0,53287,TO_DATE('2009-11-26 11:31:38','YYYY-MM-DD HH24:MI:SS'),0,'Client/Tenant for this installation.',22,'EE01','A Client is a company or a legal entity. You cannot share data between Clients. Tenant is a synonym for Client.','Y','Y','N','N','N','N','N','N','Client',0,0,TO_DATE('2009-11-26 11:31:38','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:39 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58103 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:39 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53365,58104,0,53287,TO_DATE('2009-11-26 11:31:39','YYYY-MM-DD HH24:MI:SS'),0,'BOM Line',22,'EE01','The BOM Line is a unique identifier for a BOM line in an BOM.','Y','Y','N','N','N','N','N','N','BOM Line',0,0,TO_DATE('2009-11-26 11:31:39','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:39 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58104 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:40 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53361,58105,0,53287,TO_DATE('2009-11-26 11:31:39','YYYY-MM-DD HH24:MI:SS'),0,'Unique line for this document',22,'EE01','Indicates the unique line for a document.  It will also control the display order of the lines within a document.','Y','Y','Y','N','N','N','N','N','Line No',10,1,TO_DATE('2009-11-26 11:31:39','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:40 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58105 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:40 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53364,58106,0,53287,TO_DATE('2009-11-26 11:31:40','YYYY-MM-DD HH24:MI:SS'),0,'Product, Service, Item',22,'EE01','Identifies an item which is either purchased or sold in this organization.','Y','Y','Y','N','N','N','N','N','Product',20,0,TO_DATE('2009-11-26 11:31:40','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:40 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58106 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:41 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53350,58107,0,53287,TO_DATE('2009-11-26 11:31:40','YYYY-MM-DD HH24:MI:SS'),0,'Component Type for a Bill of Material or Formula',0,'EE01','The Component Type can be:

1.- By Product: Define a By Product as Component into BOM
2.- Component: Define a normal Component into BOM 
3.- Option: Define an Option for Product Configure BOM
4.- Phantom: Define a Phantom as Component into BOM
5.- Packing: Define a Packing as Component into BOM
6.- Planning : Define Planning as Component into BOM
7.- Tools: Define Tools as Component into BOM
8.- Variant: Define Variant  for Product Configure BOM
','Y','Y','Y','N','N','N','N','Y','Component Type',30,0,TO_DATE('2009-11-26 11:31:40','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:41 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58107 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:41 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53349,58108,0,53287,TO_DATE('2009-11-26 11:31:41','YYYY-MM-DD HH24:MI:SS'),0,'Unit of Measure',22,'EE01','The UOM defines a unique non monetary Unit of Measure','Y','Y','Y','N','N','N','N','N','UOM',40,0,TO_DATE('2009-11-26 11:31:41','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:41 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58108 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:42 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53362,58109,0,53287,TO_DATE('2009-11-26 11:31:41','YYYY-MM-DD HH24:MI:SS'),0,'Product Attribute Set Instance',22,'EE01','The values of the actual Product Attribute Instances.  The product level attributes are defined on Product level.','Y','Y','Y','N','N','N','N','Y','Attribute Set Instance',50,0,TO_DATE('2009-11-26 11:31:41','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:42 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58109 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:42 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53353,58110,0,53287,TO_DATE('2009-11-26 11:31:42','YYYY-MM-DD HH24:MI:SS'),0,'Optional short description of the record',510,'EE01','A description is limited to 255 characters.','Y','Y','Y','N','N','N','N','N','Description',60,0,TO_DATE('2009-11-26 11:31:42','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:42 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58110 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:43 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53355,58111,0,53287,TO_DATE('2009-11-26 11:31:42','YYYY-MM-DD HH24:MI:SS'),0,'Comment or Hint',2000,'EE01','The Help field contains a hint, comment or help about the use of this item.','Y','Y','Y','N','N','N','N','N','Comment/Help',70,0,TO_DATE('2009-11-26 11:31:42','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:43 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58111 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:43 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53356,58112,0,53287,TO_DATE('2009-11-26 11:31:43','YYYY-MM-DD HH24:MI:SS'),0,'The record is active in the system',1,'EE01','There are two methods of making records unavailable in the system: One is to delete the record, the other is to de-activate the record. A de-activated record is not available for selection, but available for reports.
There are two reasons for de-activating and not deleting records:
(1) The system requires the record for audit purposes.
(2) The record is referenced by other records. E.g., you cannot delete a Business Partner, if there are invoices for this partner record existing. You de-activate the Business Partner and prevent that this record is used for future entries.','Y','Y','Y','N','N','N','N','N','Active',80,0,TO_DATE('2009-11-26 11:31:43','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:43 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58112 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:44 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53363,58113,0,53287,TO_DATE('2009-11-26 11:31:43','YYYY-MM-DD HH24:MI:SS'),0,'Bill of Materials (Engineering) Change Notice (Version)',10,'EE01','Y','Y','Y','N','N','N','N','Y','Change Notice',90,0,TO_DATE('2009-11-26 11:31:43','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:44 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58113 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:44 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53372,58114,0,53287,TO_DATE('2009-11-26 11:31:44','YYYY-MM-DD HH24:MI:SS'),0,'Valid from including this date (first day)',7,'EE01','The Valid From date indicates the first day of a date range

The Valid From and Valid To dates indicate the valid time period to use the BOM in a Manufacturing Order.','Y','N','Y','N','N','N','N','N','Valid from',100,0,TO_DATE('2009-11-26 11:31:44','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:44 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58114 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:45 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53374,58115,0,53287,TO_DATE('2009-11-26 11:31:44','YYYY-MM-DD HH24:MI:SS'),0,'Valid to including this date (last day)',7,'EE01','The Valid To date indicates the last day of a date range','Y','Y','Y','N','N','N','N','Y','Valid to',110,0,TO_DATE('2009-11-26 11:31:44','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:45 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58115 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:45 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53358,58116,0,53287,TO_DATE('2009-11-26 11:31:45','YYYY-MM-DD HH24:MI:SS'),0,'Indicate that this component is based in % Quantity',1,'EE01','Indicate that this component is based in % Quantity','Y','Y','Y','N','N','N','N','N','Is Qty Percentage',120,0,TO_DATE('2009-11-26 11:31:45','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:45 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58116 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:46 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53357,58117,0,53287,TO_DATE('2009-11-26 11:31:45','YYYY-MM-DD HH24:MI:SS'),0,'Indicate that a Manufacturing Order can not begin without have this component',1,'EE01','Indicate that a Manufacturing Order can not begin without have this component','Y','Y','Y','N','N','N','N','Y','Is Critical Component',130,0,TO_DATE('2009-11-26 11:31:45','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:46 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58117 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:47 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,DisplayLogic,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53368,58118,0,53287,TO_DATE('2009-11-26 11:31:46','YYYY-MM-DD HH24:MI:SS'),0,'Indicate the Quantity % use in this Formula',22,'@IsQtyPercentage@ = Y','EE01','Exist two way the add a compenent to a BOM or Formula:

1.- Adding a Component based in quantity to use in this BOM
2.- Adding a Component based in % to use the Order Quantity of Manufacturing Order in this Formula.
','Y','Y','Y','N','N','N','N','N','Quantity in %',140,0,TO_DATE('2009-11-26 11:31:46','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:47 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58118 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:48 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,DisplayLogic,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53367,58119,0,53287,TO_DATE('2009-11-26 11:31:47','YYYY-MM-DD HH24:MI:SS'),0,'Indicate the Quantity  use in this BOM',22,'@IsQtyPercentage@ = N','EE01','Exist two way the add a compenent to a BOM or Formula:

1.- Adding a Component based in quantity to use in this BOM
2.- Adding a Component based in % to use the Order Quantity of Manufacturing Order in this Formula.
','Y','Y','Y','N','N','N','N','N','Quantity',150,0,TO_DATE('2009-11-26 11:31:47','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:48 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58119 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:49 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53369,58120,0,53287,TO_DATE('2009-11-26 11:31:48','YYYY-MM-DD HH24:MI:SS'),0,'Indicate the % Scrap  for calculate the Scrap Quantity',22,'EE01','Scrap is useful to determinate a rigth Standard Cost and management a good supply.','Y','Y','Y','N','N','N','N','N','% Scrap',160,0,TO_DATE('2009-11-26 11:31:48','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:49 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58120 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:49 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53347,58121,0,53287,TO_DATE('2009-11-26 11:31:49','YYYY-MM-DD HH24:MI:SS'),0,'Indicated the Quantity Assay to use into Quality Order',22,'EE01','Indicated the Quantity Assay to use into Quality Order','Y','Y','Y','N','N','N','N','Y','Quantity Assay',170,0,TO_DATE('2009-11-26 11:31:49','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:49 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58121 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:50 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53359,58122,0,53287,TO_DATE('2009-11-26 11:31:49','YYYY-MM-DD HH24:MI:SS'),0,'There are two methods for issue the components to Manufacturing Order',1,'EE01','Method Issue: The component are delivered one for one and is necessary indicate the delivered quantity for each component.

Method BackFlush: The component are delivered based in BOM, The  delivered quantity for each component is based in BOM or Formula and Manufacturing Order Quantity.

Use the field Backflush Group for grouping the component in a Backflush Method.','Y','Y','Y','N','N','N','N','N','Issue Method',180,0,TO_DATE('2009-11-26 11:31:49','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:50 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58122 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:51 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,DisplayLogic,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53348,58123,0,53287,TO_DATE('2009-11-26 11:31:50','YYYY-MM-DD HH24:MI:SS'),0,'The Grouping Components to the Backflush',20,'@IssueMethod@=1','EE01','When the components are deliver is possible to indicated The Backflush Group this way you only can deliver the components that are for this Backflush Group.','Y','Y','Y','N','N','N','N','Y','Backflush Group',190,0,TO_DATE('2009-11-26 11:31:50','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:51 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58123 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:51 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53360,58124,0,53287,TO_DATE('2009-11-26 11:31:51','YYYY-MM-DD HH24:MI:SS'),0,'Optional Lead Time offest before starting production',10,'EE01','Optional Lead Time offest before starting production','Y','Y','Y','N','N','N','N','N','Lead Time Offset',200,0,TO_DATE('2009-11-26 11:31:51','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:51 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58124 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:52 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,DisplayLogic,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53345,58125,0,53287,TO_DATE('2009-11-26 11:31:51','YYYY-MM-DD HH24:MI:SS'),0,'Indicated the Feature for Product Configure',30,'@ComponentType@=''VA'' & @BOMType@=''C'' | @ComponentType@=''OP'' & @BOMType@=''C''','EE01','Indicated the Feature for Product Configure','Y','Y','Y','N','N','N','N','N','Feature',210,0,TO_DATE('2009-11-26 11:31:51','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:52 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58125 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:53 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,DisplayLogic,EntityType,Help,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53354,58126,0,53287,TO_DATE('2009-11-26 11:31:52','YYYY-MM-DD HH24:MI:SS'),0,'Indicated the % of participation this component into a of the BOM Planning',22,'@BOMUse@=''P''','EE01','The BOM of Planning Type are useful to Planning the Product family.

For example is possible create a BOM Planning for an Automobile

10% Automobile Red
35% Automobile Blue
45% Automobile Black
19% Automobile Green
1%  Automobile Orange

When Material Plan is calculated MRP generate a Manufacturing Order meet to demand to each  of the Automobile','Y','Y','Y','N','N','N','N','N','Forecast',220,0,TO_DATE('2009-11-26 11:31:52','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:53 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58126 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:31:53 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field (AD_Client_ID,AD_Column_ID,AD_Field_ID,AD_Org_ID,AD_Tab_ID,Created,CreatedBy,Description,DisplayLength,EntityType,Included_Tab_ID,IsActive,IsCentrallyMaintained,IsDisplayed,IsEncrypted,IsFieldOnly,IsHeading,IsReadOnly,IsSameLine,Name,SeqNo,SortNo,Updated,UpdatedBy) VALUES (0,53366,58127,0,53287,TO_DATE('2009-11-26 11:31:53','YYYY-MM-DD HH24:MI:SS'),0,'BOM & Formula',22,'EE01',53216,'Y','Y','Y','N','N','N','N','N','BOM & Formula',230,0,TO_DATE('2009-11-26 11:31:53','YYYY-MM-DD HH24:MI:SS'),0)
;

-- Nov 26, 2009 11:31:53 AM CST
-- Libero Manufacturing
INSERT INTO AD_Field_Trl (AD_Language,AD_Field_ID, Description,Help,Name, IsTranslated,AD_Client_ID,AD_Org_ID,Created,Createdby,Updated,UpdatedBy) SELECT l.AD_Language,t.AD_Field_ID, t.Description,t.Help,t.Name, 'N',t.AD_Client_ID,t.AD_Org_ID,t.Created,t.Createdby,t.Updated,t.UpdatedBy FROM AD_Language l, AD_Field t WHERE l.IsActive='Y' AND l.IsSystemLanguage='Y' AND l.IsBaseLanguage='N' AND t.AD_Field_ID=58127 AND NOT EXISTS (SELECT * FROM AD_Field_Trl tt WHERE tt.AD_Language=l.AD_Language AND tt.AD_Field_ID=t.AD_Field_ID)
;

-- Nov 26, 2009 11:38:49 AM CST
-- Libero Manufacturing
UPDATE AD_Tab SET SeqNo=15,Updated=TO_DATE('2009-11-26 11:38:49','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Tab_ID=53286
;

-- Nov 26, 2009 11:41:49 AM CST
-- Libero Manufacturing
UPDATE AD_Tab SET AD_Column_ID=53333,Updated=TO_DATE('2009-11-26 11:41:49','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Tab_ID=53286
;

-- Nov 26, 2009 11:43:55 AM CST
-- Libero Manufacturing
UPDATE AD_Tab SET AD_Column_ID=NULL, WhereClause='M_Product_ID=@M_Product_ID@',Updated=TO_DATE('2009-11-26 11:43:55','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Tab_ID=53286
;

-- Nov 26, 2009 11:45:06 AM CST
-- Libero Manufacturing
UPDATE AD_Tab SET SeqNo=16,Updated=TO_DATE('2009-11-26 11:45:06','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Tab_ID=53287
;

-- Nov 26, 2009 11:45:44 AM CST
-- Libero Manufacturing
UPDATE AD_Field SET Included_Tab_ID=53287,Updated=TO_DATE('2009-11-26 11:45:44','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=58100
;

-- Nov 26, 2009 11:48:47 AM CST
-- Libero Manufacturing
UPDATE AD_Tab SET IsSingleRow='Y',Updated=TO_DATE('2009-11-26 11:48:47','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Tab_ID=53286
;

-- Nov 26, 2009 11:50:23 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53023
;

-- Nov 26, 2009 11:50:23 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53024
;

-- Nov 26, 2009 11:50:23 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53025
;

-- Nov 26, 2009 11:50:23 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53026
;

-- Nov 26, 2009 11:50:23 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53027
;

-- Nov 26, 2009 11:50:23 AM CST
-- Libero Manufacturing
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53028
;

