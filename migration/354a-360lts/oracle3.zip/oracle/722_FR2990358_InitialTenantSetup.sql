-- Apr 22, 2010 12:27:46 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=230,Updated=TO_DATE('2010-04-22 12:27:46','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53407
;

-- Apr 22, 2010 12:27:52 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=220,Updated=TO_DATE('2010-04-22 12:27:52','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53352
;

-- Apr 22, 2010 12:27:57 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=210,Updated=TO_DATE('2010-04-22 12:27:57','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53351
;

-- Apr 22, 2010 12:28:03 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=200,Updated=TO_DATE('2010-04-22 12:28:03','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53350
;

-- Apr 22, 2010 12:28:07 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=190,Updated=TO_DATE('2010-04-22 12:28:07','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53349
;

-- Apr 22, 2010 12:28:11 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=180,Updated=TO_DATE('2010-04-22 12:28:11','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53296
;

-- Apr 22, 2010 12:28:16 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=170,Updated=TO_DATE('2010-04-22 12:28:16','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53295
;

-- Apr 22, 2010 12:28:19 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=160,Updated=TO_DATE('2010-04-22 12:28:19','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53294
;

-- Apr 22, 2010 12:28:24 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=150,Updated=TO_DATE('2010-04-22 12:28:24','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53293
;

-- Apr 22, 2010 12:28:27 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=140,Updated=TO_DATE('2010-04-22 12:28:27','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53292
;

-- Apr 22, 2010 12:28:29 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=130,Updated=TO_DATE('2010-04-22 12:28:29','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53291
;

-- Apr 22, 2010 12:28:32 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=120,Updated=TO_DATE('2010-04-22 12:28:32','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53353
;

-- Apr 22, 2010 12:28:35 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=110,Updated=TO_DATE('2010-04-22 12:28:35','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53348
;

-- Apr 22, 2010 12:28:37 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=100,Updated=TO_DATE('2010-04-22 12:28:37','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53290
;

-- Apr 22, 2010 12:28:40 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=90,Updated=TO_DATE('2010-04-22 12:28:40','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53289
;

-- Apr 22, 2010 12:28:43 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=80,Updated=TO_DATE('2010-04-22 12:28:43','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53288
;

-- Apr 22, 2010 12:28:46 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=70,Updated=TO_DATE('2010-04-22 12:28:46','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53287
;

-- Apr 22, 2010 12:28:49 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=60,Updated=TO_DATE('2010-04-22 12:28:49','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53286
;

-- Apr 22, 2010 12:28:52 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=50,Updated=TO_DATE('2010-04-22 12:28:52','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53285
;

-- Apr 22, 2010 12:28:54 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=40,Updated=TO_DATE('2010-04-22 12:28:54','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53284
;

-- Apr 22, 2010 12:28:57 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=30,Updated=TO_DATE('2010-04-22 12:28:57','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53283
;

-- Apr 22, 2010 12:28:59 PM CEST
-- FR [2990358] - Extend Initial Tenant setup
-- https://sourceforge.net/tracker/?func=detail&aid=2990358&group_id=176962&atid=879335
UPDATE AD_Process_Para SET SeqNo=20,Updated=TO_DATE('2010-04-22 12:28:59','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53347
;

