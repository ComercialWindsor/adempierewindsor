-- Jan 4, 2010 5:36:54 PM COT
-- 2923042_Problems in Requisition window
UPDATE AD_Field SET IsActive='N', IsDisplayed='N', SeqNo=0,Updated=TO_DATE('2010-01-04 17:36:54','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=12463
;

