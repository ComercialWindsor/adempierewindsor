-- Dec 15, 2009 6:32:41 PM COT
-- 2904311_Wrong default for parameter Org in Statement of Accounts
UPDATE AD_Process_Para SET DefaultValue='-1',Updated=TO_DATE('2009-12-15 18:32:41','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=459
;

