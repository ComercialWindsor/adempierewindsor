-- Mar 11, 2010 3:09:41 PM COT
UPDATE M_Product SET DescriptionURL='http://www.adempiere.com/index.php/SampleProductDescriptionForDocumentation', ImageURL='http://www.adempiere.com/images/f/f5/C32.png', IsStocked='N',Updated=TO_DATE('2010-03-11 15:09:41','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE M_Product_ID=146
;

-- Mar 11, 2010 3:09:58 PM COT
UPDATE M_Product SET ImageURL='http://www.adempiere.com/images/f/f5/C32.png', IsStocked='N',Updated=TO_DATE('2010-03-11 15:09:58','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE M_Product_ID=126
;

