
UPDATE AD_Field SET DisplayLogic='@PrintFormatType@=F|@PrintFormatType@=T',Updated=TO_DATE('2009-10-20 11:18:49','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=5688
;

