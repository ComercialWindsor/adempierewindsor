-- Mar 16, 2010 10:59:51 PM COT
-- BF 2962244 Future dated price list version used in order
UPDATE AD_Column SET Callout=NULL,Updated=TO_DATE('2010-03-16 22:59:51','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=56376
;

-- Mar 16, 2010 11:00:48 PM COT
UPDATE AD_Column SET Callout='org.compiere.model.CalloutEngine.dateAcct; org.compiere.model.CalloutOrder.priceList',Updated=TO_DATE('2010-03-16 23:00:48','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=2181
;

-- Mar 16, 2010 11:00:51 PM COT
UPDATE AD_Column SET Callout=NULL,Updated=TO_DATE('2010-03-16 23:00:51','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=2166
;

-- Mar 16, 2010 11:01:11 PM COT
UPDATE AD_Column SET Callout='org.compiere.model.CalloutEngine.dateAcct; org.compiere.model.CalloutOrder.priceList',Updated=TO_DATE('2010-03-16 23:01:11','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=3783
;
