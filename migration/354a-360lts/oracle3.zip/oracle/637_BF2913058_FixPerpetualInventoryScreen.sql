-- Dec 11, 2009 10:03:25 PM CET
-- BF [2913058] - FixPerpetualInventoryScreen
-- https://sourceforge.net/tracker/?func=detail&aid=2913058&group_id=176962&atid=879332
UPDATE AD_Field SET IsReadOnly='N',Updated=TO_DATE('2009-12-11 22:03:25','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=3036
;

