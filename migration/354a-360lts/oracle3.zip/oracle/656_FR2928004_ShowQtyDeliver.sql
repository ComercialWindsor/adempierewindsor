-- Jan 7, 2010 8:59:29 PM CST
-- Distribution Management
UPDATE AD_Field SET SeqNo=90,IsDisplayed='Y' WHERE AD_Field_ID=54036
;

-- Jan 7, 2010 8:59:29 PM CST
-- Distribution Management
UPDATE AD_Field SET SeqNo=100,IsDisplayed='Y' WHERE AD_Field_ID=54037
;

-- Jan 7, 2010 8:59:29 PM CST
-- Distribution Management
UPDATE AD_Field SET SeqNo=110,IsDisplayed='Y' WHERE AD_Field_ID=54038
;

-- Jan 7, 2010 8:59:29 PM CST
-- Distribution Management
UPDATE AD_Field SET SeqNo=120,IsDisplayed='Y' WHERE AD_Field_ID=54039
;

-- Jan 7, 2010 9:02:54 PM CST
-- Distribution Management
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=54018
;

-- Jan 7, 2010 9:02:54 PM CST
-- Distribution Management
UPDATE AD_Field SET SeqNo=80,IsDisplayed='Y' WHERE AD_Field_ID=54016
;

-- Jan 7, 2010 9:51:24 PM CST
-- Distribution Management
UPDATE AD_Column SET Callout='org.eevolution.model.CalloutDistributionOrder.qtyConfirmed',Updated=TO_DATE('2010-01-07 21:51:24','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Column_ID=53934
;

-- Jan 7, 2010 10:08:51 PM CST
-- Distribution Management
UPDATE AD_Field SET IsReadOnly='Y',Updated=TO_DATE('2010-01-07 22:08:51','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=54016
;

