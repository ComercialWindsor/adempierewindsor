-- Dec 14, 2009 5:29:08 PM COT
-- 2897751_PackIn -> folder target must be mandatory
UPDATE AD_Column SET IsMandatory='Y',Updated=TO_DATE('2009-12-14 17:29:08','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=50170
;

