-- Nov 29, 2009 4:56:03 PM MYT
-- 2836655-Resource Assignment always return Qty 1
UPDATE AD_Column SET Callout='org.compiere.model.CalloutAssignment.product; org.compiere.model.CalloutOrder.amt; org.compiere.model.CalloutOrder.qty',Updated=TO_DATE('2009-11-29 16:56:03','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=6775
;

