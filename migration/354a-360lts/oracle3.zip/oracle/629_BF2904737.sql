-- Dec 9, 2009 7:28:02 PM COT
-- BF [2904737] - fix BOM back compatibility 
UPDATE AD_Tab SET IsActive='Y',Updated=TO_DATE('2009-12-09 19:28:02','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Tab_ID=53286
;

-- Dec 9, 2009 7:28:06 PM COT
UPDATE AD_Tab SET IsActive='Y',Updated=TO_DATE('2009-12-09 19:28:06','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Tab_ID=53287
;

-- Dec 9, 2009 7:28:42 PM COT
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53023
;

-- Dec 9, 2009 7:28:42 PM COT
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53024
;

-- Dec 9, 2009 7:28:43 PM COT
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53025
;

-- Dec 9, 2009 7:28:43 PM COT
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53026
;

-- Dec 9, 2009 7:28:43 PM COT
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53027
;

-- Dec 9, 2009 7:28:43 PM COT
UPDATE AD_TreeNodeMM SET Parent_ID=53022, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53028
;

