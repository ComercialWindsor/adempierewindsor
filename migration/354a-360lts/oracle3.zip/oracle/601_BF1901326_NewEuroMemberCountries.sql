-- Feb 25, 2008 1:28:06 PM CET
-- Default comment for updating dictionary
UPDATE C_Country SET C_Currency_ID=102,Updated=TO_DATE('2008-02-25 13:28:06','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_Country_ID=302
;

-- Feb 25, 2008 1:28:26 PM CET
-- Default comment for updating dictionary
UPDATE C_Country SET C_Currency_ID=102,Updated=TO_DATE('2008-02-25 13:28:26','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_Country_ID=165
;

-- Feb 25, 2008 1:28:46 PM CET
-- Default comment for updating dictionary
UPDATE C_Country SET C_Currency_ID=102,Updated=TO_DATE('2008-02-25 13:28:46','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_Country_ID=241
;

