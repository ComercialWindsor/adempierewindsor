-- Jun 13, 2010 7:47:15 PM CDT
-- Distribution Management Distribution Order
UPDATE AD_Column SET DefaultValue=NULL,Updated=TO_DATE('2010-06-13 19:47:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=53949
;

-- Jun 13, 2010 7:48:48 PM CDT
-- Distribution Management Distribution Order
UPDATE AD_Column SET Callout='org.eevolution.model.CalloutDistributionOrder.setLocatorTo',Updated=TO_DATE('2010-06-13 19:48:48','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=53929
;

-- Jun 13, 2010 7:49:51 PM CDT
-- Distribution Management Distribution Order
UPDATE AD_Field SET SeqNo=80,IsDisplayed='Y' WHERE AD_Field_ID=54003
;

-- Jun 13, 2010 7:49:51 PM CDT
-- Distribution Management Distribution Order
UPDATE AD_Field SET SeqNo=90,IsDisplayed='Y' WHERE AD_Field_ID=54016
;

-- Jun 13, 2010 7:49:51 PM CDT
-- Distribution Management Distribution Order
UPDATE AD_Field SET SeqNo=100,IsDisplayed='Y' WHERE AD_Field_ID=58881
;

-- Jun 13, 2010 7:49:51 PM CDT
-- Distribution Management Distribution Order
UPDATE AD_Field SET SeqNo=110,IsDisplayed='Y' WHERE AD_Field_ID=54036
;

-- Jun 13, 2010 7:49:51 PM CDT
-- Distribution Management Distribution Order
UPDATE AD_Field SET SeqNo=120,IsDisplayed='Y' WHERE AD_Field_ID=54037
;

-- Jun 13, 2010 7:49:51 PM CDT
-- Distribution Management Distribution Order
UPDATE AD_Field SET SeqNo=130,IsDisplayed='Y' WHERE AD_Field_ID=54038
;

-- Jun 13, 2010 7:49:51 PM CDT
-- Distribution Management Distribution Order
UPDATE AD_Field SET SeqNo=140,IsDisplayed='Y' WHERE AD_Field_ID=54039
;

-- Jun 13, 2010 7:49:59 PM CDT
-- Distribution Management Distribution Order
UPDATE AD_Field SET IsReadOnly='Y',Updated=TO_DATE('2010-06-13 19:49:59','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=54003
;

-- Jun 13, 2010 7:50:03 PM CDT
-- Distribution Management Distribution Order
UPDATE AD_Field SET IsSameLine='Y',Updated=TO_DATE('2010-06-13 19:50:03','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=54016
;

-- Jun 13, 2010 8:00:50 PM CDT
-- Distribution Management Distribution Order
UPDATE AD_Field SET IsSameLine='Y',Updated=TO_DATE('2010-06-13 20:00:50','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=54032
;

-- Jun 13, 2010 8:01:08 PM CDT
-- Distribution Management Distribution Order
UPDATE AD_Field SET IsSameLine='N',Updated=TO_DATE('2010-06-13 20:01:08','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=54032
;

-- Jun 13, 2010 8:01:21 PM CDT
-- Distribution Management Distribution Order
UPDATE AD_Field SET SeqNo=80,IsDisplayed='Y' WHERE AD_Field_ID=58881
;

-- Jun 13, 2010 8:01:21 PM CDT
-- Distribution Management Distribution Order
UPDATE AD_Field SET SeqNo=90,IsDisplayed='Y' WHERE AD_Field_ID=54003
;

-- Jun 13, 2010 8:01:21 PM CDT
-- Distribution Management Distribution Order
UPDATE AD_Field SET SeqNo=100,IsDisplayed='Y' WHERE AD_Field_ID=54016
;

