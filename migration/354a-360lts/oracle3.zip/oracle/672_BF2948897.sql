-- Mar 4, 2010 1:33:05 PM COT
-- BF2948897_Fixed Assets Dictionary Errors
UPDATE AD_Tab SET WhereClause='A_Depreciation_Entry.A_Entry_Type=''DIS''',Updated=TO_DATE('2010-03-04 13:33:05','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Tab_ID=53141
;

-- Mar 4, 2010 1:33:13 PM COT
-- BF2948897_Fixed Assets Dictionary Errors
UPDATE AD_Tab SET WhereClause='A_Depreciation_Entry.A_Entry_Type=''SPL''',Updated=TO_DATE('2010-03-04 13:33:13','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Tab_ID=53151
;

-- Mar 4, 2010 1:33:21 PM COT
-- BF2948897_Fixed Assets Dictionary Errors
UPDATE AD_Tab SET WhereClause='A_Depreciation_Entry.A_Entry_Type=''TRN''',Updated=TO_DATE('2010-03-04 13:33:21','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Tab_ID=53140
;

