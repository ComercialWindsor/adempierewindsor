-- Dec 7, 2009 7:30:30 PM COT
-- fix BOM back compatibility
UPDATE AD_Tab SET IsActive='N',Updated=TO_DATE('2009-12-07 19:30:30','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Tab_ID=53286
;

-- Dec 7, 2009 7:30:32 PM COT
-- fix BOM back compatibility
UPDATE AD_Tab SET IsActive='N',Updated=TO_DATE('2009-12-07 19:30:32','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Tab_ID=53287
;

-- Dec 7, 2009 7:31:12 PM COT
-- fix BOM back compatibility
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=268
;

-- Dec 7, 2009 7:31:12 PM COT
-- fix BOM back compatibility
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=125
;

-- Dec 7, 2009 7:31:12 PM COT
-- fix BOM back compatibility
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=422
;

-- Dec 7, 2009 7:31:12 PM COT
-- fix BOM back compatibility
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=107
;

-- Dec 7, 2009 7:31:12 PM COT
-- fix BOM back compatibility
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=130
;

-- Dec 7, 2009 7:31:12 PM COT
-- fix BOM back compatibility
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=188
;

-- Dec 7, 2009 7:31:12 PM COT
-- fix BOM back compatibility
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=227
;

-- Dec 7, 2009 7:31:12 PM COT
-- fix BOM back compatibility
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=381
;

-- Dec 7, 2009 7:31:12 PM COT
-- fix BOM back compatibility
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=8, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=126
;

-- Dec 7, 2009 7:31:12 PM COT
-- fix BOM back compatibility
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=9, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53024
;

-- Dec 7, 2009 7:31:12 PM COT
-- fix BOM back compatibility
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=10, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=421
;

-- Dec 7, 2009 7:31:12 PM COT
-- fix BOM back compatibility
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=11, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=534
;

-- Dec 7, 2009 7:31:12 PM COT
-- fix BOM back compatibility
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=12, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=267
;

-- Dec 7, 2009 7:31:12 PM COT
-- fix BOM back compatibility
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=13, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=490
;

-- Dec 7, 2009 7:31:12 PM COT
-- fix BOM back compatibility
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=14, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=132
;

-- Dec 7, 2009 7:31:12 PM COT
-- fix BOM back compatibility
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=15, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=310
;

-- Dec 7, 2009 7:31:12 PM COT
-- fix BOM back compatibility
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=16, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=128
;

-- Dec 7, 2009 7:31:12 PM COT
-- fix BOM back compatibility
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=17, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=585
;

-- Dec 7, 2009 7:31:12 PM COT
-- fix BOM back compatibility
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=18, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=187
;

-- Dec 7, 2009 7:31:12 PM COT
-- fix BOM back compatibility
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=19, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53210
;

-- Dec 7, 2009 7:31:12 PM COT
-- fix BOM back compatibility
UPDATE AD_TreeNodeMM SET Parent_ID=167, SeqNo=20, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53211
;

