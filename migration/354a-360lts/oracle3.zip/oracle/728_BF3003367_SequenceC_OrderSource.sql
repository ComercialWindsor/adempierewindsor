-- May 18, 2010 11:40:47 AM CEST
-- BF [3003367] - Missing Sequence for C_OrderSource
-- https://sourceforge.net/tracker/?func=detail&aid=3003367&group_id=176962&atid=879332
INSERT INTO AD_Sequence (AD_Client_ID,AD_Org_ID,AD_Sequence_ID,Created,CreatedBy,CurrentNext,CurrentNextSys,Description,IncrementNo,IsActive,IsAudited,IsAutoSequence,IsTableID,Name,StartNewYear,StartNo,Updated,UpdatedBy) VALUES (0,0,53377,TO_DATE('2010-05-18 11:40:47','YYYY-MM-DD HH24:MI:SS'),100,1000000,50000,'DocumentNo/Value for Table C_OrderSource',1,'Y','N','Y','N','DocumentNo_C_OrderSource','N',1000000,TO_DATE('2010-05-18 11:40:47','YYYY-MM-DD HH24:MI:SS'),100)
;

