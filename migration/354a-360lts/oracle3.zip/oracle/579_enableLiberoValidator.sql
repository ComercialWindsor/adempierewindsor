UPDATE AD_ModelValidator SET IsActive='Y' WHERE
AD_ModelValidator_ID=50000;
