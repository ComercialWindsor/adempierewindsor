-- Dec 12, 2009 11:17:21 PM CET
-- FR [2913358] BPartner role - Manufacturer
-- https://sourceforge.net/tracker/?func=detail&aid=2913358&group_id=176962&atid=883808
UPDATE AD_Tab SET SeqNo=75,Updated=TO_DATE('2009-12-12 23:17:21','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Tab_ID=53288
;

