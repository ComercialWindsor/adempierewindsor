-- Sep 18, 2009 8:46:56 PM EST
-- BF2861302 Order By Clause of ad_reference_id 240
UPDATE AD_Ref_Table SET OrderByClause='PA_ReportLine.SeqNo',Updated=TO_DATE('2009-09-18 20:46:56','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Reference_ID=240
;

