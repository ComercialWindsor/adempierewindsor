-- Feb 18, 2009 12:13:16 PM EET
-- 
UPDATE AD_Tab SET WhereClause='PP_Order_ID=@PP_Order_ID@ AND PP_Order_BOM_ID=@PP_Order_BOM_ID@',Updated=TO_DATE('2009-02-18 12:13:14','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Tab_ID=53039
;

