-- Aug 4, 2009 6:27:34 PM COT
-- 2832312-Encrypted button must have better displaylogic
UPDATE AD_Column SET ReadOnlyLogic='@IsKey@=Y | @IsParent@=Y | @IsIdentifier@=Y | @IsEncrypted@=Y | @IsTranslated@=Y | @ColumnName@=AD_Client_ID | @ColumnName@=AD_Client_ID | @ColumnName@=AD_Org_ID | @ColumnName@=IsActive | @ColumnName@=Created | @ColumnName@=Updated | @ColumnName@=DocumentNo | @ColumnName@=Value | @ColumnName@=Name | @AD_Reference_ID@=23 | @AD_Reference_ID@=36 | @ColumnSQL@!''''',Updated=TO_DATE('2009-08-04 18:27:34','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=128
;

