
-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=178 AND AD_Role_ID=102 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=179 AND AD_Role_ID=102 AND C_DocType_ID=50003
;
-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=180 AND AD_Role_ID=102 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=181 AND AD_Role_ID=102 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=182 AND AD_Role_ID=102 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=183 AND AD_Role_ID=102 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=184 AND AD_Role_ID=102 AND C_DocType_ID=50003
;
-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=185 AND AD_Role_ID=102 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=187 AND AD_Role_ID=102 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=188 AND AD_Role_ID=102 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=189 AND AD_Role_ID=102 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=345 AND AD_Role_ID=102 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=347 AND AD_Role_ID=102 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=691 AND AD_Role_ID=102 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=178 AND AD_Role_ID=102 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=179 AND AD_Role_ID=102 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=180 AND AD_Role_ID=102 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=181 AND AD_Role_ID=102 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=182 AND AD_Role_ID=102 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=183 AND AD_Role_ID=102 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=184 AND AD_Role_ID=102 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=185 AND AD_Role_ID=102 AND C_DocType_ID=50004
;
-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=187 AND AD_Role_ID=102 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=188 AND AD_Role_ID=102 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:48:17 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=189 AND AD_Role_ID=102 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=345 AND AD_Role_ID=102 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=347 AND AD_Role_ID=102 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=691 AND AD_Role_ID=102 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=178 AND AD_Role_ID=102 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=179 AND AD_Role_ID=102 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=180 AND AD_Role_ID=102 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=181 AND AD_Role_ID=102 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=182 AND AD_Role_ID=102 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=183 AND AD_Role_ID=102 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=184 AND AD_Role_ID=102 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=185 AND AD_Role_ID=102 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=187 AND AD_Role_ID=102 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=188 AND AD_Role_ID=102 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=189 AND AD_Role_ID=102 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=345 AND AD_Role_ID=102 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=347 AND AD_Role_ID=102 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=691 AND AD_Role_ID=102 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=178 AND AD_Role_ID=102 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=179 AND AD_Role_ID=102 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=180 AND AD_Role_ID=102 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=181 AND AD_Role_ID=102 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=182 AND AD_Role_ID=102 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=183 AND AD_Role_ID=102 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=184 AND AD_Role_ID=102 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=185 AND AD_Role_ID=102 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=187 AND AD_Role_ID=102 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=188 AND AD_Role_ID=102 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=189 AND AD_Role_ID=102 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=345 AND AD_Role_ID=102 AND C_DocType_ID=50006
;
-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=347 AND AD_Role_ID=102 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=691 AND AD_Role_ID=102 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=178 AND AD_Role_ID=102 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:48:18 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=179 AND AD_Role_ID=102 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=180 AND AD_Role_ID=102 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=181 AND AD_Role_ID=102 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=182 AND AD_Role_ID=102 AND C_DocType_ID=50007
;
-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=183 AND AD_Role_ID=102 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=184 AND AD_Role_ID=102 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=185 AND AD_Role_ID=102 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=187 AND AD_Role_ID=102 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=188 AND AD_Role_ID=102 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=189 AND AD_Role_ID=102 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=345 AND AD_Role_ID=102 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=347 AND AD_Role_ID=102 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=691 AND AD_Role_ID=102 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=178 AND AD_Role_ID=102 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=179 AND AD_Role_ID=102 AND C_DocType_ID=50008
;
-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=180 AND AD_Role_ID=102 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=181 AND AD_Role_ID=102 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=182 AND AD_Role_ID=102 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=183 AND AD_Role_ID=102 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=184 AND AD_Role_ID=102 AND C_DocType_ID=50008
;
-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=185 AND AD_Role_ID=102 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=187 AND AD_Role_ID=102 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=188 AND AD_Role_ID=102 AND C_DocType_ID=50008
;
-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=189 AND AD_Role_ID=102 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=345 AND AD_Role_ID=102 AND C_DocType_ID=50008
;
-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=347 AND AD_Role_ID=102 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=691 AND AD_Role_ID=102 AND C_DocType_ID=50008
;
-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=178 AND AD_Role_ID=102 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=179 AND AD_Role_ID=102 AND C_DocType_ID=50009
;
-- Jan 1, 2009 11:48:19 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=180 AND AD_Role_ID=102 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:48:20 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=181 AND AD_Role_ID=102 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:48:20 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=182 AND AD_Role_ID=102 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:48:20 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=183 AND AD_Role_ID=102 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:48:20 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=184 AND AD_Role_ID=102 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:48:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=185 AND AD_Role_ID=102 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:48:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=187 AND AD_Role_ID=102 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:48:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=188 AND AD_Role_ID=102 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:48:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=189 AND AD_Role_ID=102 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:48:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=345 AND AD_Role_ID=102 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:48:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=347 AND AD_Role_ID=102 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:48:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=691 AND AD_Role_ID=102 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:49:20 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=178 AND AD_Role_ID=103 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:49:20 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=179 AND AD_Role_ID=103 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:49:20 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=180 AND AD_Role_ID=103 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=181 AND AD_Role_ID=103 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=182 AND AD_Role_ID=103 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=183 AND AD_Role_ID=103 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=184 AND AD_Role_ID=103 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=185 AND AD_Role_ID=103 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=187 AND AD_Role_ID=103 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=188 AND AD_Role_ID=103 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=189 AND AD_Role_ID=103 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=345 AND AD_Role_ID=103 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=347 AND AD_Role_ID=103 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=691 AND AD_Role_ID=103 AND C_DocType_ID=50003
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=178 AND AD_Role_ID=103 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=179 AND AD_Role_ID=103 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=180 AND AD_Role_ID=103 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=181 AND AD_Role_ID=103 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=182 AND AD_Role_ID=103 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=183 AND AD_Role_ID=103 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=184 AND AD_Role_ID=103 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=185 AND AD_Role_ID=103 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=187 AND AD_Role_ID=103 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=188 AND AD_Role_ID=103 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=189 AND AD_Role_ID=103 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=345 AND AD_Role_ID=103 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=347 AND AD_Role_ID=103 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=691 AND AD_Role_ID=103 AND C_DocType_ID=50004
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=178 AND AD_Role_ID=103 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=179 AND AD_Role_ID=103 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=180 AND AD_Role_ID=103 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=181 AND AD_Role_ID=103 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=182 AND AD_Role_ID=103 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=183 AND AD_Role_ID=103 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=184 AND AD_Role_ID=103 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=185 AND AD_Role_ID=103 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=187 AND AD_Role_ID=103 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=188 AND AD_Role_ID=103 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=189 AND AD_Role_ID=103 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=345 AND AD_Role_ID=103 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=347 AND AD_Role_ID=103 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=691 AND AD_Role_ID=103 AND C_DocType_ID=50005
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=178 AND AD_Role_ID=103 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=179 AND AD_Role_ID=103 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:49:21 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=180 AND AD_Role_ID=103 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=181 AND AD_Role_ID=103 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=182 AND AD_Role_ID=103 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=183 AND AD_Role_ID=103 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=184 AND AD_Role_ID=103 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=185 AND AD_Role_ID=103 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=187 AND AD_Role_ID=103 AND C_DocType_ID=50006
;
-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=188 AND AD_Role_ID=103 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=189 AND AD_Role_ID=103 AND C_DocType_ID=50006
;
-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=345 AND AD_Role_ID=103 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=347 AND AD_Role_ID=103 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=691 AND AD_Role_ID=103 AND C_DocType_ID=50006
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=178 AND AD_Role_ID=103 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=179 AND AD_Role_ID=103 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=180 AND AD_Role_ID=103 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=181 AND AD_Role_ID=103 AND C_DocType_ID=50007
;
-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=182 AND AD_Role_ID=103 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=183 AND AD_Role_ID=103 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=184 AND AD_Role_ID=103 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=185 AND AD_Role_ID=103 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=187 AND AD_Role_ID=103 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=188 AND AD_Role_ID=103 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=189 AND AD_Role_ID=103 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=345 AND AD_Role_ID=103 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=347 AND AD_Role_ID=103 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=691 AND AD_Role_ID=103 AND C_DocType_ID=50007
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=178 AND AD_Role_ID=103 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=179 AND AD_Role_ID=103 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=180 AND AD_Role_ID=103 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=181 AND AD_Role_ID=103 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=182 AND AD_Role_ID=103 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:49:22 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=183 AND AD_Role_ID=103 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:49:23 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=184 AND AD_Role_ID=103 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:49:23 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=185 AND AD_Role_ID=103 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:49:23 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=187 AND AD_Role_ID=103 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:49:23 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=188 AND AD_Role_ID=103 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:49:23 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=189 AND AD_Role_ID=103 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:49:23 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=345 AND AD_Role_ID=103 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:49:23 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=347 AND AD_Role_ID=103 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:49:23 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=691 AND AD_Role_ID=103 AND C_DocType_ID=50008
;

-- Jan 1, 2009 11:49:23 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=178 AND AD_Role_ID=103 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:49:23 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=179 AND AD_Role_ID=103 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:49:23 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=180 AND AD_Role_ID=103 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:49:23 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=181 AND AD_Role_ID=103 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:49:24 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=182 AND AD_Role_ID=103 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:49:24 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=183 AND AD_Role_ID=103 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:49:24 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=184 AND AD_Role_ID=103 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:49:24 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=185 AND AD_Role_ID=103 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:49:24 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=187 AND AD_Role_ID=103 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:49:24 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=188 AND AD_Role_ID=103 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:49:24 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=189 AND AD_Role_ID=103 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:49:24 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=345 AND AD_Role_ID=103 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:49:24 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=347 AND AD_Role_ID=103 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:49:24 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE AD_Ref_List_ID=691 AND AD_Role_ID=103 AND C_DocType_ID=50009
;

-- Jan 1, 2009 11:52:25 PM ECT
-- Accounting Manufacturing Management
DELETE FROM C_DocType_Trl WHERE C_DocType_ID=50009
;

-- Jan 1, 2009 11:52:25 PM ECT
-- Accounting Manufacturing Management
DELETE FROM C_DocType WHERE C_DocType_ID=50009
;

-- Jan 1, 2009 11:52:25 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE C_DocType_ID=50009
;

-- Jan 1, 2009 11:52:32 PM ECT
-- Accounting Manufacturing Management
DELETE FROM C_DocType_Trl WHERE C_DocType_ID=50005
;

-- Jan 1, 2009 11:52:32 PM ECT
-- Accounting Manufacturing Management
DELETE FROM C_DocType WHERE C_DocType_ID=50005
;

-- Jan 1, 2009 11:52:32 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE C_DocType_ID=50005
;

-- Jan 1, 2009 11:52:38 PM ECT
-- Accounting Manufacturing Management
DELETE FROM C_DocType_Trl WHERE C_DocType_ID=50006
;

-- Jan 1, 2009 11:52:38 PM ECT
-- Accounting Manufacturing Management
DELETE FROM C_DocType WHERE C_DocType_ID=50006
;

-- Jan 1, 2009 11:52:38 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE C_DocType_ID=50006
;

-- Jan 1, 2009 11:52:42 PM ECT
-- Accounting Manufacturing Management
DELETE FROM C_DocType_Trl WHERE C_DocType_ID=50003
;

-- Jan 1, 2009 11:52:42 PM ECT
-- Accounting Manufacturing Management
DELETE FROM C_DocType WHERE C_DocType_ID=50003
;

-- Jan 1, 2009 11:52:42 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE C_DocType_ID=50003
;

-- Jan 1, 2009 11:52:46 PM ECT
-- Accounting Manufacturing Management
DELETE FROM C_DocType_Trl WHERE C_DocType_ID=50004
;

-- Jan 1, 2009 11:52:46 PM ECT
-- Accounting Manufacturing Management
DELETE FROM C_DocType WHERE C_DocType_ID=50004
;

-- Jan 1, 2009 11:52:46 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE C_DocType_ID=50004
;

-- Jan 1, 2009 11:52:49 PM ECT
-- Accounting Manufacturing Management
DELETE FROM C_DocType_Trl WHERE C_DocType_ID=50007
;

-- Jan 1, 2009 11:52:49 PM ECT
-- Accounting Manufacturing Management
DELETE FROM C_DocType WHERE C_DocType_ID=50007
;

-- Jan 1, 2009 11:52:49 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE C_DocType_ID=50007
;

-- Jan 1, 2009 11:52:53 PM ECT
-- Accounting Manufacturing Management
DELETE FROM C_DocType_Trl WHERE C_DocType_ID=50008
;

-- Jan 1, 2009 11:52:53 PM ECT
-- Accounting Manufacturing Management
DELETE FROM C_DocType WHERE C_DocType_ID=50008
;

-- Jan 1, 2009 11:52:53 PM ECT
-- Accounting Manufacturing Management
DELETE FROM AD_Document_Action_Access WHERE C_DocType_ID=50008
;

