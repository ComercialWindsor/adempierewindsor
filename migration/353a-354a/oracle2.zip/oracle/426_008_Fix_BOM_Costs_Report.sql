-- 05.03.2009 14:20:07 EET
-- 
UPDATE AD_PrintFormatItem SET XPosition=0, IsGroupBy='N', IsHeightOneLine='Y', SortNo=0, AD_PrintFormatChild_ID=NULL, IsPageBreak='N', YPosition=0, IsImageField='N',Updated=TO_DATE('2009-03-05 14:20:07','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51000
;

-- 05.03.2009 14:21:52 EET
-- 
UPDATE AD_PrintFormatItem_Trl SET IsTranslated='Y',PrintName='Element',Updated=TO_DATE('2009-03-05 14:21:52','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51002 AND AD_Language='ro_RO'
;

-- 05.03.2009 14:22:10 EET
-- 
UPDATE AD_PrintFormatItem_Trl SET IsTranslated='Y',PrintName='Cost TL',Updated=TO_DATE('2009-03-05 14:22:10','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51005 AND AD_Language='ro_RO'
;

-- 05.03.2009 14:22:19 EET
-- 
UPDATE AD_PrintFormatItem_Trl SET IsTranslated='Y',PrintName='Cost LL',Updated=TO_DATE('2009-03-05 14:22:19','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51006 AND AD_Language='ro_RO'
;

-- 05.03.2009 14:22:26 EET
-- 
UPDATE AD_PrintFormatItem_Trl SET IsTranslated='Y',Updated=TO_DATE('2009-03-05 14:22:26','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51001 AND AD_Language='ro_RO'
;

-- 05.03.2009 14:23:27 EET
-- 
UPDATE AD_PrintFormatItem_Trl SET PrintName='Cost V TL',Updated=TO_DATE('2009-03-05 14:23:27','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51067 AND AD_Language='ro_RO'
;

-- 05.03.2009 14:23:36 EET
-- 
UPDATE AD_PrintFormatItem_Trl SET IsTranslated='Y',PrintName='Cost V LL',Updated=TO_DATE('2009-03-05 14:23:36','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51067 AND AD_Language='ro_RO'
;

-- 05.03.2009 14:23:48 EET
-- 
UPDATE AD_PrintFormatItem_Trl SET IsTranslated='Y',PrintName='Cost V',Updated=TO_DATE('2009-03-05 14:23:48','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51066 AND AD_Language='ro_RO'
;

-- 05.03.2009 14:24:18 EET
-- 
UPDATE AD_PrintFormatItem_Trl SET IsTranslated='Y',PrintName=NULL,Updated=TO_DATE('2009-03-05 14:24:18','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51069 AND AD_Language='ro_RO'
;

-- 05.03.2009 14:24:23 EET
-- 
UPDATE AD_PrintFormatItem_Trl SET PrintName=' ',Updated=TO_DATE('2009-03-05 14:24:23','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51069 AND AD_Language='ro_RO'
;

-- 05.03.2009 14:25:19 EET
-- 
UPDATE AD_PrintFormatItem_Trl SET IsTranslated='Y',PrintName='Cost Std',Updated=TO_DATE('2009-03-05 14:25:19','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51068 AND AD_Language='ro_RO'
;

-- 05.03.2009 14:26:29 EET
-- 
UPDATE AD_PrintFormatItem_Trl SET IsTranslated='Y',PrintName='N',Updated=TO_DATE('2009-03-05 14:26:29','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51013 AND AD_Language='ro_RO'
;

-- 05.03.2009 14:26:39 EET
-- 
UPDATE AD_PrintFormatItem SET XPosition=0, IsGroupBy='N', SortNo=0, AD_PrintFormatChild_ID=NULL, IsPageBreak='N', YPosition=0, IsCentrallyMaintained='N', IsImageField='N',Updated=TO_DATE('2009-03-05 14:26:39','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51013
;

-- 05.03.2009 14:26:54 EET
-- 
UPDATE AD_PrintFormatItem_Trl SET IsTranslated='Y',PrintName='Tip',Updated=TO_DATE('2009-03-05 14:26:54','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51000 AND AD_Language='ro_RO'
;

-- 05.03.2009 14:27:07 EET
-- 
UPDATE AD_PrintFormatItem_Trl SET IsTranslated='Y',PrintName='Cant.',Updated=TO_DATE('2009-03-05 14:27:07','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51019 AND AD_Language='ro_RO'
;

-- 05.03.2009 14:27:14 EET
-- 
UPDATE AD_PrintFormatItem_Trl SET IsTranslated='Y',Updated=TO_DATE('2009-03-05 14:27:14','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51021 AND AD_Language='ro_RO'
;

-- 05.03.2009 14:27:21 EET
-- 
UPDATE AD_PrintFormatItem_Trl SET IsTranslated='Y',PrintName='Rebut%',Updated=TO_DATE('2009-03-05 14:27:21','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=50994 AND AD_Language='ro_RO'
;

-- 05.03.2009 14:27:39 EET
-- 
UPDATE AD_PrintFormatItem_Trl SET PrintName='Cantitate',Updated=TO_DATE('2009-03-05 14:27:39','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51019 AND AD_Language='ro_RO'
;

-- 05.03.2009 14:28:03 EET
-- 
UPDATE AD_Element_Trl SET Name='Rebut%',PrintName='Rebut%',Updated=TO_DATE('2009-03-05 14:28:03','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53257 AND AD_Language='ro_RO'
;

-- 05.03.2009 14:28:10 EET
-- 
UPDATE AD_Element_Trl SET Name='Rebut %',PrintName='Rebut %',Updated=TO_DATE('2009-03-05 14:28:10','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53257 AND AD_Language='ro_RO'
;

-- 05.03.2009 14:28:17 EET
-- 
UPDATE AD_PrintFormatItem_Trl SET PrintName='Rebut %',Updated=TO_DATE('2009-03-05 14:28:17','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=50994 AND AD_Language='ro_RO'
;

-- 05.03.2009 14:28:46 EET
-- 
UPDATE AD_Element_Trl SET PrintName='Element',Updated=TO_DATE('2009-03-05 14:28:46','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=2700 AND AD_Language='ro_RO'
;

-- 05.03.2009 14:30:40 EET
-- 
UPDATE AD_PrintFormatItem SET XPosition=0, IsHeightOneLine='Y', AD_PrintFormatChild_ID=NULL, YPosition=0, IsImageField='N',Updated=TO_DATE('2009-03-05 14:30:40','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51017
;

-- 05.03.2009 14:30:51 EET
-- 
UPDATE AD_PrintFormatItem SET XPosition=0, IsGroupBy='N', IsHeightOneLine='Y', SortNo=0, AD_PrintFormatChild_ID=NULL, IsPageBreak='N', YPosition=0, IsImageField='N',Updated=TO_DATE('2009-03-05 14:30:51','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51021
;

-- 05.03.2009 14:31:54 EET
-- 
UPDATE AD_PrintFormatItem SET SeqNo=120,IsPrinted='Y' WHERE AD_PrintFormatItem_ID=51066
;

-- 05.03.2009 14:31:54 EET
-- 
UPDATE AD_PrintFormatItem SET SeqNo=130,IsPrinted='Y' WHERE AD_PrintFormatItem_ID=51067
;

-- 05.03.2009 14:31:54 EET
-- 
UPDATE AD_PrintFormatItem SET SeqNo=140,IsPrinted='Y' WHERE AD_PrintFormatItem_ID=51069
;

-- 05.03.2009 14:37:16 EET
-- 
UPDATE AD_PrintFormatItem_Trl SET PrintName='I',Updated=TO_DATE('2009-03-05 14:37:16','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51069 AND AD_Language='ro_RO'
;

-- 05.03.2009 15:07:13 EET
-- 
UPDATE AD_Process_Trl SET IsTranslated='Y',Name='Costuri BOM',Description='Raportul afiseaza costurile pe fiecare element de cost in cadrul unui BOM pe mai multe nivele',Help=NULL,Updated=TO_DATE('2009-03-05 15:07:13','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Process_ID=53159 AND AD_Language='ro_RO'
;

-- 05.03.2009 15:09:11 EET
-- 
UPDATE AD_PrintFormatItem SET SeqNo=0,IsPrinted='N' WHERE AD_PrintFormatItem_ID=51068
;

-- 05.03.2009 15:09:11 EET
-- 
UPDATE AD_PrintFormatItem SET SeqNo=110,IsPrinted='Y' WHERE AD_PrintFormatItem_ID=51066
;

-- 05.03.2009 15:09:11 EET
-- 
UPDATE AD_PrintFormatItem SET SeqNo=120,IsPrinted='Y' WHERE AD_PrintFormatItem_ID=51067
;

-- 05.03.2009 15:09:11 EET
-- 
UPDATE AD_PrintFormatItem SET SeqNo=130,IsPrinted='Y' WHERE AD_PrintFormatItem_ID=51069
;

-- 05.03.2009 15:09:28 EET
-- 
UPDATE AD_PrintFormatItem SET XPosition=0, IsGroupBy='N', SortNo=0, AD_PrintFormatChild_ID=NULL, IsPageBreak='N', YPosition=0, IsCentrallyMaintained='N', IsImageField='N',Updated=TO_DATE('2009-03-05 15:09:28','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51001
;

-- 05.03.2009 15:09:32 EET
-- 
UPDATE AD_PrintFormatItem_Trl SET PrintName='Cost T',Updated=TO_DATE('2009-03-05 15:09:32','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51001 AND AD_Language='ro_RO'
;

-- 05.03.2009 15:10:09 EET
-- 
UPDATE AD_PrintFormatItem SET XPosition=0, IsGroupBy='N', SortNo=0, AD_PrintFormatChild_ID=NULL, Name='Cost T', PrintName='Cost T', IsPageBreak='N', YPosition=0, IsImageField='N',Updated=TO_DATE('2009-03-05 15:10:09','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51001
;

-- 05.03.2009 15:10:09 EET
-- 
UPDATE AD_PrintFormatItem_Trl SET IsTranslated='N' WHERE AD_PrintFormatItem_ID=51001
;

-- 05.03.2009 15:10:19 EET
-- 
UPDATE AD_PrintFormatItem_Trl SET IsTranslated='Y',Updated=TO_DATE('2009-03-05 15:10:19','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_PrintFormatItem_ID=51001 AND AD_Language='ro_RO'
;

