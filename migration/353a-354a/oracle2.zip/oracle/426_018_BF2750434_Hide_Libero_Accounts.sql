-- 10.04.2009 17:30:19 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@#IsLiberoEnabled@=Y',Updated=TO_DATE('2009-04-10 17:30:17','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56549
;

-- 10.04.2009 17:30:25 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@#IsLiberoEnabled@=Y',Updated=TO_DATE('2009-04-10 17:30:25','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56542
;

-- 10.04.2009 17:30:40 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@#IsLiberoEnabled@=Y & @ProductType@=''R''',Updated=TO_DATE('2009-04-10 17:30:40','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56543
;

-- 10.04.2009 17:30:44 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@#IsLiberoEnabled@=Y & @ProductType@=''R''',Updated=TO_DATE('2009-04-10 17:30:44','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56540
;

-- 10.04.2009 17:30:47 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@#IsLiberoEnabled@=Y & @ProductType@=''R''',Updated=TO_DATE('2009-04-10 17:30:47','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56541
;

-- 10.04.2009 17:30:51 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@#IsLiberoEnabled@=Y & @ProductType@=''R''',Updated=TO_DATE('2009-04-10 17:30:51','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56546
;

-- 10.04.2009 17:30:54 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@#IsLiberoEnabled@=Y & @ProductType@=''R''',Updated=TO_DATE('2009-04-10 17:30:54','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56554
;

-- 10.04.2009 17:30:58 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@#IsLiberoEnabled@=Y & @ProductType@=''R''',Updated=TO_DATE('2009-04-10 17:30:58','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56555
;

-- 10.04.2009 17:31:40 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@IsBOM@=''Y'' | @ProductType@=''S'' & @#IsLiberoEnabled@=Y',Updated=TO_DATE('2009-04-10 17:31:40','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56544
;

-- 10.04.2009 17:31:45 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@IsBOM@=''Y'' | @ProductType@=''S'' & @#IsLiberoEnabled@=Y',Updated=TO_DATE('2009-04-10 17:31:45','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56548
;

-- 10.04.2009 17:31:49 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@IsBOM@=''Y'' | @ProductType@=''S'' & @#IsLiberoEnabled@=Y',Updated=TO_DATE('2009-04-10 17:31:49','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56547
;

-- 10.04.2009 17:31:52 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@IsBOM@=''Y'' | @ProductType@=''S'' & @#IsLiberoEnabled@=Y',Updated=TO_DATE('2009-04-10 17:31:52','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56545
;

-- 10.04.2009 17:32:48 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@#IsLiberoEnabled@=Y',Updated=TO_DATE('2009-04-10 17:32:48','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56539
;

-- 10.04.2009 17:32:50 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@#IsLiberoEnabled@=Y',Updated=TO_DATE('2009-04-10 17:32:50','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56532
;

-- 10.04.2009 17:32:53 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@#IsLiberoEnabled@=Y',Updated=TO_DATE('2009-04-10 17:32:53','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56534
;

-- 10.04.2009 17:32:56 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@#IsLiberoEnabled@=Y',Updated=TO_DATE('2009-04-10 17:32:56','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56538
;

-- 10.04.2009 17:32:59 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@#IsLiberoEnabled@=Y',Updated=TO_DATE('2009-04-10 17:32:59','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56537
;

-- 10.04.2009 17:33:01 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@#IsLiberoEnabled@=Y',Updated=TO_DATE('2009-04-10 17:33:01','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56535
;

-- 10.04.2009 17:33:05 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@#IsLiberoEnabled@=Y',Updated=TO_DATE('2009-04-10 17:33:05','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56533
;

-- 10.04.2009 17:33:08 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@#IsLiberoEnabled@=Y',Updated=TO_DATE('2009-04-10 17:33:08','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56530
;

-- 10.04.2009 17:33:11 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@#IsLiberoEnabled@=Y',Updated=TO_DATE('2009-04-10 17:33:11','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56531
;

-- 10.04.2009 17:33:13 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@#IsLiberoEnabled@=Y',Updated=TO_DATE('2009-04-10 17:33:13','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56536
;

-- 10.04.2009 17:33:16 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@#IsLiberoEnabled@=Y',Updated=TO_DATE('2009-04-10 17:33:16','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56552
;

-- 10.04.2009 17:33:18 EEST
-- 
UPDATE AD_Field SET DisplayLogic='@#IsLiberoEnabled@=Y',Updated=TO_DATE('2009-04-10 17:33:18','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56553
;

-- 10.04.2009 17:36:32 EEST
-- 
UPDATE AD_Field SET AD_FieldGroup_ID=114,Updated=TO_DATE('2009-04-10 17:36:32','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=3945
;

