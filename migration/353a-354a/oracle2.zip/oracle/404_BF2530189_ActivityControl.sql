-- Jan 27, 2009 12:39:32 AM ECT
-- Remove material issues and receipt from Activity Control
UPDATE AD_Tab SET WhereClause='CostCollectorType=''160''',Updated=TO_DATE('2009-01-27 00:39:32','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Tab_ID=53049
;

