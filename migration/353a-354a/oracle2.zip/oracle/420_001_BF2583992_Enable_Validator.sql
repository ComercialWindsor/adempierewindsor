-- Feb 10, 2009 11:27:30 PM EET
-- 
UPDATE AD_ModelValidator SET IsActive='Y', SeqNo=1,Updated=TO_DATE('2009-02-10 23:27:30','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_ModelValidator_ID=50000
;

