-- Aug 1, 2009 12:04:23 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=225
;

-- Aug 1, 2009 12:04:23 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53202
;

-- Aug 1, 2009 12:04:23 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=261
;

-- Aug 1, 2009 12:04:23 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=148
;

-- Aug 1, 2009 12:04:23 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=529
;

-- Aug 1, 2009 12:04:23 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=397
;

-- Aug 1, 2009 12:04:23 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=530
;

-- Aug 1, 2009 12:04:23 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=53108, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=531
;

-- Aug 1, 2009 12:04:23 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=53108, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53109
;

-- Aug 1, 2009 12:04:23 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=53108, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53114
;

-- Aug 1, 2009 12:04:34 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=225
;

-- Aug 1, 2009 12:04:34 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53202
;

-- Aug 1, 2009 12:04:34 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=261
;

-- Aug 1, 2009 12:04:34 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=148
;

-- Aug 1, 2009 12:04:34 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=529
;

-- Aug 1, 2009 12:04:34 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=397
;

-- Aug 1, 2009 12:04:34 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=53108, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=531
;

-- Aug 1, 2009 12:04:34 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=53108, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=530
;

-- Aug 1, 2009 12:04:34 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=53108, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53109
;

-- Aug 1, 2009 12:04:34 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=53108, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53114
;

-- Aug 1, 2009 12:04:49 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=225
;

-- Aug 1, 2009 12:04:49 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=261
;

-- Aug 1, 2009 12:04:49 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53202
;

-- Aug 1, 2009 12:04:49 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=148
;

-- Aug 1, 2009 12:04:49 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=529
;

-- Aug 1, 2009 12:04:49 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=397
;

-- Aug 1, 2009 12:04:56 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53202
;

-- Aug 1, 2009 12:04:56 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=225
;

-- Aug 1, 2009 12:04:56 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=261
;

-- Aug 1, 2009 12:04:56 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=148
;

-- Aug 1, 2009 12:04:56 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=529
;

-- Aug 1, 2009 12:04:56 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=397
;

-- Aug 1, 2009 12:05:06 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=261
;

-- Aug 1, 2009 12:05:06 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53202
;

-- Aug 1, 2009 12:05:06 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=225
;

-- Aug 1, 2009 12:05:06 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=148
;

-- Aug 1, 2009 12:05:06 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=529
;

-- Aug 1, 2009 12:05:06 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=156, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=397
;


-- Aug 1, 2009 12:19:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=163, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=222
;

-- Aug 1, 2009 12:19:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=163, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=223
;

-- Aug 1, 2009 12:19:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=163, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=185
;

-- Aug 1, 2009 12:19:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=163, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=340
;

-- Aug 1, 2009 12:19:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=163, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53206
;

-- Aug 1, 2009 12:19:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=163, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=339
;

-- Aug 1, 2009 12:19:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=163, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=338
;

-- Aug 1, 2009 12:19:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=163, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=363
;

-- Aug 1, 2009 12:19:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=163, SeqNo=8, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=376
;

-- Aug 1, 2009 12:19:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=163, SeqNo=9, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=382
;

-- Aug 1, 2009 12:19:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=163, SeqNo=10, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=486
;

-- Aug 1, 2009 12:19:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=163, SeqNo=11, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=425
;

-- Aug 1, 2009 12:19:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=163, SeqNo=12, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=378
;

-- Aug 1, 2009 12:19:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=163, SeqNo=13, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=374
;

-- Aug 1, 2009 12:19:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=163, SeqNo=14, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=423
;

-- Aug 1, 2009 12:19:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=163, SeqNo=15, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=373
;

-- Aug 1, 2009 12:19:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=163, SeqNo=16, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=424
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=165
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=372
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=271
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=528
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=237
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=544
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=512
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=414
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=8, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=238
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=9, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=396
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=266
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=232
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=190
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=127
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=133
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=172
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=110
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=394
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=8, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=506
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=9, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=420
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=10, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=451
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=11, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=476
;

-- Aug 1, 2009 12:24:14 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=12, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=473
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=165
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=372
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=271
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=528
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=237
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=512
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=414
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=238
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=8, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=396
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=266
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=232
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=190
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=127
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=133
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=172
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=110
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=394
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=8, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=544
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=9, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=506
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=10, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=420
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=11, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=451
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=12, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=476
;

-- Aug 1, 2009 12:24:29 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=13, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=473
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=165
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=372
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=271
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=528
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=237
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=414
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=238
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=263, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=396
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=266
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=232
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=190
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=127
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=133
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=172
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=110
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=394
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=8, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=544
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=9, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=512
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=10, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=506
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=11, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=420
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=12, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=451
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=13, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=476
;

-- Aug 1, 2009 12:24:36 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=14, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=473
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=266
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=232
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=190
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=127
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=133
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=172
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=110
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=394
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=8, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=544
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=9, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=512
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=10, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=506
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=11, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=420
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=12, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=451
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=165, SeqNo=13, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=473
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=265
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=104
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=105
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=384
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=111
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=106
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=117
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=418
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=8, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=102
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=9, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=103
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=10, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=270
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=11, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=121
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=12, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=476
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=13, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=409
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=14, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=151
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=15, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53087
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=16, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=464
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=17, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=124
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=18, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=123
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=19, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=547
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=20, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53189
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=21, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=174
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=22, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=254
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=23, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=120
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=24, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=135
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=25, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=550
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=26, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=551
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=27, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=306
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=28, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=53091
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=29, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=417
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=30, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=307
;

-- Aug 1, 2009 12:27:16 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=164, SeqNo=31, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=393
;

-- Aug 1, 2009 12:27:51 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=175, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=441
;

-- Aug 1, 2009 12:27:51 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=175, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=149
;

-- Aug 1, 2009 12:27:51 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=175, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=50010
;

-- Aug 1, 2009 12:27:51 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=175, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=171
;

-- Aug 1, 2009 12:27:51 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=175, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=437
;

-- Aug 1, 2009 12:27:51 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=175, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=240
;

-- Aug 1, 2009 12:27:51 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=175, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=361
;

-- Aug 1, 2009 12:29:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=53133, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=431
;

-- Aug 1, 2009 12:29:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=53133, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=430
;

-- Aug 1, 2009 12:29:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=53133, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=474
;

-- Aug 1, 2009 12:29:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=53133, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=400
;

-- Aug 1, 2009 12:29:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=53133, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=399
;

-- Aug 1, 2009 12:29:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=53133, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=348
;

-- Aug 1, 2009 12:29:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=367, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=147
;

-- Aug 1, 2009 12:29:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=367, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=487
;

-- Aug 1, 2009 12:29:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=367, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=150
;

-- Aug 1, 2009 12:29:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=367, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=495
;

-- Aug 1, 2009 12:29:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=367, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=50007
;

-- Aug 1, 2009 12:29:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=367, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=362
;

-- Aug 1, 2009 12:29:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=367, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=475
;

-- Aug 1, 2009 12:29:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=367, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=366
;

-- Aug 1, 2009 12:29:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=367, SeqNo=8, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=483
;

-- Aug 1, 2009 12:29:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=367, SeqNo=9, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=368
;

-- Aug 1, 2009 12:29:45 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=367, SeqNo=10, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=508
;

-- Aug 1, 2009 12:31:47 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=271, SeqNo=0, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=319
;

-- Aug 1, 2009 12:31:47 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=271, SeqNo=1, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=369
;

-- Aug 1, 2009 12:31:47 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=271, SeqNo=2, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=317
;

-- Aug 1, 2009 12:31:47 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=271, SeqNo=3, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=318
;

-- Aug 1, 2009 12:31:47 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=271, SeqNo=4, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=327
;

-- Aug 1, 2009 12:31:47 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=271, SeqNo=5, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=328
;

-- Aug 1, 2009 12:31:47 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=271, SeqNo=6, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=349
;

-- Aug 1, 2009 12:31:47 PM EEST
-- FR-2830755 Re-Organize menu items
UPDATE AD_TreeNodeMM SET Parent_ID=271, SeqNo=7, Updated=SysDate WHERE AD_Tree_ID=10 AND Node_ID=329
;

