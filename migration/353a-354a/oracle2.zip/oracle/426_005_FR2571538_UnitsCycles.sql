-- Feb 24, 2009 11:04:25 AM EET
-- 
UPDATE AD_Column SET Callout='org.eevolution.model.CalloutCostCollector.duration',Updated=TO_DATE('2009-02-24 11:04:23','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Column_ID=53826
;

