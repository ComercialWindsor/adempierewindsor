-- Feb 17, 2009 9:21:53 PM EET
-- 
UPDATE AD_Table SET AccessLevel='1',Updated=TO_DATE('2009-02-17 21:21:51','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=702
;

-- Feb 17, 2009 9:22:06 PM EET
-- 
UPDATE AD_Table SET AccessLevel='1',Updated=TO_DATE('2009-02-17 21:22:06','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=703
;

