-- Aug 9, 2009 11:49:40 AM EEST
-- BF [2834402] - Wrong Reference type for Partner Category column
UPDATE AD_Column SET AD_Reference_ID=10,Updated=TO_DATE('2009-08-09 11:49:40','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=2710
;

