-- Jul 13, 2009 6:48:55 PM CEST
-- [2820886] Wrong Reference type of Manufacturer field
UPDATE AD_Column SET AD_Reference_ID=10,Updated=TO_DATE('2009-07-13 18:48:55','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=7965
;

