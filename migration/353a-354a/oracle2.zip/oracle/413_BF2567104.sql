-- Feb 5, 2009 3:03:17 PM MYT
-- [ 2567104 ] Inventory move should allow movement between ASI
UPDATE AD_Field SET IsReadOnly='N',Updated=TO_DATE('2009-02-05 15:03:17','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=12097
;
