-- Sep 5, 2009 11:51:35 AM EST
-- BF2852048 Views with IsView set to N
UPDATE AD_Table SET IsView='Y',Updated=TO_DATE('2009-09-05 11:51:35','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Table_ID=53198
;

-- Sep 5, 2009 11:51:38 AM EST
-- BF2852048 Views with IsView set to N
UPDATE AD_Table SET IsView='Y',Updated=TO_DATE('2009-09-05 11:51:38','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Table_ID=53205
;

-- Sep 5, 2009 11:51:41 AM EST
-- BF2852048 Views with IsView set to N
UPDATE AD_Table SET IsView='Y',Updated=TO_DATE('2009-09-05 11:51:41','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Table_ID=53200
;

-- Sep 5, 2009 11:51:44 AM EST
-- BF2852048 Views with IsView set to N
UPDATE AD_Table SET IsView='Y',Updated=TO_DATE('2009-09-05 11:51:44','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Table_ID=53199
;

