-- May 19, 2009 1:25:01 PM EEST
-- -
UPDATE AD_Table SET AccessLevel='7',Updated=TO_DATE('2009-05-19 13:25:01','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53090
;

