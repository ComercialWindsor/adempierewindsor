-- Jun 11, 2009 3:50:57 PM CEST
-- Hide non working Replication functionality.
UPDATE AD_Process SET IsActive='N',Updated=TO_DATE('2009-06-11 15:50:57','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_ID=53089
;

-- Jun 11, 2009 3:50:57 PM CEST
-- Hide non working Replication functionality.
UPDATE AD_Menu SET IsActive='N', Name='Test Export Model', Description='Test Export of XML files',Updated=TO_DATE('2009-06-11 15:50:57','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Menu_ID=53130
;

-- Jun 11, 2009 3:55:02 PM CEST
-- Hide non working Replication functionality.
UPDATE AD_Field SET IsActive='N',Updated=TO_DATE('2009-06-11 15:55:02','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=55417
;

-- Jun 11, 2009 4:04:34 PM CEST
-- Hide non working Replication functionality.
UPDATE AD_Field SET IsEncrypted='Y',Updated=TO_DATE('2009-06-11 16:04:34','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=54648
;

-- Jun 11, 2009 4:16:19 PM CEST
-- Hide non working Replication functionality.
UPDATE AD_Field SET IsEncrypted='Y',Updated=TO_DATE('2009-06-11 16:16:19','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=54611
;

-- Jun 11, 2009 4:17:15 PM CEST
-- Hide non working Replication functionality.
UPDATE AD_Process SET IsActive='N',Updated=TO_DATE('2009-06-11 16:17:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_ID=53085
;

-- Jun 11, 2009 4:17:15 PM CEST
-- Hide non working Replication functionality.
UPDATE AD_Menu SET IsActive='N', Name='Export Format Generator', Description='Create multiple Export Format based in a Window',Updated=TO_DATE('2009-06-11 16:17:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Menu_ID=53125
;

