-- 05.03.2009 21:51:10 EET
-- [ 2664599 ] Fix CreateCostElement process parameters
UPDATE AD_Tab SET IsInsertRecord='N',Updated=TO_DATE('2009-03-05 21:51:10','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Tab_ID=53032
;

