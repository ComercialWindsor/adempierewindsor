-- 15.07.2009 10:04:45 EEST
-- 
UPDATE AD_Field SET SeqNo=340,IsDisplayed='Y' WHERE AD_Field_ID=56684
;

-- 15.07.2009 10:05:13 EEST
-- 
UPDATE AD_Field SET IsSameLine='Y', IsReadOnly='Y',Updated=TO_DATE('2009-07-15 10:05:13','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56684
;

