-- Apr 23, 2009 7:58:44 PM COT
-- Advanced Search
UPDATE AD_Field SET SeqNo=10,IsDisplayed='Y' WHERE AD_Field_ID=56704
;

-- Apr 23, 2009 7:58:44 PM COT
-- Advanced Search
UPDATE AD_Field SET SeqNo=20,IsDisplayed='Y' WHERE AD_Field_ID=56709
;

-- Apr 23, 2009 7:58:44 PM COT
-- Advanced Search
UPDATE AD_Field SET SeqNo=30,IsDisplayed='Y' WHERE AD_Field_ID=56713
;

-- Apr 23, 2009 7:58:44 PM COT
-- Advanced Search
UPDATE AD_Field SET SeqNo=40,IsDisplayed='Y' WHERE AD_Field_ID=56708
;

-- Apr 23, 2009 7:58:44 PM COT
-- Advanced Search
UPDATE AD_Field SET SeqNo=50,IsDisplayed='Y' WHERE AD_Field_ID=56707
;

-- Apr 23, 2009 7:58:44 PM COT
-- Advanced Search
UPDATE AD_Field SET SeqNo=60,IsDisplayed='Y' WHERE AD_Field_ID=56702
;

-- Apr 23, 2009 7:58:44 PM COT
-- Advanced Search
UPDATE AD_Field SET SeqNo=70,IsDisplayed='Y' WHERE AD_Field_ID=56718
;

-- Apr 23, 2009 7:58:44 PM COT
-- Advanced Search
UPDATE AD_Field SET SeqNo=80,IsDisplayed='Y' WHERE AD_Field_ID=56711
;

-- Apr 23, 2009 7:58:44 PM COT
-- Advanced Search
UPDATE AD_Field SET SeqNo=90,IsDisplayed='Y' WHERE AD_Field_ID=56712
;

-- Apr 23, 2009 7:58:44 PM COT
-- Advanced Search
UPDATE AD_Field SET SeqNo=100,IsDisplayed='Y' WHERE AD_Field_ID=56705
;

-- Apr 23, 2009 7:58:44 PM COT
-- Advanced Search
UPDATE AD_Field SET SeqNo=110,IsDisplayed='Y' WHERE AD_Field_ID=56710
;

-- Apr 23, 2009 7:58:44 PM COT
-- Advanced Search
UPDATE AD_Field SET SeqNo=120,IsDisplayed='Y' WHERE AD_Field_ID=56706
;

-- Apr 23, 2009 7:58:44 PM COT
-- Advanced Search
UPDATE AD_Field SET SeqNo=130,IsDisplayed='Y' WHERE AD_Field_ID=56714
;

-- Apr 23, 2009 7:58:44 PM COT
-- Advanced Search
UPDATE AD_Field SET SeqNo=140,IsDisplayed='Y' WHERE AD_Field_ID=56717
;

-- Apr 23, 2009 7:58:54 PM COT
-- Advanced Search
UPDATE AD_Field SET IsSameLine='Y',Updated=TO_DATE('2009-04-23 19:58:54','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=56709
;

