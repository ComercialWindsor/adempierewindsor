-- 16.04.2009 17:57:33 EEST
-- 
UPDATE AD_Column SET DefaultValue='@#AD_Client_ID@',Updated=TO_DATE('2009-04-16 17:57:30','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Column_ID=434
;

-- 16.04.2009 17:58:02 EEST
-- 
UPDATE AD_Column SET DefaultValue='@#AD_Client_ID@',Updated=TO_DATE('2009-04-16 17:58:02','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Column_ID=755
;

