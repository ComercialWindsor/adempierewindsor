-- 07.07.2009 11:45:51 EEST
-- 
UPDATE AD_Field SET DisplayLength=10, IsReadOnly='N',Updated=TO_DATE('2009-07-07 11:45:44','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53594
;

