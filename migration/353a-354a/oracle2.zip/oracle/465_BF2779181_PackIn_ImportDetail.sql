-- 12/05/2009 16:04:45
UPDATE AD_Column SET IsKey='Y', IsParent='N', IsUpdateable='N',Updated=TO_DATE('2009-05-12 16:04:45','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=50065
;

