-- Feb 6, 2009 6:24:58 PM ECT
-- Fix DocType Purchase Order
UPDATE C_DocType SET IsDefault='Y',Updated=TO_DATE('2009-02-06 18:24:58','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_DocType_ID=126
;

