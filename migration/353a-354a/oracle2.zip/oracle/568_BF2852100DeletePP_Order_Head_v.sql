-- Sep 11, 2009 5:18:43 PM COT
-- BF2852100-PP_Order_Head_v has columns wrongly defined
DELETE  FROM  AD_Table_Trl WHERE AD_Table_ID=53196
;

-- Sep 11, 2009 5:18:44 PM COT
DELETE FROM AD_Table WHERE AD_Table_ID=53196
;
