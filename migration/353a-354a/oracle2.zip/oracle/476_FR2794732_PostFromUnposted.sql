
UPDATE AD_Column SET AD_Reference_ID=28, AD_Reference_Value_ID=NULL,Updated=TO_DATE('2009-06-02 11:32:10','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=56347
;

