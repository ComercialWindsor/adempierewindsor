-- Aug 27, 2009 12:37:51 AM EEST
-- BF: [2845487] - Wrong Subscription reference 
UPDATE AD_Column SET AD_Reference_ID=19,Updated=TO_DATE('2009-08-27 00:37:51','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=10919
;

-- Aug 27, 2009 12:43:03 AM EEST
-- BF: [2845487] - Wrong Subscription reference
UPDATE AD_Field SET IsDisplayed='N', SeqNo=0,Updated=TO_DATE('2009-08-27 00:43:03','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=9492
;

-- Aug 27, 2009 12:54:57 AM EEST
-- BF: [2845487] - Wrong Subscription reference
UPDATE AD_Field SET IsReadOnly='N',Updated=TO_DATE('2009-08-27 00:54:57','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=9476
;

