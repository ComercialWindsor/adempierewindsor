-- Jul 14, 2009 4:02:38 AM MYT
-- FR [2723091] Sponsored Development: Promotions
INSERT INTO AD_Sequence (AD_Client_ID,AD_Org_ID,AD_Sequence_ID,Created,CreatedBy,CurrentNext,CurrentNextSys,IncrementNo,IsActive,IsAudited,IsAutoSequence,IsTableID,Name,StartNewYear,StartNo,Updated,UpdatedBy) VALUES (0,0,53326,TO_DATE('2009-07-14 04:02:35','YYYY-MM-DD HH24:MI:SS'),100,1000000,100,1,'Y','N','Y','Y','M_PromotionDistribution','N',1000000,TO_DATE('2009-07-14 04:02:35','YYYY-MM-DD HH24:MI:SS'),100)
;

-- Jul 14, 2009 4:03:08 AM MYT
-- FR [2723091] Sponsored Development: Promotions
UPDATE AD_Sequence SET Description='Table M_PromotionDistribution',Updated=TO_DATE('2009-07-14 04:03:08','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Sequence_ID=53326
;

-- Jul 14, 2009 4:03:39 AM MYT
-- FR [2723091] Sponsored Development: Promotions
INSERT INTO AD_Sequence (AD_Client_ID,AD_Org_ID,AD_Sequence_ID,Created,CreatedBy,CurrentNext,CurrentNextSys,Description,IncrementNo,IsActive,IsAudited,IsAutoSequence,IsTableID,Name,StartNewYear,StartNo,Updated,UpdatedBy) VALUES (0,0,53327,TO_DATE('2009-07-14 04:03:37','YYYY-MM-DD HH24:MI:SS'),100,1000000,100,'Table M_PromotionGroup',1,'Y','N','Y','Y','M_PromotionGroup','N',1000000,TO_DATE('2009-07-14 04:03:37','YYYY-MM-DD HH24:MI:SS'),100)
;

-- Jul 14, 2009 4:04:20 AM MYT
-- FR [2723091] Sponsored Development: Promotions
INSERT INTO AD_Sequence (AD_Client_ID,AD_Org_ID,AD_Sequence_ID,Created,CreatedBy,CurrentNext,CurrentNextSys,Description,IncrementNo,IsActive,IsAudited,IsAutoSequence,IsTableID,Name,StartNewYear,StartNo,Updated,UpdatedBy) VALUES (0,0,53328,TO_DATE('2009-07-14 04:04:19','YYYY-MM-DD HH24:MI:SS'),100,1000000,100,'Table M_PromotionReward',1,'Y','N','Y','Y','M_PromotionReward','N',1000000,TO_DATE('2009-07-14 04:04:19','YYYY-MM-DD HH24:MI:SS'),100)
;

