-- Aug 18, 2009 7:17:15 PM COT
-- [ adempiere-Libero-2839974 ] Not zoom for payroll period
UPDATE AD_Table SET AD_Window_ID=53038,Updated=TO_DATE('2009-08-18 19:17:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Table_ID=53094
;

