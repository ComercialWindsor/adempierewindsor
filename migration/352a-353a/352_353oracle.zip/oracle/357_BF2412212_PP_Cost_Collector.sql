-- 11.12.2008 17:17:55 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=280,IsDisplayed='Y' WHERE AD_Field_ID=53971
;

-- 11.12.2008 17:17:55 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=290,IsDisplayed='Y' WHERE AD_Field_ID=53972
;

-- 11.12.2008 17:17:55 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=300,IsDisplayed='Y' WHERE AD_Field_ID=53969
;

-- 11.12.2008 17:17:55 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=310,IsDisplayed='Y' WHERE AD_Field_ID=53975
;

-- 11.12.2008 17:17:55 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=320,IsDisplayed='Y' WHERE AD_Field_ID=53973
;

-- 11.12.2008 17:17:55 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=330,IsDisplayed='Y' WHERE AD_Field_ID=53968
;

-- 11.12.2008 17:17:56 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=340,IsDisplayed='Y' WHERE AD_Field_ID=53966
;

-- 11.12.2008 17:17:56 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=350,IsDisplayed='Y' WHERE AD_Field_ID=53967
;

-- 11.12.2008 17:19:37 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLogic='@#AD_Client_ID@', IsReadOnly='Y',Updated=TO_DATE('2008-12-11 17:19:37','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53976
;

-- 11.12.2008 17:20:12 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53980
;

-- 11.12.2008 17:20:12 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=50,IsDisplayed='Y' WHERE AD_Field_ID=53981
;

-- 11.12.2008 17:20:12 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=60,IsDisplayed='Y' WHERE AD_Field_ID=53982
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=70,IsDisplayed='Y' WHERE AD_Field_ID=53983
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=80,IsDisplayed='Y' WHERE AD_Field_ID=53984
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=90,IsDisplayed='Y' WHERE AD_Field_ID=53985
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=100,IsDisplayed='Y' WHERE AD_Field_ID=53986
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=110,IsDisplayed='Y' WHERE AD_Field_ID=53987
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=120,IsDisplayed='Y' WHERE AD_Field_ID=53988
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=130,IsDisplayed='Y' WHERE AD_Field_ID=53989
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=140,IsDisplayed='Y' WHERE AD_Field_ID=53990
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=150,IsDisplayed='Y' WHERE AD_Field_ID=53991
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=160,IsDisplayed='Y' WHERE AD_Field_ID=53992
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=170,IsDisplayed='Y' WHERE AD_Field_ID=53993
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=180,IsDisplayed='Y' WHERE AD_Field_ID=53994
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=190,IsDisplayed='Y' WHERE AD_Field_ID=53995
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=200,IsDisplayed='Y' WHERE AD_Field_ID=53996
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=210,IsDisplayed='Y' WHERE AD_Field_ID=53997
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=220,IsDisplayed='Y' WHERE AD_Field_ID=53998
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=230,IsDisplayed='Y' WHERE AD_Field_ID=53999
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=240,IsDisplayed='Y' WHERE AD_Field_ID=54000
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=250,IsDisplayed='Y' WHERE AD_Field_ID=54001
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=260,IsDisplayed='Y' WHERE AD_Field_ID=54002
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=270,IsDisplayed='Y' WHERE AD_Field_ID=53971
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=280,IsDisplayed='Y' WHERE AD_Field_ID=53972
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=290,IsDisplayed='Y' WHERE AD_Field_ID=53969
;

-- 11.12.2008 17:20:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=300,IsDisplayed='Y' WHERE AD_Field_ID=53975
;

-- 11.12.2008 17:20:14 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=310,IsDisplayed='Y' WHERE AD_Field_ID=53973
;

-- 11.12.2008 17:20:14 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=320,IsDisplayed='Y' WHERE AD_Field_ID=53968
;

-- 11.12.2008 17:20:14 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=330,IsDisplayed='Y' WHERE AD_Field_ID=53966
;

-- 11.12.2008 17:20:14 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=340,IsDisplayed='Y' WHERE AD_Field_ID=53967
;

-- 11.12.2008 17:20:25 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=240,IsDisplayed='Y' WHERE AD_Field_ID=53980
;

-- 11.12.2008 17:20:25 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=250,IsDisplayed='Y' WHERE AD_Field_ID=54000
;

-- 11.12.2008 17:20:25 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=260,IsDisplayed='Y' WHERE AD_Field_ID=54001
;

-- 11.12.2008 17:20:25 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=270,IsDisplayed='Y' WHERE AD_Field_ID=54002
;

-- 11.12.2008 17:20:25 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=280,IsDisplayed='Y' WHERE AD_Field_ID=53971
;

-- 11.12.2008 17:20:25 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=290,IsDisplayed='Y' WHERE AD_Field_ID=53972
;

-- 11.12.2008 17:20:25 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=300,IsDisplayed='Y' WHERE AD_Field_ID=53969
;

-- 11.12.2008 17:20:25 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=310,IsDisplayed='Y' WHERE AD_Field_ID=53975
;

-- 11.12.2008 17:20:25 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=320,IsDisplayed='Y' WHERE AD_Field_ID=53973
;

-- 11.12.2008 17:20:25 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=330,IsDisplayed='Y' WHERE AD_Field_ID=53968
;

-- 11.12.2008 17:20:25 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=340,IsDisplayed='Y' WHERE AD_Field_ID=53966
;

-- 11.12.2008 17:20:25 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=350,IsDisplayed='Y' WHERE AD_Field_ID=53967
;

-- 11.12.2008 17:20:48 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET IsDisplayed='N',Updated=TO_DATE('2008-12-11 17:20:48','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53969
;

-- 11.12.2008 17:24:23 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53969
;

-- 11.12.2008 17:24:23 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=240,IsDisplayed='Y' WHERE AD_Field_ID=54000
;

-- 11.12.2008 17:24:23 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=250,IsDisplayed='Y' WHERE AD_Field_ID=53980
;

-- 11.12.2008 17:24:23 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=260,IsDisplayed='Y' WHERE AD_Field_ID=53975
;

-- 11.12.2008 17:24:23 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=270,IsDisplayed='Y' WHERE AD_Field_ID=54001
;

-- 11.12.2008 17:24:23 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=280,IsDisplayed='Y' WHERE AD_Field_ID=54002
;

-- 11.12.2008 17:24:23 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=290,IsDisplayed='Y' WHERE AD_Field_ID=53973
;

-- 11.12.2008 17:24:23 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=300,IsDisplayed='Y' WHERE AD_Field_ID=53971
;

-- 11.12.2008 17:24:23 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=310,IsDisplayed='Y' WHERE AD_Field_ID=53972
;

-- 11.12.2008 17:24:23 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=320,IsDisplayed='Y' WHERE AD_Field_ID=53967
;

-- 11.12.2008 17:24:34 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLogic='@#AD_Org_ID@',Updated=TO_DATE('2008-12-11 17:24:34','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53977
;

-- 11.12.2008 17:24:51 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLength=10,Updated=TO_DATE('2008-12-11 17:24:51','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53979
;

-- 11.12.2008 17:24:56 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLength=40,Updated=TO_DATE('2008-12-11 17:24:56','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53981
;

-- 11.12.2008 17:25:00 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLength=10,Updated=TO_DATE('2008-12-11 17:25:00','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53982
;

-- 11.12.2008 17:25:03 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLength=10,Updated=TO_DATE('2008-12-11 17:25:03','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53983
;

-- 11.12.2008 17:25:10 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLength=10,Updated=TO_DATE('2008-12-11 17:25:10','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53984
;

-- 11.12.2008 17:25:13 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLength=10,Updated=TO_DATE('2008-12-11 17:25:13','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53985
;

-- 11.12.2008 17:25:36 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLength=10,Updated=TO_DATE('2008-12-11 17:25:36','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53996
;

-- 11.12.2008 17:25:39 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLength=10,Updated=TO_DATE('2008-12-11 17:25:39','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53997
;

-- 11.12.2008 17:25:42 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLength=10,Updated=TO_DATE('2008-12-11 17:25:42','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53998
;

-- 11.12.2008 17:25:48 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET IsReadOnly='Y',Updated=TO_DATE('2008-12-11 17:25:48','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53999
;

-- 11.12.2008 17:25:55 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET IsReadOnly='Y', IsSameLine='Y',Updated=TO_DATE('2008-12-11 17:25:55','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=54000
;

-- 11.12.2008 17:26:01 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET IsReadOnly='Y',Updated=TO_DATE('2008-12-11 17:26:01','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53980
;

-- 11.12.2008 17:26:05 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET IsSameLine='Y',Updated=TO_DATE('2008-12-11 17:26:05','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53975
;

-- 11.12.2008 17:26:38 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLogic='@Processed@=Y & @#ShowAcct@=Y', IsSameLine='N',Updated=TO_DATE('2008-12-11 17:26:38','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=54002
;

-- 11.12.2008 17:26:58 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLogic='@$Element_PJ@=''Y''',Updated=TO_DATE('2008-12-11 17:26:58','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53973
;

-- 11.12.2008 17:27:04 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLogic='@$Element_AY@=''Y''',Updated=TO_DATE('2008-12-11 17:27:04','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53971
;

-- 11.12.2008 17:27:15 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLogic='@$Element_MC@=''Y''',Updated=TO_DATE('2008-12-11 17:27:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53972
;

-- 11.12.2008 17:27:22 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLogic='@$Element_OT@=Y',Updated=TO_DATE('2008-12-11 17:27:22','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53967
;

-- 11.12.2008 17:27:28 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLogic='@$Element_U1@=Y',Updated=TO_DATE('2008-12-11 17:27:28','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53968
;

-- 11.12.2008 17:27:35 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLogic='@$Element_U2@=Y',Updated=TO_DATE('2008-12-11 17:27:35','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53966
;

-- 11.12.2008 17:28:57 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DefaultValue='@#AD_Client_ID@', DisplayLogic=NULL,Updated=TO_DATE('2008-12-11 17:28:57','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53976
;

-- 11.12.2008 17:29:02 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLogic=NULL,Updated=TO_DATE('2008-12-11 17:29:02','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53977
;

-- 11.12.2008 17:29:05 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DefaultValue='@#AD_Org_ID@',Updated=TO_DATE('2008-12-11 17:29:05','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53977
;

-- 11.12.2008 17:30:24 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET IsSameLine='N',Updated=TO_DATE('2008-12-11 17:30:24','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53999
;

-- 11.12.2008 17:30:29 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLength=10,Updated=TO_DATE('2008-12-11 17:30:29','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53976
;

-- 11.12.2008 17:30:32 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLength=10,Updated=TO_DATE('2008-12-11 17:30:32','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53977
;

-- 11.12.2008 17:30:36 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLength=10,Updated=TO_DATE('2008-12-11 17:30:36','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53978
;

-- 11.12.2008 17:32:11 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET IsDisplayed='N',Updated=TO_DATE('2008-12-11 17:32:11','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=54000
;

-- 11.12.2008 17:32:20 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLength=10, IsSameLine='Y',Updated=TO_DATE('2008-12-11 17:32:20','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53980
;

-- 11.12.2008 17:33:04 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=54000
;

-- 11.12.2008 17:33:04 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=230,IsDisplayed='Y' WHERE AD_Field_ID=53973
;

-- 11.12.2008 17:33:04 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=240,IsDisplayed='Y' WHERE AD_Field_ID=53971
;

-- 11.12.2008 17:33:04 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=250,IsDisplayed='Y' WHERE AD_Field_ID=53972
;

-- 11.12.2008 17:33:04 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=260,IsDisplayed='Y' WHERE AD_Field_ID=53967
;

-- 11.12.2008 17:33:04 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=270,IsDisplayed='Y' WHERE AD_Field_ID=53968
;

-- 11.12.2008 17:33:04 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=280,IsDisplayed='Y' WHERE AD_Field_ID=53966
;

-- 11.12.2008 17:33:05 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=290,IsDisplayed='Y' WHERE AD_Field_ID=53999
;

-- 11.12.2008 17:33:05 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=300,IsDisplayed='Y' WHERE AD_Field_ID=53980
;

-- 11.12.2008 17:33:05 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=310,IsDisplayed='Y' WHERE AD_Field_ID=53975
;

-- 11.12.2008 17:33:05 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=320,IsDisplayed='Y' WHERE AD_Field_ID=54001
;

-- 11.12.2008 17:33:05 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=330,IsDisplayed='Y' WHERE AD_Field_ID=54002
;

-- 11.12.2008 17:33:25 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2008-12-11 17:33:25','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53973
;

-- 11.12.2008 17:33:34 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLength=10, IsSameLine='Y',Updated=TO_DATE('2008-12-11 17:33:34','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53971
;

-- 11.12.2008 17:33:38 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLength=10,Updated=TO_DATE('2008-12-11 17:33:38','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53973
;

-- 11.12.2008 17:33:55 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLength=10, IsSameLine='N',Updated=TO_DATE('2008-12-11 17:33:55','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53972
;

-- 11.12.2008 17:34:00 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLength=10, IsSameLine='Y',Updated=TO_DATE('2008-12-11 17:34:00','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53967
;

-- 11.12.2008 17:34:15 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLength=10,Updated=TO_DATE('2008-12-11 17:34:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53968
;

-- 11.12.2008 17:34:19 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DisplayLength=10, IsSameLine='Y',Updated=TO_DATE('2008-12-11 17:34:19','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53966
;

-- 11.12.2008 17:34:35 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2008-12-11 17:34:35','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53999
;

-- 11.12.2008 17:34:38 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2008-12-11 17:34:38','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53980
;

-- 11.12.2008 17:34:42 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2008-12-11 17:34:42','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53975
;

-- 11.12.2008 17:34:57 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2008-12-11 17:34:57','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=54002
;

-- 11.12.2008 17:35:04 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2008-12-11 17:35:04','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=54001
;

-- 11.12.2008 17:40:21 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53986
;

-- 11.12.2008 17:40:21 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=100,IsDisplayed='Y' WHERE AD_Field_ID=53987
;

-- 11.12.2008 17:40:21 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=110,IsDisplayed='Y' WHERE AD_Field_ID=53988
;

-- 11.12.2008 17:40:21 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=120,IsDisplayed='Y' WHERE AD_Field_ID=53989
;

-- 11.12.2008 17:40:21 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=130,IsDisplayed='Y' WHERE AD_Field_ID=53990
;

-- 11.12.2008 17:40:21 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=140,IsDisplayed='Y' WHERE AD_Field_ID=53991
;

-- 11.12.2008 17:40:21 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=150,IsDisplayed='Y' WHERE AD_Field_ID=53992
;

-- 11.12.2008 17:40:21 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=160,IsDisplayed='Y' WHERE AD_Field_ID=53993
;

-- 11.12.2008 17:40:21 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=170,IsDisplayed='Y' WHERE AD_Field_ID=53994
;

-- 11.12.2008 17:40:21 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=180,IsDisplayed='Y' WHERE AD_Field_ID=53995
;

-- 11.12.2008 17:40:21 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=190,IsDisplayed='Y' WHERE AD_Field_ID=53996
;

-- 11.12.2008 17:40:21 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=200,IsDisplayed='Y' WHERE AD_Field_ID=53997
;

-- 11.12.2008 17:40:21 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=210,IsDisplayed='Y' WHERE AD_Field_ID=53998
;

-- 11.12.2008 17:40:21 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=220,IsDisplayed='Y' WHERE AD_Field_ID=53973
;

-- 11.12.2008 17:40:21 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=230,IsDisplayed='Y' WHERE AD_Field_ID=53971
;

-- 11.12.2008 17:40:21 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=240,IsDisplayed='Y' WHERE AD_Field_ID=53972
;

-- 11.12.2008 17:40:21 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=250,IsDisplayed='Y' WHERE AD_Field_ID=53967
;

-- 11.12.2008 17:40:21 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=260,IsDisplayed='Y' WHERE AD_Field_ID=53968
;

-- 11.12.2008 17:40:21 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=270,IsDisplayed='Y' WHERE AD_Field_ID=53966
;

-- 11.12.2008 17:40:22 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=280,IsDisplayed='Y' WHERE AD_Field_ID=53999
;

-- 11.12.2008 17:40:22 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=290,IsDisplayed='Y' WHERE AD_Field_ID=53980
;

-- 11.12.2008 17:40:22 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=300,IsDisplayed='Y' WHERE AD_Field_ID=53975
;

-- 11.12.2008 17:40:22 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=310,IsDisplayed='Y' WHERE AD_Field_ID=54001
;

-- 11.12.2008 17:40:22 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=320,IsDisplayed='Y' WHERE AD_Field_ID=54002
;

-- 11.12.2008 17:41:26 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=280,IsDisplayed='Y' WHERE AD_Field_ID=54001
;

-- 11.12.2008 17:41:26 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=290,IsDisplayed='Y' WHERE AD_Field_ID=53999
;

-- 11.12.2008 17:41:26 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=300,IsDisplayed='Y' WHERE AD_Field_ID=53980
;

-- 11.12.2008 17:41:26 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET SeqNo=310,IsDisplayed='Y' WHERE AD_Field_ID=53975
;

-- 11.12.2008 17:42:49 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Field SET DefaultValue='160',Updated=TO_DATE('2008-12-11 17:42:49','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=54001
;

-- 11.12.2008 17:48:40 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Column SET DefaultValue='0',Updated=TO_DATE('2008-12-11 17:48:40','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Column_ID=53810
;

-- 11.12.2008 17:54:07 EET
-- [ 2412212 ] Fix Activity Control Report Window
UPDATE AD_Column SET AD_Reference_Value_ID=NULL,Updated=TO_DATE('2008-12-11 17:54:07','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Column_ID=53810
;

