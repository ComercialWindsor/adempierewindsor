-- Aug 29, 2008 7:06:38 PM CDT
-- MRP Run to Multiple Plant
UPDATE AD_Process_Para SET AD_Val_Rule_ID=148, IsMandatory='N',Updated=TO_DATE('2008-08-29 19:06:38','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Process_Para_ID=53054
;

-- Aug 29, 2008 7:09:28 PM CDT
-- MRP Run to Multiple Plant
UPDATE AD_Process_Para SET IsMandatory='N',Updated=TO_DATE('2008-08-29 19:09:28','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Process_Para_ID=53132
;

-- Aug 29, 2008 7:10:33 PM CDT
-- MRP Run to Multiple Plant
UPDATE AD_Process_Para SET IsMandatory='N',Updated=TO_DATE('2008-08-29 19:10:33','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Process_Para_ID=53207
;

