
UPDATE AD_Column SET IsParent='Y', IsUpdateable='N',Updated=TO_DATE('2008-06-28 22:10:02','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=13468
;

