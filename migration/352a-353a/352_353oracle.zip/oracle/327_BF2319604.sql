-- Nov 21, 2008 12:14:31 PM SGT
-- [ 2319604 ] Wrong SQL where clause in Inbound Asset Entry window
UPDATE AD_Tab SET WhereClause='A_Depreciation_Entry.A_Entry_Type = ''New''',Updated=TO_DATE('2008-11-21 12:14:31','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Tab_ID=53166
;
