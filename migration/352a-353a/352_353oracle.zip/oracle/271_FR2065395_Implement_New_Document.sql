-- Aug 21, 2008 12:18:36 PM CDT
-- Implementing new document
UPDATE AD_Ref_List SET Name='Manufacturing Order Method Variance ',Updated=TO_DATE('2008-08-21 12:18:36','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Ref_List_ID=53234
;

-- Aug 21, 2008 12:18:36 PM CDT
-- Implementing new document
UPDATE AD_Ref_List_Trl SET IsTranslated='N' WHERE AD_Ref_List_ID=53234
;

-- Aug 21, 2008 12:18:46 PM CDT
-- Implementing new document
UPDATE AD_Ref_List SET Name='Manufacturing Order Use Variance ',Updated=TO_DATE('2008-08-21 12:18:46','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Ref_List_ID=53237
;

-- Aug 21, 2008 12:18:46 PM CDT
-- Implementing new document
UPDATE AD_Ref_List_Trl SET IsTranslated='N' WHERE AD_Ref_List_ID=53237
;

-- Aug 21, 2008 12:18:54 PM CDT
-- Implementing new document
UPDATE AD_Ref_List SET Name='Manufacturing Order Rate Variance',Updated=TO_DATE('2008-08-21 12:18:54','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Ref_List_ID=53238
;

-- Aug 21, 2008 12:18:54 PM CDT
-- Implementing new document
UPDATE AD_Ref_List_Trl SET IsTranslated='N' WHERE AD_Ref_List_ID=53238
;

