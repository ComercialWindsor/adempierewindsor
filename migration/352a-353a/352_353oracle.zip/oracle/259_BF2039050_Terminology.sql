SET SQLBLANKLINES ON
SET DEFINE OFF

-- Aug 5, 2008 11:44:57 AM CDT
-- Terminology
UPDATE AD_Table SET Name='Cost Collector',Updated=TO_DATE('2008-08-05 11:44:57','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53035
;

-- Aug 5, 2008 11:44:57 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53035
;

-- Aug 5, 2008 11:45:02 AM CDT
-- Terminology
UPDATE AD_Table SET Name='MRP',Updated=TO_DATE('2008-08-05 11:45:02','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53043
;

-- Aug 5, 2008 11:45:02 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53043
;

-- Aug 5, 2008 11:45:10 AM CDT
-- Terminology
UPDATE AD_Table SET Name='Manufacturing Order',Updated=TO_DATE('2008-08-05 11:45:10','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53027
;

-- Aug 5, 2008 11:45:10 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53027
;

-- Aug 5, 2008 11:45:19 AM CDT
-- Terminology
UPDATE AD_Table SET Name='Order BOM',Updated=TO_DATE('2008-08-05 11:45:19','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53026
;

-- Aug 5, 2008 11:45:19 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53026
;

-- Aug 5, 2008 11:45:29 AM CDT
-- Terminology
UPDATE AD_Table SET Name='Order BOM Line',Updated=TO_DATE('2008-08-05 11:45:29','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53025
;

-- Aug 5, 2008 11:45:29 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53025
;

-- Aug 5, 2008 11:46:09 AM CDT
-- Terminology
UPDATE AD_Table SET Name='Order BOM Line MA',Updated=TO_DATE('2008-08-05 11:46:09','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53062
;

-- Aug 5, 2008 11:46:09 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53062
;

-- Aug 5, 2008 11:46:22 AM CDT
-- Terminology
UPDATE AD_Table SET Name='Order Cost',Updated=TO_DATE('2008-08-05 11:46:22','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53024
;

-- Aug 5, 2008 11:46:22 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53024
;

-- Aug 5, 2008 11:46:55 AM CDT
-- Terminology
UPDATE AD_Table SET Name='Manufacturing Order Activity Next',Updated=TO_DATE('2008-08-05 11:46:55','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53023
;

-- Aug 5, 2008 11:46:55 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53023
;

-- Aug 5, 2008 11:47:21 AM CDT
-- Terminology
UPDATE AD_Table SET Name='Manufacturing Order Activity Asset',Updated=TO_DATE('2008-08-05 11:47:21','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53031
;

-- Aug 5, 2008 11:47:21 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53031
;

-- Aug 5, 2008 11:47:54 AM CDT
-- Terminology
UPDATE AD_Table SET Name='Manufacturing Order Activity Product',Updated=TO_DATE('2008-08-05 11:47:54','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53030
;

-- Aug 5, 2008 11:47:54 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53030
;

-- Aug 5, 2008 11:48:08 AM CDT
-- Terminology
UPDATE AD_Table SET Name='Manufacturing Order Workflow',Updated=TO_DATE('2008-08-05 11:48:08','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53029
;

-- Aug 5, 2008 11:48:08 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53029
;

-- Aug 5, 2008 11:48:31 AM CDT
-- Terminology
UPDATE AD_Table SET Name='Product Planning',Updated=TO_DATE('2008-08-05 11:48:31','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53020
;

-- Aug 5, 2008 11:48:31 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53020
;

-- Aug 5, 2008 11:48:47 AM CDT
-- Terminology
UPDATE AD_Table SET Name='Workflow Node Asset',Updated=TO_DATE('2008-08-05 11:48:47','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53017
;

-- Aug 5, 2008 11:48:47 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53017
;

-- Aug 5, 2008 11:49:03 AM CDT
-- Terminology
UPDATE AD_Table SET Name='Workflow Node Product',Updated=TO_DATE('2008-08-05 11:49:03','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53016
;

-- Aug 5, 2008 11:49:03 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53016
;

-- Aug 5, 2008 11:49:17 AM CDT
-- Terminology
UPDATE AD_Table SET Name='Quality Specification',Updated=TO_DATE('2008-08-05 11:49:17','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53040
;

-- Aug 5, 2008 11:49:17 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53040
;

-- Aug 5, 2008 11:49:23 AM CDT
-- Terminology
UPDATE AD_Table SET Name='Quality Specification Line',Updated=TO_DATE('2008-08-05 11:49:23','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53041
;

-- Aug 5, 2008 11:49:23 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53041
;

-- Aug 5, 2008 11:49:58 AM CDT
-- Terminology
UPDATE AD_Table SET Name='View Working In Process',Updated=TO_DATE('2008-08-05 11:49:58','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53033
;

-- Aug 5, 2008 11:49:58 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53033
;

-- Aug 5, 2008 11:50:22 AM CDT
-- Terminology
UPDATE AD_Table SET Name='Temporal BOM Line',Updated=TO_DATE('2008-08-05 11:50:22','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53045
;

-- Aug 5, 2008 11:50:22 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53045
;

-- Aug 5, 2008 11:50:37 AM CDT
-- Terminology
UPDATE AD_Table SET Name='Temporal MRP & CRP',Updated=TO_DATE('2008-08-05 11:50:37','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53044
;

-- Aug 5, 2008 11:50:37 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53044
;

-- Aug 5, 2008 11:51:46 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Network Distribution',Updated=TO_DATE('2008-08-05 11:51:46','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53060
;

-- Aug 5, 2008 11:51:59 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Network Distribution Line', Name='Network Distribution Line',Updated=TO_DATE('2008-08-05 11:51:59','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53061
;

-- Aug 5, 2008 11:51:59 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53061
;

-- Aug 5, 2008 11:52:02 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Distribution Order',Updated=TO_DATE('2008-08-05 11:52:02','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53037
;

-- Aug 5, 2008 11:52:08 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Distribution Order Line',Updated=TO_DATE('2008-08-05 11:52:08','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53038
;

-- Aug 5, 2008 11:52:13 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Cost Collector',Updated=TO_DATE('2008-08-05 11:52:13','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53035
;

-- Aug 5, 2008 11:54:27 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Material Requirement Planning', Name='Material Requirement Planning',Updated=TO_DATE('2008-08-05 11:54:27','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53043
;

-- Aug 5, 2008 11:54:27 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53043
;

-- Aug 5, 2008 11:54:34 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Manufacturing Order',Updated=TO_DATE('2008-08-05 11:54:34','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53027
;

-- Aug 5, 2008 11:54:37 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Order BOM',Updated=TO_DATE('2008-08-05 11:54:37','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53026
;

-- Aug 5, 2008 11:54:42 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Order BOM Line',Updated=TO_DATE('2008-08-05 11:54:42','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53025
;

-- Aug 5, 2008 11:54:45 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Order BOM Line MA',Updated=TO_DATE('2008-08-05 11:54:45','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53062
;

-- Aug 5, 2008 11:54:50 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Order Cost',Updated=TO_DATE('2008-08-05 11:54:50','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53024
;

-- Aug 5, 2008 11:54:54 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Manufacturing Order Activity',Updated=TO_DATE('2008-08-05 11:54:54','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53022
;

-- Aug 5, 2008 11:54:59 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Manufacturing Order Activity Next',Updated=TO_DATE('2008-08-05 11:54:59','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53023
;

-- Aug 5, 2008 11:55:03 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Manufacturing Order Activity Asset',Updated=TO_DATE('2008-08-05 11:55:03','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53031
;

-- Aug 5, 2008 11:55:08 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Manufacturing Order Activity Product',Updated=TO_DATE('2008-08-05 11:55:08','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53030
;

-- Aug 5, 2008 11:55:13 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Manufacturing Order Workflow',Updated=TO_DATE('2008-08-05 11:55:13','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53029
;

-- Aug 5, 2008 11:55:17 AM CDT
-- Terminology
UPDATE AD_Table SET Description='BOM Line',Updated=TO_DATE('2008-08-05 11:55:17','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53019
;

-- Aug 5, 2008 11:55:22 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Product Planning',Updated=TO_DATE('2008-08-05 11:55:22','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53020
;

-- Aug 5, 2008 11:55:25 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Workflow Node Asset',Updated=TO_DATE('2008-08-05 11:55:25','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53017
;

-- Aug 5, 2008 11:55:29 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Workflow Node Product',Updated=TO_DATE('2008-08-05 11:55:29','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53016
;

-- Aug 5, 2008 11:55:33 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Quality Specification',Updated=TO_DATE('2008-08-05 11:55:33','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53040
;

-- Aug 5, 2008 11:55:38 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Quality Specification Line',Updated=TO_DATE('2008-08-05 11:55:38','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53041
;

-- Aug 5, 2008 11:55:43 AM CDT
-- Terminology
UPDATE AD_Table SET Description='MRP View',Updated=TO_DATE('2008-08-05 11:55:43','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53021
;

-- Aug 5, 2008 11:55:56 AM CDT
-- Terminology
UPDATE AD_Table SET Description='View Operation_Activity', Name='View Operation_Activity',Updated=TO_DATE('2008-08-05 11:55:56','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53036
;

-- Aug 5, 2008 11:55:56 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53036
;

-- Aug 5, 2008 11:56:14 AM CDT
-- Terminology
UPDATE AD_Table SET Description='View Order BOM Line', Name='View Order BOM Line',Updated=TO_DATE('2008-08-05 11:56:14','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53028
;

-- Aug 5, 2008 11:56:14 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53028
;

-- Aug 5, 2008 11:56:32 AM CDT
-- Terminology
UPDATE AD_Table SET Description='View Order Storage', Name='View Order Storage',Updated=TO_DATE('2008-08-05 11:56:32','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53032
;

-- Aug 5, 2008 11:56:32 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53032
;

-- Aug 5, 2008 11:56:42 AM CDT
-- Terminology
UPDATE AD_Table SET Name='View Manufacturing Order Transactions',Updated=TO_DATE('2008-08-05 11:56:42','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53034
;

-- Aug 5, 2008 11:56:42 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53034
;

-- Aug 5, 2008 11:56:51 AM CDT
-- Terminology
UPDATE AD_Table SET Name='View Product BOM Line',Updated=TO_DATE('2008-08-05 11:56:51','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53063
;

-- Aug 5, 2008 11:56:51 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53063
;

-- Aug 5, 2008 11:56:55 AM CDT
-- Terminology
UPDATE AD_Table SET Description='View Manufacturing Order Transactions',Updated=TO_DATE('2008-08-05 11:56:55','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53034
;

-- Aug 5, 2008 11:57:00 AM CDT
-- Terminology
UPDATE AD_Table SET Description='View Product BOM Line',Updated=TO_DATE('2008-08-05 11:57:00','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53063
;

-- Aug 5, 2008 11:57:03 AM CDT
-- Terminology
UPDATE AD_Table SET Description='View Product Costing',Updated=TO_DATE('2008-08-05 11:57:03','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53042
;

-- Aug 5, 2008 11:57:09 AM CDT
-- Terminology
UPDATE AD_Table SET Description='View Product Costing', Name='View Product Costing',Updated=TO_DATE('2008-08-05 11:57:09','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53033
;

-- Aug 5, 2008 11:57:09 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53033
;

-- Aug 5, 2008 11:57:17 AM CDT
-- Terminology
UPDATE AD_Table SET Name='View ',Updated=TO_DATE('2008-08-05 11:57:17','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53021
;

-- Aug 5, 2008 11:57:17 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53021
;

-- Aug 5, 2008 11:57:28 AM CDT
-- Terminology
UPDATE AD_Table SET Description='View Material Requirement Planning', Name='View Material Requirement Planning',Updated=TO_DATE('2008-08-05 11:57:28','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53021
;

-- Aug 5, 2008 11:57:28 AM CDT
-- Terminology
UPDATE AD_Table_Trl SET IsTranslated='N' WHERE AD_Table_ID=53021
;

-- Aug 5, 2008 11:57:35 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Temporal BOM Line',Updated=TO_DATE('2008-08-05 11:57:35','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53045
;

-- Aug 5, 2008 11:57:45 AM CDT
-- Terminology
UPDATE AD_Table SET Description='Temporal MRP & CRP',Updated=TO_DATE('2008-08-05 11:57:45','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=53044
;

-- Aug 5, 2008 11:58:53 AM CDT
-- Terminology
UPDATE AD_Element SET Name='Payroll Concept Account', PrintName='Payroll Concept Account',Updated=TO_DATE('2008-08-05 11:58:53','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53411
;

-- Aug 5, 2008 11:58:53 AM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53411
;

-- Aug 5, 2008 11:58:53 AM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='HR_Concept_Acct', Name='Payroll Concept Account', Description=NULL, Help=NULL WHERE AD_Element_ID=53411
;

-- Aug 5, 2008 11:58:53 AM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Concept_Acct', Name='Payroll Concept Account', Description=NULL, Help=NULL, AD_Element_ID=53411 WHERE UPPER(ColumnName)='HR_CONCEPT_ACCT' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 11:58:53 AM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Concept_Acct', Name='Payroll Concept Account', Description=NULL, Help=NULL WHERE AD_Element_ID=53411 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 11:58:53 AM CDT
-- Terminology
UPDATE AD_Field SET Name='Payroll Concept Account', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53411) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 11:58:53 AM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Payroll Concept Account', Name='Payroll Concept Account' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53411)
;

-- Aug 5, 2008 11:59:16 AM CDT
-- Terminology
UPDATE AD_Element SET Name='Payroll Concept Account ID', PrintName='Payroll Concept Account ID',Updated=TO_DATE('2008-08-05 11:59:16','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53404
;

-- Aug 5, 2008 11:59:16 AM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53404
;

-- Aug 5, 2008 11:59:16 AM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='HR_Concept_Acct_ID', Name='Payroll Concept Account ID', Description=NULL, Help=NULL WHERE AD_Element_ID=53404
;

-- Aug 5, 2008 11:59:16 AM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Concept_Acct_ID', Name='Payroll Concept Account ID', Description=NULL, Help=NULL, AD_Element_ID=53404 WHERE UPPER(ColumnName)='HR_CONCEPT_ACCT_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 11:59:16 AM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Concept_Acct_ID', Name='Payroll Concept Account ID', Description=NULL, Help=NULL WHERE AD_Element_ID=53404 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 11:59:16 AM CDT
-- Terminology
UPDATE AD_Field SET Name='Payroll Concept Account ID', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53404) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 11:59:16 AM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Payroll Concept Account ID', Name='Payroll Concept Account ID' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53404)
;

-- Aug 5, 2008 11:59:25 AM CDT
-- Terminology
UPDATE AD_Element SET Name='Payroll Concept', PrintName='Payroll Concept',Updated=TO_DATE('2008-08-05 11:59:25','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53398
;

-- Aug 5, 2008 11:59:25 AM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53398
;

-- Aug 5, 2008 11:59:25 AM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='HR_Concept_ID', Name='Payroll Concept', Description=NULL, Help=NULL WHERE AD_Element_ID=53398
;

-- Aug 5, 2008 11:59:25 AM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Concept_ID', Name='Payroll Concept', Description=NULL, Help=NULL, AD_Element_ID=53398 WHERE UPPER(ColumnName)='HR_CONCEPT_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 11:59:25 AM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Concept_ID', Name='Payroll Concept', Description=NULL, Help=NULL WHERE AD_Element_ID=53398 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 11:59:25 AM CDT
-- Terminology
UPDATE AD_Field SET Name='Payroll Concept', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53398) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 11:59:25 AM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Payroll Concept', Name='Payroll Concept' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53398)
;

-- Aug 5, 2008 11:59:33 AM CDT
-- Terminology
UPDATE AD_Element SET Name='Payroll Department', PrintName='Payroll Department',Updated=TO_DATE('2008-08-05 11:59:33','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53390
;

-- Aug 5, 2008 11:59:33 AM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53390
;

-- Aug 5, 2008 11:59:33 AM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='HR_Department_ID', Name='Payroll Department', Description=NULL, Help=NULL WHERE AD_Element_ID=53390
;

-- Aug 5, 2008 11:59:33 AM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Department_ID', Name='Payroll Department', Description=NULL, Help=NULL, AD_Element_ID=53390 WHERE UPPER(ColumnName)='HR_DEPARTMENT_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 11:59:33 AM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Department_ID', Name='Payroll Department', Description=NULL, Help=NULL WHERE AD_Element_ID=53390 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 11:59:33 AM CDT
-- Terminology
UPDATE AD_Field SET Name='Payroll Department', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53390) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 11:59:33 AM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Payroll Department', Name='Payroll Department' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53390)
;

-- Aug 5, 2008 11:59:51 AM CDT
-- Terminology
UPDATE AD_Element SET Name='Payroll Employee', PrintName='Payroll Employee',Updated=TO_DATE('2008-08-05 11:59:51','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53391
;

-- Aug 5, 2008 11:59:51 AM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53391
;

-- Aug 5, 2008 11:59:51 AM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='HR_Employee_ID', Name='Payroll Employee', Description=NULL, Help=NULL WHERE AD_Element_ID=53391
;

-- Aug 5, 2008 11:59:51 AM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Employee_ID', Name='Payroll Employee', Description=NULL, Help=NULL, AD_Element_ID=53391 WHERE UPPER(ColumnName)='HR_EMPLOYEE_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 11:59:51 AM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Employee_ID', Name='Payroll Employee', Description=NULL, Help=NULL WHERE AD_Element_ID=53391 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 11:59:51 AM CDT
-- Terminology
UPDATE AD_Field SET Name='Payroll Employee', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53391) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 11:59:51 AM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Payroll Employee', Name='Payroll Employee' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53391)
;

-- Aug 5, 2008 12:00:15 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Payroll Expense Account', PrintName='Payroll Expense Account',Updated=TO_DATE('2008-08-05 12:00:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53406
;

-- Aug 5, 2008 12:00:15 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53406
;

-- Aug 5, 2008 12:00:15 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='HR_Expense_Acct', Name='Payroll Expense Account', Description=NULL, Help=NULL WHERE AD_Element_ID=53406
;

-- Aug 5, 2008 12:00:15 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Expense_Acct', Name='Payroll Expense Account', Description=NULL, Help=NULL, AD_Element_ID=53406 WHERE UPPER(ColumnName)='HR_EXPENSE_ACCT' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:00:15 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Expense_Acct', Name='Payroll Expense Account', Description=NULL, Help=NULL WHERE AD_Element_ID=53406 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:00:15 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Payroll Expense Account', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53406) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:00:15 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Payroll Expense Account', Name='Payroll Expense Account' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53406)
;

-- Aug 5, 2008 12:00:28 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Payroll Job', PrintName='Payroll Job',Updated=TO_DATE('2008-08-05 12:00:28','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53392
;

-- Aug 5, 2008 12:00:28 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53392
;

-- Aug 5, 2008 12:00:28 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='HR_Job_ID', Name='Payroll Job', Description=NULL, Help=NULL WHERE AD_Element_ID=53392
;

-- Aug 5, 2008 12:00:28 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Job_ID', Name='Payroll Job', Description=NULL, Help=NULL, AD_Element_ID=53392 WHERE UPPER(ColumnName)='HR_JOB_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:00:28 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Job_ID', Name='Payroll Job', Description=NULL, Help=NULL WHERE AD_Element_ID=53392 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:00:28 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Payroll Job', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53392) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:00:28 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Payroll Job', Name='Payroll Job' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53392)
;

-- Aug 5, 2008 12:01:05 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Payroll Revenue Account', PrintName='Payroll Revenue Account',Updated=TO_DATE('2008-08-05 12:01:05','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53405
;

-- Aug 5, 2008 12:01:05 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53405
;

-- Aug 5, 2008 12:01:05 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='HR_Revenue_Acct', Name='Payroll Revenue Account', Description=NULL, Help=NULL WHERE AD_Element_ID=53405
;

-- Aug 5, 2008 12:01:05 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Revenue_Acct', Name='Payroll Revenue Account', Description=NULL, Help=NULL, AD_Element_ID=53405 WHERE UPPER(ColumnName)='HR_REVENUE_ACCT' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:01:05 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Revenue_Acct', Name='Payroll Revenue Account', Description=NULL, Help=NULL WHERE AD_Element_ID=53405 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:01:05 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Payroll Revenue Account', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53405) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:01:05 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Payroll Revenue Account', Name='Payroll Revenue Account' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53405)
;

-- Aug 5, 2008 12:03:07 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Network Distribution Line', PrintName='Network Distribution Line',Updated=TO_DATE('2008-08-05 12:03:07','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53341
;

-- Aug 5, 2008 12:03:07 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53341
;

-- Aug 5, 2008 12:03:07 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='DD_NetworkDistributionLine_ID', Name='Network Distribution Line', Description=NULL, Help=NULL WHERE AD_Element_ID=53341
;

-- Aug 5, 2008 12:03:07 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='DD_NetworkDistributionLine_ID', Name='Network Distribution Line', Description=NULL, Help=NULL, AD_Element_ID=53341 WHERE UPPER(ColumnName)='DD_NETWORKDISTRIBUTIONLINE_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:03:07 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='DD_NetworkDistributionLine_ID', Name='Network Distribution Line', Description=NULL, Help=NULL WHERE AD_Element_ID=53341 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:03:07 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Network Distribution Line', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53341) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:03:07 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Network Distribution Line', Name='Network Distribution Line' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53341)
;

-- Aug 5, 2008 12:03:17 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Cost Collector ID', PrintName='Cost Collector ID',Updated=TO_DATE('2008-08-05 12:03:17','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53310
;

-- Aug 5, 2008 12:03:17 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53310
;

-- Aug 5, 2008 12:03:17 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Cost_Collector_ID', Name='Cost Collector ID', Description=NULL, Help=NULL WHERE AD_Element_ID=53310
;

-- Aug 5, 2008 12:03:17 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Cost_Collector_ID', Name='Cost Collector ID', Description=NULL, Help=NULL, AD_Element_ID=53310 WHERE UPPER(ColumnName)='PP_COST_COLLECTOR_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:03:17 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Cost_Collector_ID', Name='Cost Collector ID', Description=NULL, Help=NULL WHERE AD_Element_ID=53310 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:03:17 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Cost Collector ID', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53310) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:03:18 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Cost Collector ID', Name='Cost Collector ID' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53310)
;

-- Aug 5, 2008 12:03:22 PM CDT
-- Terminology
UPDATE AD_Element SET Name='MRP ID',Updated=TO_DATE('2008-08-05 12:03:22','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53316
;

-- Aug 5, 2008 12:03:22 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53316
;

-- Aug 5, 2008 12:03:22 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_MRP_ID', Name='MRP ID', Description=NULL, Help=NULL WHERE AD_Element_ID=53316
;

-- Aug 5, 2008 12:03:22 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_MRP_ID', Name='MRP ID', Description=NULL, Help=NULL, AD_Element_ID=53316 WHERE UPPER(ColumnName)='PP_MRP_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:03:22 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_MRP_ID', Name='MRP ID', Description=NULL, Help=NULL WHERE AD_Element_ID=53316 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:03:22 PM CDT
-- Terminology
UPDATE AD_Field SET Name='MRP ID', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53316) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:03:22 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='PP_MRP_ID', Name='MRP ID' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53316)
;

-- Aug 5, 2008 12:03:27 PM CDT
-- Terminology
UPDATE AD_Element SET PrintName='MRP ID',Updated=TO_DATE('2008-08-05 12:03:27','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53316
;

-- Aug 5, 2008 12:03:27 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53316
;

-- Aug 5, 2008 12:03:27 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='MRP ID', Name='MRP ID' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53316)
;

-- Aug 5, 2008 12:03:41 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Order BOM Line MA ID', PrintName='Order BOM Line MA ID',Updated=TO_DATE('2008-08-05 12:03:41','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53343
;

-- Aug 5, 2008 12:03:41 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53343
;

-- Aug 5, 2008 12:03:41 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Order_BOMLineMA_ID', Name='Order BOM Line MA ID', Description=NULL, Help=NULL WHERE AD_Element_ID=53343
;

-- Aug 5, 2008 12:03:41 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_BOMLineMA_ID', Name='Order BOM Line MA ID', Description=NULL, Help=NULL, AD_Element_ID=53343 WHERE UPPER(ColumnName)='PP_ORDER_BOMLINEMA_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:03:41 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_BOMLineMA_ID', Name='Order BOM Line MA ID', Description=NULL, Help=NULL WHERE AD_Element_ID=53343 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:03:41 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Order BOM Line MA ID', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53343) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:03:41 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Order BOM Line MA ID', Name='Order BOM Line MA ID' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53343)
;

-- Aug 5, 2008 12:04:01 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Order BOM Line ID', PrintName='Order BOM Line ID',Updated=TO_DATE('2008-08-05 12:04:01','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53275
;

-- Aug 5, 2008 12:04:01 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53275
;

-- Aug 5, 2008 12:04:01 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Order_BOMLine_ID', Name='Order BOM Line ID', Description=NULL, Help=NULL WHERE AD_Element_ID=53275
;

-- Aug 5, 2008 12:04:01 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_BOMLine_ID', Name='Order BOM Line ID', Description=NULL, Help=NULL, AD_Element_ID=53275 WHERE UPPER(ColumnName)='PP_ORDER_BOMLINE_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:04:01 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_BOMLine_ID', Name='Order BOM Line ID', Description=NULL, Help=NULL WHERE AD_Element_ID=53275 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:04:01 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Order BOM Line ID', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53275) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:04:01 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Order BOM Line ID', Name='Order BOM Line ID' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53275)
;

-- Aug 5, 2008 12:04:11 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Order BOM ID', PrintName='Order BOM ID',Updated=TO_DATE('2008-08-05 12:04:11','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53298
;

-- Aug 5, 2008 12:04:11 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53298
;

-- Aug 5, 2008 12:04:11 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Order_BOM_ID', Name='Order BOM ID', Description=NULL, Help=NULL WHERE AD_Element_ID=53298
;

-- Aug 5, 2008 12:04:12 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_BOM_ID', Name='Order BOM ID', Description=NULL, Help=NULL, AD_Element_ID=53298 WHERE UPPER(ColumnName)='PP_ORDER_BOM_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:04:12 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_BOM_ID', Name='Order BOM ID', Description=NULL, Help=NULL WHERE AD_Element_ID=53298 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:04:12 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Order BOM ID', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53298) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:04:12 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Order BOM ID', Name='Order BOM ID' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53298)
;

-- Aug 5, 2008 12:04:55 PM CDT
-- Terminology
UPDATE AD_Element SET PrintName='Order BOM Line MA',Updated=TO_DATE('2008-08-05 12:04:55','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53343
;

-- Aug 5, 2008 12:04:55 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53343
;

-- Aug 5, 2008 12:04:55 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Order BOM Line MA', Name='Order BOM Line MA ID' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53343)
;

-- Aug 5, 2008 12:04:59 PM CDT
-- Terminology
UPDATE AD_Element SET PrintName='Cost Collector',Updated=TO_DATE('2008-08-05 12:04:59','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53310
;

-- Aug 5, 2008 12:04:59 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53310
;

-- Aug 5, 2008 12:04:59 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Cost Collector', Name='Cost Collector ID' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53310)
;

-- Aug 5, 2008 12:05:01 PM CDT
-- Terminology
UPDATE AD_Element SET PrintName='Order BOM Line',Updated=TO_DATE('2008-08-05 12:05:01','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53275
;

-- Aug 5, 2008 12:05:01 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53275
;

-- Aug 5, 2008 12:05:01 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Order BOM Line', Name='Order BOM Line ID' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53275)
;

-- Aug 5, 2008 12:05:04 PM CDT
-- Terminology
UPDATE AD_Element SET PrintName='Order BOM',Updated=TO_DATE('2008-08-05 12:05:04','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53298
;

-- Aug 5, 2008 12:05:04 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53298
;

-- Aug 5, 2008 12:05:04 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Order BOM', Name='Order BOM ID' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53298)
;

-- Aug 5, 2008 12:05:11 PM CDT
-- Terminology
UPDATE AD_Element SET PrintName='Order_Cost_ID',Updated=TO_DATE('2008-08-05 12:05:11','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53297
;

-- Aug 5, 2008 12:05:11 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53297
;

-- Aug 5, 2008 12:05:11 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Order_Cost_ID', Name='PP_Order_Cost_ID' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53297)
;

-- Aug 5, 2008 12:05:15 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Order BOM Line MA',Updated=TO_DATE('2008-08-05 12:05:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53343
;

-- Aug 5, 2008 12:05:15 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53343
;

-- Aug 5, 2008 12:05:15 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Order_BOMLineMA_ID', Name='Order BOM Line MA', Description=NULL, Help=NULL WHERE AD_Element_ID=53343
;

-- Aug 5, 2008 12:05:15 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_BOMLineMA_ID', Name='Order BOM Line MA', Description=NULL, Help=NULL, AD_Element_ID=53343 WHERE UPPER(ColumnName)='PP_ORDER_BOMLINEMA_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:05:15 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_BOMLineMA_ID', Name='Order BOM Line MA', Description=NULL, Help=NULL WHERE AD_Element_ID=53343 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:05:15 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Order BOM Line MA', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53343) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:05:15 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Order BOM Line MA', Name='Order BOM Line MA' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53343)
;

-- Aug 5, 2008 12:05:18 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Order BOM Line',Updated=TO_DATE('2008-08-05 12:05:18','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53275
;

-- Aug 5, 2008 12:05:18 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53275
;

-- Aug 5, 2008 12:05:18 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Order_BOMLine_ID', Name='Order BOM Line', Description=NULL, Help=NULL WHERE AD_Element_ID=53275
;

-- Aug 5, 2008 12:05:18 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_BOMLine_ID', Name='Order BOM Line', Description=NULL, Help=NULL, AD_Element_ID=53275 WHERE UPPER(ColumnName)='PP_ORDER_BOMLINE_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:05:18 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_BOMLine_ID', Name='Order BOM Line', Description=NULL, Help=NULL WHERE AD_Element_ID=53275 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:05:18 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Order BOM Line', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53275) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:05:18 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Order BOM Line', Name='Order BOM Line' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53275)
;

-- Aug 5, 2008 12:05:20 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Order BOM',Updated=TO_DATE('2008-08-05 12:05:20','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53298
;

-- Aug 5, 2008 12:05:20 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53298
;

-- Aug 5, 2008 12:05:21 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Order_BOM_ID', Name='Order BOM', Description=NULL, Help=NULL WHERE AD_Element_ID=53298
;

-- Aug 5, 2008 12:05:21 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_BOM_ID', Name='Order BOM', Description=NULL, Help=NULL, AD_Element_ID=53298 WHERE UPPER(ColumnName)='PP_ORDER_BOM_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:05:21 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_BOM_ID', Name='Order BOM', Description=NULL, Help=NULL WHERE AD_Element_ID=53298 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:05:21 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Order BOM', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53298) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:05:21 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Order BOM', Name='Order BOM' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53298)
;

-- Aug 5, 2008 12:05:23 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Cost Collector',Updated=TO_DATE('2008-08-05 12:05:23','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53310
;

-- Aug 5, 2008 12:05:23 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53310
;

-- Aug 5, 2008 12:05:23 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Cost_Collector_ID', Name='Cost Collector', Description=NULL, Help=NULL WHERE AD_Element_ID=53310
;

-- Aug 5, 2008 12:05:23 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Cost_Collector_ID', Name='Cost Collector', Description=NULL, Help=NULL, AD_Element_ID=53310 WHERE UPPER(ColumnName)='PP_COST_COLLECTOR_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:05:23 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Cost_Collector_ID', Name='Cost Collector', Description=NULL, Help=NULL WHERE AD_Element_ID=53310 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:05:23 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Cost Collector', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53310) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:05:23 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Cost Collector', Name='Cost Collector' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53310)
;

-- Aug 5, 2008 12:06:05 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Material Requirement Planning', PrintName='Material Requirement Planning',Updated=TO_DATE('2008-08-05 12:06:05','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53316
;

-- Aug 5, 2008 12:06:05 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53316
;

-- Aug 5, 2008 12:06:05 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_MRP_ID', Name='Material Requirement Planning', Description=NULL, Help=NULL WHERE AD_Element_ID=53316
;

-- Aug 5, 2008 12:06:05 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_MRP_ID', Name='Material Requirement Planning', Description=NULL, Help=NULL, AD_Element_ID=53316 WHERE UPPER(ColumnName)='PP_MRP_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:06:05 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_MRP_ID', Name='Material Requirement Planning', Description=NULL, Help=NULL WHERE AD_Element_ID=53316 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:06:05 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Material Requirement Planning', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53316) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:06:05 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Material Requirement Planning', Name='Material Requirement Planning' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53316)
;

-- Aug 5, 2008 12:06:15 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Order Cost', PrintName='Order Cost',Updated=TO_DATE('2008-08-05 12:06:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53297
;

-- Aug 5, 2008 12:06:15 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53297
;

-- Aug 5, 2008 12:06:15 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Order_Cost_ID', Name='Order Cost', Description=NULL, Help=NULL WHERE AD_Element_ID=53297
;

-- Aug 5, 2008 12:06:15 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_Cost_ID', Name='Order Cost', Description=NULL, Help=NULL, AD_Element_ID=53297 WHERE UPPER(ColumnName)='PP_ORDER_COST_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:06:15 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_Cost_ID', Name='Order Cost', Description=NULL, Help=NULL WHERE AD_Element_ID=53297 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:06:15 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Order Cost', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53297) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:06:15 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Order Cost', Name='Order Cost' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53297)
;

-- Aug 5, 2008 12:06:34 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Manufacturing Order', PrintName='Manufacturing Order',Updated=TO_DATE('2008-08-05 12:06:34','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53276
;

-- Aug 5, 2008 12:06:34 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53276
;

-- Aug 5, 2008 12:06:34 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Order_ID', Name='Manufacturing Order', Description=NULL, Help=NULL WHERE AD_Element_ID=53276
;

-- Aug 5, 2008 12:06:34 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_ID', Name='Manufacturing Order', Description=NULL, Help=NULL, AD_Element_ID=53276 WHERE UPPER(ColumnName)='PP_ORDER_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:06:34 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_ID', Name='Manufacturing Order', Description=NULL, Help=NULL WHERE AD_Element_ID=53276 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:06:34 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Manufacturing Order', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53276) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:06:35 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Manufacturing Order', Name='Manufacturing Order' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53276)
;

-- Aug 5, 2008 12:06:37 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Manufacturing Order Cost',Updated=TO_DATE('2008-08-05 12:06:37','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53297
;

-- Aug 5, 2008 12:06:37 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53297
;

-- Aug 5, 2008 12:06:37 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Order_Cost_ID', Name='Manufacturing Order Cost', Description=NULL, Help=NULL WHERE AD_Element_ID=53297
;

-- Aug 5, 2008 12:06:37 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_Cost_ID', Name='Manufacturing Order Cost', Description=NULL, Help=NULL, AD_Element_ID=53297 WHERE UPPER(ColumnName)='PP_ORDER_COST_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:06:37 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_Cost_ID', Name='Manufacturing Order Cost', Description=NULL, Help=NULL WHERE AD_Element_ID=53297 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:06:37 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Manufacturing Order Cost', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53297) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:06:37 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Order Cost', Name='Manufacturing Order Cost' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53297)
;

-- Aug 5, 2008 12:06:42 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Manufacturing Order BOM',Updated=TO_DATE('2008-08-05 12:06:42','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53298
;

-- Aug 5, 2008 12:06:42 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53298
;

-- Aug 5, 2008 12:06:42 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Order_BOM_ID', Name='Manufacturing Order BOM', Description=NULL, Help=NULL WHERE AD_Element_ID=53298
;

-- Aug 5, 2008 12:06:42 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_BOM_ID', Name='Manufacturing Order BOM', Description=NULL, Help=NULL, AD_Element_ID=53298 WHERE UPPER(ColumnName)='PP_ORDER_BOM_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:06:42 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_BOM_ID', Name='Manufacturing Order BOM', Description=NULL, Help=NULL WHERE AD_Element_ID=53298 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:06:42 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Manufacturing Order BOM', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53298) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:06:42 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Order BOM', Name='Manufacturing Order BOM' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53298)
;

-- Aug 5, 2008 12:06:45 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Manufacturing Order BOM Line',Updated=TO_DATE('2008-08-05 12:06:45','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53275
;

-- Aug 5, 2008 12:06:45 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53275
;

-- Aug 5, 2008 12:06:45 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Order_BOMLine_ID', Name='Manufacturing Order BOM Line', Description=NULL, Help=NULL WHERE AD_Element_ID=53275
;

-- Aug 5, 2008 12:06:45 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_BOMLine_ID', Name='Manufacturing Order BOM Line', Description=NULL, Help=NULL, AD_Element_ID=53275 WHERE UPPER(ColumnName)='PP_ORDER_BOMLINE_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:06:45 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_BOMLine_ID', Name='Manufacturing Order BOM Line', Description=NULL, Help=NULL WHERE AD_Element_ID=53275 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:06:45 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Manufacturing Order BOM Line', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53275) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:06:45 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Order BOM Line', Name='Manufacturing Order BOM Line' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53275)
;

-- Aug 5, 2008 12:06:48 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Manufacturing Order BOM Line MA',Updated=TO_DATE('2008-08-05 12:06:48','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53343
;

-- Aug 5, 2008 12:06:48 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53343
;

-- Aug 5, 2008 12:06:48 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Order_BOMLineMA_ID', Name='Manufacturing Order BOM Line MA', Description=NULL, Help=NULL WHERE AD_Element_ID=53343
;

-- Aug 5, 2008 12:06:48 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_BOMLineMA_ID', Name='Manufacturing Order BOM Line MA', Description=NULL, Help=NULL, AD_Element_ID=53343 WHERE UPPER(ColumnName)='PP_ORDER_BOMLINEMA_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:06:48 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_BOMLineMA_ID', Name='Manufacturing Order BOM Line MA', Description=NULL, Help=NULL WHERE AD_Element_ID=53343 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:06:48 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Manufacturing Order BOM Line MA', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53343) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:06:48 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Order BOM Line MA', Name='Manufacturing Order BOM Line MA' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53343)
;

-- Aug 5, 2008 12:06:56 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Manufacturing Cost Collector', PrintName='Manufacturing Cost Collector',Updated=TO_DATE('2008-08-05 12:06:56','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53310
;

-- Aug 5, 2008 12:06:56 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53310
;

-- Aug 5, 2008 12:06:56 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Cost_Collector_ID', Name='Manufacturing Cost Collector', Description=NULL, Help=NULL WHERE AD_Element_ID=53310
;

-- Aug 5, 2008 12:06:56 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Cost_Collector_ID', Name='Manufacturing Cost Collector', Description=NULL, Help=NULL, AD_Element_ID=53310 WHERE UPPER(ColumnName)='PP_COST_COLLECTOR_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:06:56 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Cost_Collector_ID', Name='Manufacturing Cost Collector', Description=NULL, Help=NULL WHERE AD_Element_ID=53310 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:06:56 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Manufacturing Cost Collector', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53310) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:06:56 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Manufacturing Cost Collector', Name='Manufacturing Cost Collector' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53310)
;

-- Aug 5, 2008 12:07:08 PM CDT
-- Terminology
UPDATE AD_Element SET PrintName='Manufacturing Cost Collector',Updated=TO_DATE('2008-08-05 12:07:08','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53343
;

-- Aug 5, 2008 12:07:08 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53343
;

-- Aug 5, 2008 12:07:08 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Manufacturing Cost Collector', Name='Manufacturing Order BOM Line MA' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53343)
;

-- Aug 5, 2008 12:07:13 PM CDT
-- Terminology
UPDATE AD_Element SET PrintName='Manufacturing Order BOM Line',Updated=TO_DATE('2008-08-05 12:07:13','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53275
;

-- Aug 5, 2008 12:07:13 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53275
;

-- Aug 5, 2008 12:07:13 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Manufacturing Order BOM Line', Name='Manufacturing Order BOM Line' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53275)
;

-- Aug 5, 2008 12:07:17 PM CDT
-- Terminology
UPDATE AD_Element SET PrintName='Manufacturing Order BOM',Updated=TO_DATE('2008-08-05 12:07:17','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53298
;

-- Aug 5, 2008 12:07:17 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53298
;

-- Aug 5, 2008 12:07:17 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Manufacturing Order BOM', Name='Manufacturing Order BOM' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53298)
;

-- Aug 5, 2008 12:07:34 PM CDT
-- Terminology
UPDATE AD_Element SET PrintName='Manufacturing Order Cost',Updated=TO_DATE('2008-08-05 12:07:34','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53297
;

-- Aug 5, 2008 12:07:34 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53297
;

-- Aug 5, 2008 12:07:34 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Manufacturing Order Cost', Name='Manufacturing Order Cost' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53297)
;

-- Aug 5, 2008 12:07:41 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Overlap Units', PrintName='Overlap Units',Updated=TO_DATE('2008-08-05 12:07:41','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53241
;

-- Aug 5, 2008 12:07:41 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53241
;

-- Aug 5, 2008 12:07:41 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='OverlapUnits', Name='Overlap Units', Description=NULL, Help=NULL WHERE AD_Element_ID=53241
;

-- Aug 5, 2008 12:07:41 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='OverlapUnits', Name='Overlap Units', Description=NULL, Help=NULL, AD_Element_ID=53241 WHERE UPPER(ColumnName)='OVERLAPUNITS' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:07:41 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='OverlapUnits', Name='Overlap Units', Description=NULL, Help=NULL WHERE AD_Element_ID=53241 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:07:41 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Overlap Units', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53241) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:07:41 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Overlap Units', Name='Overlap Units' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53241)
;

-- Aug 5, 2008 12:08:03 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Manufacturing Order Activity', PrintName='Manufacturing Order Activity',Updated=TO_DATE('2008-08-05 12:08:03','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53292
;

-- Aug 5, 2008 12:08:03 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53292
;

-- Aug 5, 2008 12:08:03 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Order_Next_ID', Name='Manufacturing Order Activity', Description=NULL, Help=NULL WHERE AD_Element_ID=53292
;

-- Aug 5, 2008 12:08:03 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_Next_ID', Name='Manufacturing Order Activity', Description=NULL, Help=NULL, AD_Element_ID=53292 WHERE UPPER(ColumnName)='PP_ORDER_NEXT_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:08:03 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_Next_ID', Name='Manufacturing Order Activity', Description=NULL, Help=NULL WHERE AD_Element_ID=53292 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:08:03 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Manufacturing Order Activity', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53292) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:08:03 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Manufacturing Order Activity', Name='Manufacturing Order Activity' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53292)
;

-- Aug 5, 2008 12:08:14 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Manufacturing Order Activity Next', PrintName='Manufacturing Order Activity Next',Updated=TO_DATE('2008-08-05 12:08:14','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53293
;

-- Aug 5, 2008 12:08:14 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53293
;

-- Aug 5, 2008 12:08:14 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Order_NodeNext_ID', Name='Manufacturing Order Activity Next', Description=NULL, Help=NULL WHERE AD_Element_ID=53293
;

-- Aug 5, 2008 12:08:14 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_NodeNext_ID', Name='Manufacturing Order Activity Next', Description=NULL, Help=NULL, AD_Element_ID=53293 WHERE UPPER(ColumnName)='PP_ORDER_NODENEXT_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:08:14 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_NodeNext_ID', Name='Manufacturing Order Activity Next', Description=NULL, Help=NULL WHERE AD_Element_ID=53293 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:08:14 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Manufacturing Order Activity Next', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53293) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:08:14 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Manufacturing Order Activity Next', Name='Manufacturing Order Activity Next' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53293)
;

-- Aug 5, 2008 12:08:29 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Manufacturing Order Activity Asset', PrintName='Manufacturing Order Activity Asset',Updated=TO_DATE('2008-08-05 12:08:29','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53304
;

-- Aug 5, 2008 12:08:29 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53304
;

-- Aug 5, 2008 12:08:29 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Order_Node_Asset_ID', Name='Manufacturing Order Activity Asset', Description=NULL, Help=NULL WHERE AD_Element_ID=53304
;

-- Aug 5, 2008 12:08:29 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_Node_Asset_ID', Name='Manufacturing Order Activity Asset', Description=NULL, Help=NULL, AD_Element_ID=53304 WHERE UPPER(ColumnName)='PP_ORDER_NODE_ASSET_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:08:29 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_Node_Asset_ID', Name='Manufacturing Order Activity Asset', Description=NULL, Help=NULL WHERE AD_Element_ID=53304 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:08:29 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Manufacturing Order Activity Asset', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53304) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:08:29 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Manufacturing Order Activity Asset', Name='Manufacturing Order Activity Asset' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53304)
;

-- Aug 5, 2008 12:08:58 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Manufacturing Order Activity Next', PrintName='Manufacturing Order Activity Next',Updated=TO_DATE('2008-08-05 12:08:58','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53292
;

-- Aug 5, 2008 12:08:58 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53292
;

-- Aug 5, 2008 12:08:58 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Order_Next_ID', Name='Manufacturing Order Activity Next', Description=NULL, Help=NULL WHERE AD_Element_ID=53292
;

-- Aug 5, 2008 12:08:58 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_Next_ID', Name='Manufacturing Order Activity Next', Description=NULL, Help=NULL, AD_Element_ID=53292 WHERE UPPER(ColumnName)='PP_ORDER_NEXT_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:08:58 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_Next_ID', Name='Manufacturing Order Activity Next', Description=NULL, Help=NULL WHERE AD_Element_ID=53292 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:08:58 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Manufacturing Order Activity Next', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53292) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:08:58 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Manufacturing Order Activity Next', Name='Manufacturing Order Activity Next' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53292)
;

-- Aug 5, 2008 12:09:18 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Manufacturing Order Activity Product', PrintName='Manufacturing Order Activity Product',Updated=TO_DATE('2008-08-05 12:09:18','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53303
;

-- Aug 5, 2008 12:09:18 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53303
;

-- Aug 5, 2008 12:09:18 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Order_Node_Product_ID', Name='Manufacturing Order Activity Product', Description=NULL, Help=NULL WHERE AD_Element_ID=53303
;

-- Aug 5, 2008 12:09:18 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_Node_Product_ID', Name='Manufacturing Order Activity Product', Description=NULL, Help=NULL, AD_Element_ID=53303 WHERE UPPER(ColumnName)='PP_ORDER_NODE_PRODUCT_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:09:18 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_Node_Product_ID', Name='Manufacturing Order Activity Product', Description=NULL, Help=NULL WHERE AD_Element_ID=53303 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:09:18 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Manufacturing Order Activity Product', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53303) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:09:18 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Manufacturing Order Activity Product', Name='Manufacturing Order Activity Product' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53303)
;

-- Aug 5, 2008 12:09:38 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Manufacturing Order Workflow', PrintName='Manufacturing Order Workflow',Updated=TO_DATE('2008-08-05 12:09:38','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53286
;

-- Aug 5, 2008 12:09:38 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53286
;

-- Aug 5, 2008 12:09:38 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Order_Workflow_ID', Name='Manufacturing Order Workflow', Description=NULL, Help=NULL WHERE AD_Element_ID=53286
;

-- Aug 5, 2008 12:09:38 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_Workflow_ID', Name='Manufacturing Order Workflow', Description=NULL, Help=NULL, AD_Element_ID=53286 WHERE UPPER(ColumnName)='PP_ORDER_WORKFLOW_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:09:38 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Order_Workflow_ID', Name='Manufacturing Order Workflow', Description=NULL, Help=NULL WHERE AD_Element_ID=53286 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:09:38 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Manufacturing Order Workflow', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53286) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:09:38 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Manufacturing Order Workflow', Name='Manufacturing Order Workflow' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53286)
;

-- Aug 5, 2008 12:09:50 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Product Planning', PrintName='Product Planning',Updated=TO_DATE('2008-08-05 12:09:50','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53268
;

-- Aug 5, 2008 12:09:50 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53268
;

-- Aug 5, 2008 12:09:50 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_Product_Planning_ID', Name='Product Planning', Description=NULL, Help=NULL WHERE AD_Element_ID=53268
;

-- Aug 5, 2008 12:09:50 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Product_Planning_ID', Name='Product Planning', Description=NULL, Help=NULL, AD_Element_ID=53268 WHERE UPPER(ColumnName)='PP_PRODUCT_PLANNING_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:09:50 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_Product_Planning_ID', Name='Product Planning', Description=NULL, Help=NULL WHERE AD_Element_ID=53268 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:09:50 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Product Planning', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53268) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:09:50 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Product Planning', Name='Product Planning' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53268)
;

-- Aug 5, 2008 12:10:09 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Workflow Node Asset', PrintName='Workflow Node Asset',Updated=TO_DATE('2008-08-05 12:10:09','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53236
;

-- Aug 5, 2008 12:10:09 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53236
;

-- Aug 5, 2008 12:10:09 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_WF_Node_Asset_ID', Name='Workflow Node Asset', Description=NULL, Help=NULL WHERE AD_Element_ID=53236
;

-- Aug 5, 2008 12:10:09 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_WF_Node_Asset_ID', Name='Workflow Node Asset', Description=NULL, Help=NULL, AD_Element_ID=53236 WHERE UPPER(ColumnName)='PP_WF_NODE_ASSET_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:10:09 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_WF_Node_Asset_ID', Name='Workflow Node Asset', Description=NULL, Help=NULL WHERE AD_Element_ID=53236 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:10:09 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Workflow Node Asset', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53236) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:10:09 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Workflow Node Asset', Name='Workflow Node Asset' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53236)
;

-- Aug 5, 2008 12:10:28 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Workflow Node Product', PrintName='Workflow Node Product',Updated=TO_DATE('2008-08-05 12:10:28','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53235
;

-- Aug 5, 2008 12:10:28 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53235
;

-- Aug 5, 2008 12:10:28 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PP_WF_Node_Product_ID', Name='Workflow Node Product', Description=NULL, Help=NULL WHERE AD_Element_ID=53235
;

-- Aug 5, 2008 12:10:28 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_WF_Node_Product_ID', Name='Workflow Node Product', Description=NULL, Help=NULL, AD_Element_ID=53235 WHERE UPPER(ColumnName)='PP_WF_NODE_PRODUCT_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:10:28 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PP_WF_Node_Product_ID', Name='Workflow Node Product', Description=NULL, Help=NULL WHERE AD_Element_ID=53235 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:10:28 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Workflow Node Product', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53235) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:10:28 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Workflow Node Product', Name='Workflow Node Product' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53235)
;

-- Aug 5, 2008 12:10:43 PM CDT
-- Terminology
UPDATE AD_Element SET Name='% Utilization', PrintName='% Utilization',Updated=TO_DATE('2008-08-05 12:10:43','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53230
;

-- Aug 5, 2008 12:10:43 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53230
;

-- Aug 5, 2008 12:10:43 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PercentUtilization', Name='% Utilization', Description=NULL, Help=NULL WHERE AD_Element_ID=53230
;

-- Aug 5, 2008 12:10:43 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PercentUtilization', Name='% Utilization', Description=NULL, Help=NULL, AD_Element_ID=53230 WHERE UPPER(ColumnName)='PERCENTUTILIZATION' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:10:43 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PercentUtilization', Name='% Utilization', Description=NULL, Help=NULL WHERE AD_Element_ID=53230 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:10:43 PM CDT
-- Terminology
UPDATE AD_Field SET Name='% Utilization', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53230) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:10:43 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='% Utilization', Name='% Utilization' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53230)
;

-- Aug 5, 2008 12:10:49 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Process Type', PrintName='Process Type',Updated=TO_DATE('2008-08-05 12:10:49','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53242
;

-- Aug 5, 2008 12:10:49 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53242
;

-- Aug 5, 2008 12:10:49 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='ProcessType', Name='Process Type', Description=NULL, Help=NULL WHERE AD_Element_ID=53242
;

-- Aug 5, 2008 12:10:49 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='ProcessType', Name='Process Type', Description=NULL, Help=NULL, AD_Element_ID=53242 WHERE UPPER(ColumnName)='PROCESSTYPE' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:10:49 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='ProcessType', Name='Process Type', Description=NULL, Help=NULL WHERE AD_Element_ID=53242 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:10:49 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Process Type', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53242) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:10:49 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Process Type', Name='Process Type' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53242)
;

-- Aug 5, 2008 12:11:05 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Quality Specification', PrintName='Quality Specification',Updated=TO_DATE('2008-08-05 12:11:05','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53314
;

-- Aug 5, 2008 12:11:05 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53314
;

-- Aug 5, 2008 12:11:05 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='QM_Specification_ID', Name='Quality Specification', Description=NULL, Help=NULL WHERE AD_Element_ID=53314
;

-- Aug 5, 2008 12:11:05 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QM_Specification_ID', Name='Quality Specification', Description=NULL, Help=NULL, AD_Element_ID=53314 WHERE UPPER(ColumnName)='QM_SPECIFICATION_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:11:05 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QM_Specification_ID', Name='Quality Specification', Description=NULL, Help=NULL WHERE AD_Element_ID=53314 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:11:05 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Quality Specification', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53314) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:11:05 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Quality Specification', Name='Quality Specification' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53314)
;

-- Aug 5, 2008 12:11:21 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Qty Batch Size', PrintName='Qty Batch Size',Updated=TO_DATE('2008-08-05 12:11:21','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53243
;

-- Aug 5, 2008 12:11:21 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53243
;

-- Aug 5, 2008 12:11:21 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='QtyBatchSize', Name='Qty Batch Size', Description=NULL, Help=NULL WHERE AD_Element_ID=53243
;

-- Aug 5, 2008 12:11:21 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyBatchSize', Name='Qty Batch Size', Description=NULL, Help=NULL, AD_Element_ID=53243 WHERE UPPER(ColumnName)='QTYBATCHSIZE' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:11:21 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyBatchSize', Name='Qty Batch Size', Description=NULL, Help=NULL WHERE AD_Element_ID=53243 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:11:21 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Qty Batch Size', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53243) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:11:21 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Qty Batch Size', Name='Qty Batch Size' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53243)
;

-- Aug 5, 2008 12:11:25 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Qty Batchs', PrintName='Qty Batchs',Updated=TO_DATE('2008-08-05 12:11:25','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53302
;

-- Aug 5, 2008 12:11:25 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53302
;

-- Aug 5, 2008 12:11:25 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='QtyBatchs', Name='Qty Batchs', Description=NULL, Help=NULL WHERE AD_Element_ID=53302
;

-- Aug 5, 2008 12:11:25 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyBatchs', Name='Qty Batchs', Description=NULL, Help=NULL, AD_Element_ID=53302 WHERE UPPER(ColumnName)='QTYBATCHS' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:11:25 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyBatchs', Name='Qty Batchs', Description=NULL, Help=NULL WHERE AD_Element_ID=53302 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:11:25 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Qty Batchs', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53302) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:11:25 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Qty Batchs', Name='Qty Batchs' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53302)
;

-- Aug 5, 2008 12:11:31 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Qty Delivered Line', PrintName='Qty Delivered Line',Updated=TO_DATE('2008-08-05 12:11:31','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53305
;

-- Aug 5, 2008 12:11:31 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53305
;

-- Aug 5, 2008 12:11:31 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='QtyDeliveredLine', Name='Qty Delivered Line', Description=NULL, Help=NULL WHERE AD_Element_ID=53305
;

-- Aug 5, 2008 12:11:31 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyDeliveredLine', Name='Qty Delivered Line', Description=NULL, Help=NULL, AD_Element_ID=53305 WHERE UPPER(ColumnName)='QTYDELIVEREDLINE' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:11:31 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyDeliveredLine', Name='Qty Delivered Line', Description=NULL, Help=NULL WHERE AD_Element_ID=53305 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:11:31 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Qty Delivered Line', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53305) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:11:32 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Qty Delivered Line', Name='Qty Delivered Line' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53305)
;

-- Aug 5, 2008 12:11:41 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Qty In Transit', PrintName='Qty In Transit',Updated=TO_DATE('2008-08-05 12:11:41','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53312
;

-- Aug 5, 2008 12:11:41 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53312
;

-- Aug 5, 2008 12:11:41 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='QtyInTransit', Name='Qty In Transit', Description=NULL, Help=NULL WHERE AD_Element_ID=53312
;

-- Aug 5, 2008 12:11:41 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyInTransit', Name='Qty In Transit', Description=NULL, Help=NULL, AD_Element_ID=53312 WHERE UPPER(ColumnName)='QTYINTRANSIT' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:11:41 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyInTransit', Name='Qty In Transit', Description=NULL, Help=NULL WHERE AD_Element_ID=53312 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:11:41 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Qty In Transit', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53312) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:11:41 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Qty In Transit', Name='Qty In Transit' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53312)
;

-- Aug 5, 2008 12:11:56 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Qty Issue Scrap Should Be', PrintName='Qty Issue Scrap Should Be',Updated=TO_DATE('2008-08-05 12:11:56','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53306
;

-- Aug 5, 2008 12:11:56 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53306
;

-- Aug 5, 2008 12:11:56 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='QtyIssueScrapShouldBe', Name='Qty Issue Scrap Should Be', Description=NULL, Help=NULL WHERE AD_Element_ID=53306
;

-- Aug 5, 2008 12:11:56 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyIssueScrapShouldBe', Name='Qty Issue Scrap Should Be', Description=NULL, Help=NULL, AD_Element_ID=53306 WHERE UPPER(ColumnName)='QTYISSUESCRAPSHOULDBE' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:11:56 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyIssueScrapShouldBe', Name='Qty Issue Scrap Should Be', Description=NULL, Help=NULL WHERE AD_Element_ID=53306 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:11:56 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Qty Issue Scrap Should Be', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53306) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:11:56 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Qty Issue Scrap Should Be', Name='Qty Issue Scrap Should Be' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53306)
;

-- Aug 5, 2008 12:12:09 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Qty Issue Should Be', PrintName='Qty Issue Should Be',Updated=TO_DATE('2008-08-05 12:12:09','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53307
;

-- Aug 5, 2008 12:12:09 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53307
;

-- Aug 5, 2008 12:12:09 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='QtyIssueShouldBe', Name='Qty Issue Should Be', Description=NULL, Help=NULL WHERE AD_Element_ID=53307
;

-- Aug 5, 2008 12:12:09 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyIssueShouldBe', Name='Qty Issue Should Be', Description=NULL, Help=NULL, AD_Element_ID=53307 WHERE UPPER(ColumnName)='QTYISSUESHOULDBE' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:12:09 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyIssueShouldBe', Name='Qty Issue Should Be', Description=NULL, Help=NULL WHERE AD_Element_ID=53307 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:12:09 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Qty Issue Should Be', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53307) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:12:10 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Qty Issue Should Be', Name='Qty Issue Should Be' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53307)
;

-- Aug 5, 2008 12:12:13 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Qty Post', PrintName='Qty Post',Updated=TO_DATE('2008-08-05 12:12:13','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53299
;

-- Aug 5, 2008 12:12:13 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53299
;

-- Aug 5, 2008 12:12:13 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='QtyPost', Name='Qty Post', Description=NULL, Help=NULL WHERE AD_Element_ID=53299
;

-- Aug 5, 2008 12:12:13 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyPost', Name='Qty Post', Description=NULL, Help=NULL, AD_Element_ID=53299 WHERE UPPER(ColumnName)='QTYPOST' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:12:13 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyPost', Name='Qty Post', Description=NULL, Help=NULL WHERE AD_Element_ID=53299 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:12:13 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Qty Post', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53299) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:12:13 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Qty Post', Name='Qty Post' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53299)
;

-- Aug 5, 2008 12:12:17 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Qty Reject', PrintName='Qty Reject',Updated=TO_DATE('2008-08-05 12:12:17','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53287
;

-- Aug 5, 2008 12:12:17 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53287
;

-- Aug 5, 2008 12:12:17 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='QtyReject', Name='Qty Reject', Description=NULL, Help=NULL WHERE AD_Element_ID=53287
;

-- Aug 5, 2008 12:12:17 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyReject', Name='Qty Reject', Description=NULL, Help=NULL, AD_Element_ID=53287 WHERE UPPER(ColumnName)='QTYREJECT' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:12:17 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyReject', Name='Qty Reject', Description=NULL, Help=NULL WHERE AD_Element_ID=53287 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:12:17 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Qty Reject', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53287) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:12:17 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Qty Reject', Name='Qty Reject' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53287)
;

-- Aug 5, 2008 12:12:21 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Qty Requiered', PrintName='Qty Required',Updated=TO_DATE('2008-08-05 12:12:21','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53288
;

-- Aug 5, 2008 12:12:21 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53288
;

-- Aug 5, 2008 12:12:21 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='QtyRequiered', Name='Qty Requiered', Description=NULL, Help=NULL WHERE AD_Element_ID=53288
;

-- Aug 5, 2008 12:12:21 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyRequiered', Name='Qty Requiered', Description=NULL, Help=NULL, AD_Element_ID=53288 WHERE UPPER(ColumnName)='QTYREQUIERED' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:12:21 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyRequiered', Name='Qty Requiered', Description=NULL, Help=NULL WHERE AD_Element_ID=53288 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:12:21 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Qty Requiered', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53288) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:12:21 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Qty Required', Name='Qty Requiered' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53288)
;

-- Aug 5, 2008 12:12:26 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Qty Scrap', PrintName='Qty Scrap',Updated=TO_DATE('2008-08-05 12:12:26','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53289
;

-- Aug 5, 2008 12:12:26 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53289
;

-- Aug 5, 2008 12:12:26 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='QtyScrap', Name='Qty Scrap', Description=NULL, Help=NULL WHERE AD_Element_ID=53289
;

-- Aug 5, 2008 12:12:26 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyScrap', Name='Qty Scrap', Description=NULL, Help=NULL, AD_Element_ID=53289 WHERE UPPER(ColumnName)='QTYSCRAP' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:12:26 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyScrap', Name='Qty Scrap', Description=NULL, Help=NULL WHERE AD_Element_ID=53289 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:12:26 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Qty Scrap', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53289) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:12:26 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Qty Scrap', Name='Qty Scrap' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53289)
;

-- Aug 5, 2008 12:12:40 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Qty Scrap Line', PrintName='Qty Scrap Line',Updated=TO_DATE('2008-08-05 12:12:40','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53308
;

-- Aug 5, 2008 12:12:40 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53308
;

-- Aug 5, 2008 12:12:40 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='QtyScrapLine', Name='Qty Scrap Line', Description=NULL, Help=NULL WHERE AD_Element_ID=53308
;

-- Aug 5, 2008 12:12:40 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyScrapLine', Name='Qty Scrap Line', Description=NULL, Help=NULL, AD_Element_ID=53308 WHERE UPPER(ColumnName)='QTYSCRAPLINE' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:12:40 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyScrapLine', Name='Qty Scrap Line', Description=NULL, Help=NULL WHERE AD_Element_ID=53308 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:12:40 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Qty Scrap Line', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53308) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:12:40 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Qty Scrap Line', Name='Qty Scrap Line' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53308)
;

-- Aug 5, 2008 12:12:54 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Units Cycles', PrintName='Units Cycles',Updated=TO_DATE('2008-08-05 12:12:54','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53239
;

-- Aug 5, 2008 12:12:54 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53239
;

-- Aug 5, 2008 12:12:54 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='UnitsCycles', Name='Units Cycles', Description=NULL, Help=NULL WHERE AD_Element_ID=53239
;

-- Aug 5, 2008 12:12:54 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='UnitsCycles', Name='Units Cycles', Description=NULL, Help=NULL, AD_Element_ID=53239 WHERE UPPER(ColumnName)='UNITSCYCLES' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:12:54 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='UnitsCycles', Name='Units Cycles', Description=NULL, Help=NULL WHERE AD_Element_ID=53239 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:12:54 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Units Cycles', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53239) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:12:54 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Units Cycles', Name='Units Cycles' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53239)
;

-- Aug 5, 2008 12:13:10 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Temporal MRP & CRP', PrintName='Temporal MRP & CRP',Updated=TO_DATE('2008-08-05 12:13:10','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53317
;

-- Aug 5, 2008 12:13:10 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53317
;

-- Aug 5, 2008 12:13:10 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='T_MRP_CRP_ID', Name='Temporal MRP & CRP', Description=NULL, Help=NULL WHERE AD_Element_ID=53317
;

-- Aug 5, 2008 12:13:10 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='T_MRP_CRP_ID', Name='Temporal MRP & CRP', Description=NULL, Help=NULL, AD_Element_ID=53317 WHERE UPPER(ColumnName)='T_MRP_CRP_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:13:10 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='T_MRP_CRP_ID', Name='Temporal MRP & CRP', Description=NULL, Help=NULL WHERE AD_Element_ID=53317 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:13:10 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Temporal MRP & CRP', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53317) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:13:10 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Temporal MRP & CRP', Name='Temporal MRP & CRP' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53317)
;

-- Aug 5, 2008 12:13:18 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Temporal BOM Line',Updated=TO_DATE('2008-08-05 12:13:18','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53319
;

-- Aug 5, 2008 12:13:18 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53319
;

-- Aug 5, 2008 12:13:18 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='T_BOMLine_ID', Name='Temporal BOM Line', Description=NULL, Help=NULL WHERE AD_Element_ID=53319
;

-- Aug 5, 2008 12:13:18 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='T_BOMLine_ID', Name='Temporal BOM Line', Description=NULL, Help=NULL, AD_Element_ID=53319 WHERE UPPER(ColumnName)='T_BOMLINE_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:13:18 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='T_BOMLine_ID', Name='Temporal BOM Line', Description=NULL, Help=NULL WHERE AD_Element_ID=53319 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:13:18 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Temporal BOM Line', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53319) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:13:18 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='T_BOMLine_ID', Name='Temporal BOM Line' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53319)
;

-- Aug 5, 2008 12:13:25 PM CDT
-- Terminology
UPDATE AD_Element SET PrintName='Temporal BOM Line',Updated=TO_DATE('2008-08-05 12:13:25','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53319
;

-- Aug 5, 2008 12:13:25 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53319
;

-- Aug 5, 2008 12:13:25 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Temporal BOM Line', Name='Temporal BOM Line' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53319)
;

-- Aug 5, 2008 12:14:34 PM CDT
-- Terminology
UPDATE AD_Element SET Description=NULL, Name='Product',Updated=TO_DATE('2008-08-05 12:14:34','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53465
;

-- Aug 5, 2008 12:14:34 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53465
;

-- Aug 5, 2008 12:14:34 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='TM_Product_ID', Name='Product', Description=NULL, Help=NULL WHERE AD_Element_ID=53465
;

-- Aug 5, 2008 12:14:34 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='TM_Product_ID', Name='Product', Description=NULL, Help=NULL, AD_Element_ID=53465 WHERE UPPER(ColumnName)='TM_PRODUCT_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:14:34 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='TM_Product_ID', Name='Product', Description=NULL, Help=NULL WHERE AD_Element_ID=53465 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:14:34 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Product', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53465) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:14:34 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Product', Name='Product' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53465)
;

-- Aug 5, 2008 12:15:03 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Current Cost Price Lower Level', PrintName='Current Cost Price Lower Level',Updated=TO_DATE('2008-08-05 12:15:03','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53296
;

-- Aug 5, 2008 12:15:03 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53296
;

-- Aug 5, 2008 12:15:03 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='CurrentCostPriceLL', Name='Current Cost Price Lower Level', Description=NULL, Help=NULL WHERE AD_Element_ID=53296
;

-- Aug 5, 2008 12:15:03 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='CurrentCostPriceLL', Name='Current Cost Price Lower Level', Description=NULL, Help=NULL, AD_Element_ID=53296 WHERE UPPER(ColumnName)='CURRENTCOSTPRICELL' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:15:03 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='CurrentCostPriceLL', Name='Current Cost Price Lower Level', Description=NULL, Help=NULL WHERE AD_Element_ID=53296 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:15:03 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Current Cost Price Lower Level', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53296) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:15:03 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Current Cost Price Lower Level', Name='Current Cost Price Lower Level' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53296)
;

-- Aug 5, 2008 12:15:07 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Cumulated Amt Post',Updated=TO_DATE('2008-08-05 12:15:07','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53294
;

-- Aug 5, 2008 12:15:07 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53294
;

-- Aug 5, 2008 12:15:07 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='CumulatedAmtPost', Name='Cumulated Amt Post', Description=NULL, Help=NULL WHERE AD_Element_ID=53294
;

-- Aug 5, 2008 12:15:07 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='CumulatedAmtPost', Name='Cumulated Amt Post', Description=NULL, Help=NULL, AD_Element_ID=53294 WHERE UPPER(ColumnName)='CUMULATEDAMTPOST' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:15:07 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='CumulatedAmtPost', Name='Cumulated Amt Post', Description=NULL, Help=NULL WHERE AD_Element_ID=53294 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:15:07 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Cumulated Amt Post', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53294) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:15:07 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='CumulatedAmtPost', Name='Cumulated Amt Post' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53294)
;

-- Aug 5, 2008 12:15:10 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Cumulated Qty Post',Updated=TO_DATE('2008-08-05 12:15:10','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53295
;

-- Aug 5, 2008 12:15:10 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53295
;

-- Aug 5, 2008 12:15:10 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='CumulatedQtyPost', Name='Cumulated Qty Post', Description=NULL, Help=NULL WHERE AD_Element_ID=53295
;

-- Aug 5, 2008 12:15:10 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='CumulatedQtyPost', Name='Cumulated Qty Post', Description=NULL, Help=NULL, AD_Element_ID=53295 WHERE UPPER(ColumnName)='CUMULATEDQTYPOST' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:15:10 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='CumulatedQtyPost', Name='Cumulated Qty Post', Description=NULL, Help=NULL WHERE AD_Element_ID=53295 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:15:10 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Cumulated Qty Post', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53295) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:15:10 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='CumulatedQtyPost', Name='Cumulated Qty Post' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53295)
;

-- Aug 5, 2008 12:15:13 PM CDT
-- Terminology
UPDATE AD_Element SET PrintName='Cumulated Amt Post',Updated=TO_DATE('2008-08-05 12:15:13','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53294
;

-- Aug 5, 2008 12:15:13 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53294
;

-- Aug 5, 2008 12:15:13 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Cumulated Amt Post', Name='Cumulated Amt Post' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53294)
;

-- Aug 5, 2008 12:15:21 PM CDT
-- Terminology
UPDATE AD_Element SET PrintName='Cumulated Qty Post',Updated=TO_DATE('2008-08-05 12:15:21','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53295
;

-- Aug 5, 2008 12:15:21 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53295
;

-- Aug 5, 2008 12:15:21 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Cumulated Qty Post', Name='Cumulated Qty Post' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53295)
;

-- Aug 5, 2008 12:15:26 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Daily Capacity', PrintName='Daily Capacity',Updated=TO_DATE('2008-08-05 12:15:26','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53231
;

-- Aug 5, 2008 12:15:26 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53231
;

-- Aug 5, 2008 12:15:26 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='DailyCapacity', Name='Daily Capacity', Description=NULL, Help=NULL WHERE AD_Element_ID=53231
;

-- Aug 5, 2008 12:15:26 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='DailyCapacity', Name='Daily Capacity', Description=NULL, Help=NULL, AD_Element_ID=53231 WHERE UPPER(ColumnName)='DAILYCAPACITY' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:15:26 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='DailyCapacity', Name='Daily Capacity', Description=NULL, Help=NULL WHERE AD_Element_ID=53231 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:15:26 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Daily Capacity', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53231) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:15:26 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Daily Capacity', Name='Daily Capacity' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53231)
;

-- Aug 5, 2008 12:15:29 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Duration Real', PrintName='Duration Real',Updated=TO_DATE('2008-08-05 12:15:29','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53283
;

-- Aug 5, 2008 12:15:29 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53283
;

-- Aug 5, 2008 12:15:29 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='DurationReal', Name='Duration Real', Description=NULL, Help=NULL WHERE AD_Element_ID=53283
;

-- Aug 5, 2008 12:15:29 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='DurationReal', Name='Duration Real', Description=NULL, Help=NULL, AD_Element_ID=53283 WHERE UPPER(ColumnName)='DURATIONREAL' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:15:29 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='DurationReal', Name='Duration Real', Description=NULL, Help=NULL WHERE AD_Element_ID=53283 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:15:29 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Duration Real', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53283) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:15:30 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Duration Real', Name='Duration Real' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53283)
;

-- Aug 5, 2008 12:15:36 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Duration Requiered', PrintName='Duration Requiered',Updated=TO_DATE('2008-08-05 12:15:36','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53284
;

-- Aug 5, 2008 12:15:36 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53284
;

-- Aug 5, 2008 12:15:36 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='DurationRequiered', Name='Duration Requiered', Description=NULL, Help=NULL WHERE AD_Element_ID=53284
;

-- Aug 5, 2008 12:15:36 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='DurationRequiered', Name='Duration Requiered', Description=NULL, Help=NULL, AD_Element_ID=53284 WHERE UPPER(ColumnName)='DURATIONREQUIERED' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:15:36 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='DurationRequiered', Name='Duration Requiered', Description=NULL, Help=NULL WHERE AD_Element_ID=53284 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:15:36 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Duration Requiered', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53284) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:15:36 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Duration Requiered', Name='Duration Requiered' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53284)
;

-- Aug 5, 2008 12:15:42 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Float After', PrintName='Float After',Updated=TO_DATE('2008-08-05 12:15:42','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53300
;

-- Aug 5, 2008 12:15:42 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53300
;

-- Aug 5, 2008 12:15:42 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='FloatAfter', Name='Float After', Description=NULL, Help=NULL WHERE AD_Element_ID=53300
;

-- Aug 5, 2008 12:15:42 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='FloatAfter', Name='Float After', Description=NULL, Help=NULL, AD_Element_ID=53300 WHERE UPPER(ColumnName)='FLOATAFTER' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:15:42 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='FloatAfter', Name='Float After', Description=NULL, Help=NULL WHERE AD_Element_ID=53300 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:15:42 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Float After', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53300) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:15:42 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Float After', Name='Float After' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53300)
;

-- Aug 5, 2008 12:15:51 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Float Befored', PrintName='Float Befored',Updated=TO_DATE('2008-08-05 12:15:51','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53301
;

-- Aug 5, 2008 12:15:51 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53301
;

-- Aug 5, 2008 12:15:51 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='FloatBefored', Name='Float Befored', Description=NULL, Help=NULL WHERE AD_Element_ID=53301
;

-- Aug 5, 2008 12:15:51 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='FloatBefored', Name='Float Befored', Description=NULL, Help=NULL, AD_Element_ID=53301 WHERE UPPER(ColumnName)='FLOATBEFORED' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:15:51 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='FloatBefored', Name='Float Befored', Description=NULL, Help=NULL WHERE AD_Element_ID=53301 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:15:51 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Float Befored', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53301) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:15:51 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Float Befored', Name='Float Befored' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53301)
;

-- Aug 5, 2008 12:15:58 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Is BatchTime', PrintName='Is BatchTime',Updated=TO_DATE('2008-08-05 12:15:58','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53309
;

-- Aug 5, 2008 12:15:58 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53309
;

-- Aug 5, 2008 12:15:58 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='IsBatchTime', Name='Is BatchTime', Description=NULL, Help=NULL WHERE AD_Element_ID=53309
;

-- Aug 5, 2008 12:15:58 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='IsBatchTime', Name='Is BatchTime', Description=NULL, Help=NULL, AD_Element_ID=53309 WHERE UPPER(ColumnName)='ISBATCHTIME' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:15:58 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='IsBatchTime', Name='Is BatchTime', Description=NULL, Help=NULL WHERE AD_Element_ID=53309 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:15:58 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Is BatchTime', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53309) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:15:58 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Is BatchTime', Name='Is BatchTime' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53309)
;

-- Aug 5, 2008 12:16:14 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Is Milestone', PrintName='Is Milestone',Updated=TO_DATE('2008-08-05 12:16:14','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53237
;

-- Aug 5, 2008 12:16:14 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53237
;

-- Aug 5, 2008 12:16:14 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='IsMilestone', Name='Is Milestone', Description=NULL, Help=NULL WHERE AD_Element_ID=53237
;

-- Aug 5, 2008 12:16:14 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='IsMilestone', Name='Is Milestone', Description=NULL, Help=NULL, AD_Element_ID=53237 WHERE UPPER(ColumnName)='ISMILESTONE' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:16:14 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='IsMilestone', Name='Is Milestone', Description=NULL, Help=NULL WHERE AD_Element_ID=53237 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:16:14 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Is Milestone', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53237) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:16:14 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Is Milestone', Name='Is Milestone' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53237)
;

-- Aug 5, 2008 12:16:22 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Is Subcontracting', PrintName='Is Subcontracting',Updated=TO_DATE('2008-08-05 12:16:22','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53238
;

-- Aug 5, 2008 12:16:22 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53238
;

-- Aug 5, 2008 12:16:22 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='IsSubcontracting', Name='Is Subcontracting', Description=NULL, Help=NULL WHERE AD_Element_ID=53238
;

-- Aug 5, 2008 12:16:22 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='IsSubcontracting', Name='Is Subcontracting', Description=NULL, Help=NULL, AD_Element_ID=53238 WHERE UPPER(ColumnName)='ISSUBCONTRACTING' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:16:22 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='IsSubcontracting', Name='Is Subcontracting', Description=NULL, Help=NULL WHERE AD_Element_ID=53238 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:16:22 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Is Subcontracting', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53238) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:16:22 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Is Subcontracting', Name='Is Subcontracting' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53238)
;

-- Aug 5, 2008 12:16:27 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Low Level', PrintName='Low Level',Updated=TO_DATE('2008-08-05 12:16:27','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53274
;

-- Aug 5, 2008 12:16:27 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53274
;

-- Aug 5, 2008 12:16:27 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='LowLevel', Name='Low Level', Description=NULL, Help=NULL WHERE AD_Element_ID=53274
;

-- Aug 5, 2008 12:16:27 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='LowLevel', Name='Low Level', Description=NULL, Help=NULL, AD_Element_ID=53274 WHERE UPPER(ColumnName)='LOWLEVEL' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:16:27 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='LowLevel', Name='Low Level', Description=NULL, Help=NULL WHERE AD_Element_ID=53274 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:16:27 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Low Level', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53274) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:16:27 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Low Level', Name='Low Level' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53274)
;

-- Aug 5, 2008 12:16:47 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Moving Time', PrintName='Moving Time',Updated=TO_DATE('2008-08-05 12:16:47','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53240
;

-- Aug 5, 2008 12:16:47 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53240
;

-- Aug 5, 2008 12:16:47 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='MovingTime', Name='Moving Time', Description=NULL, Help=NULL WHERE AD_Element_ID=53240
;

-- Aug 5, 2008 12:16:47 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='MovingTime', Name='Moving Time', Description=NULL, Help=NULL, AD_Element_ID=53240 WHERE UPPER(ColumnName)='MOVINGTIME' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:16:47 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='MovingTime', Name='Moving Time', Description=NULL, Help=NULL WHERE AD_Element_ID=53240 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:16:47 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Moving Time', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53240) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:16:47 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Moving Time', Name='Moving Time' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53240)
;

-- Aug 5, 2008 12:17:08 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Quantity in %', PrintName='Quantity in %',Updated=TO_DATE('2008-08-05 12:17:08','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53256
;

-- Aug 5, 2008 12:17:08 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53256
;

-- Aug 5, 2008 12:17:08 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='QtyBatch', Name='Quantity in %', Description='Indicate the Quantity % use in this Formula', Help='Exist two way the add a compenent to a BOM or Formula:

1.- Adding a Component based in quantity to use in this BOM
2.- Adding a Component based in % to use the Order Quantity of Manufacturing Order in this Formula.
' WHERE AD_Element_ID=53256
;

-- Aug 5, 2008 12:17:08 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyBatch', Name='Quantity in %', Description='Indicate the Quantity % use in this Formula', Help='Exist two way the add a compenent to a BOM or Formula:

1.- Adding a Component based in quantity to use in this BOM
2.- Adding a Component based in % to use the Order Quantity of Manufacturing Order in this Formula.
', AD_Element_ID=53256 WHERE UPPER(ColumnName)='QTYBATCH' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:17:08 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QtyBatch', Name='Quantity in %', Description='Indicate the Quantity % use in this Formula', Help='Exist two way the add a compenent to a BOM or Formula:

1.- Adding a Component based in quantity to use in this BOM
2.- Adding a Component based in % to use the Order Quantity of Manufacturing Order in this Formula.
' WHERE AD_Element_ID=53256 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:17:08 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Quantity in %', Description='Indicate the Quantity % use in this Formula', Help='Exist two way the add a compenent to a BOM or Formula:

1.- Adding a Component based in quantity to use in this BOM
2.- Adding a Component based in % to use the Order Quantity of Manufacturing Order in this Formula.
' WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53256) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:17:08 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Quantity in %', Name='Quantity in %' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53256)
;

-- Aug 5, 2008 12:17:12 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Setup Time Real',Updated=TO_DATE('2008-08-05 12:17:12','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53290
;

-- Aug 5, 2008 12:17:12 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53290
;

-- Aug 5, 2008 12:17:12 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='SetupTimeReal', Name='Setup Time Real', Description=NULL, Help=NULL WHERE AD_Element_ID=53290
;

-- Aug 5, 2008 12:17:12 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='SetupTimeReal', Name='Setup Time Real', Description=NULL, Help=NULL, AD_Element_ID=53290 WHERE UPPER(ColumnName)='SETUPTIMEREAL' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:17:12 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='SetupTimeReal', Name='Setup Time Real', Description=NULL, Help=NULL WHERE AD_Element_ID=53290 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:17:12 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Setup Time Real', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53290) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:17:12 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='SetupTimeReal', Name='Setup Time Real' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53290)
;

-- Aug 5, 2008 12:17:15 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Setup Time Requiered',Updated=TO_DATE('2008-08-05 12:17:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53291
;

-- Aug 5, 2008 12:17:15 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53291
;

-- Aug 5, 2008 12:17:15 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='SetupTimeRequiered', Name='Setup Time Requiered', Description=NULL, Help=NULL WHERE AD_Element_ID=53291
;

-- Aug 5, 2008 12:17:15 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='SetupTimeRequiered', Name='Setup Time Requiered', Description=NULL, Help=NULL, AD_Element_ID=53291 WHERE UPPER(ColumnName)='SETUPTIMEREQUIERED' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:17:15 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='SetupTimeRequiered', Name='Setup Time Requiered', Description=NULL, Help=NULL WHERE AD_Element_ID=53291 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:17:15 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Setup Time Requiered', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53291) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:17:15 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='SetupTimeRequiered', Name='Setup Time Requiered' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53291)
;

-- Aug 5, 2008 12:17:19 PM CDT
-- Terminology
UPDATE AD_Element SET PrintName='Setup Time Real',Updated=TO_DATE('2008-08-05 12:17:19','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53290
;

-- Aug 5, 2008 12:17:19 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53290
;

-- Aug 5, 2008 12:17:19 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Setup Time Real', Name='Setup Time Real' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53290)
;

-- Aug 5, 2008 12:17:32 PM CDT
-- Terminology
UPDATE AD_Element SET PrintName='Setup Time Requiered',Updated=TO_DATE('2008-08-05 12:17:32','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53291
;

-- Aug 5, 2008 12:17:32 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53291
;

-- Aug 5, 2008 12:17:32 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Setup Time Requiered', Name='Setup Time Requiered' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53291)
;

-- Aug 5, 2008 12:18:07 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Selected Product',Updated=TO_DATE('2008-08-05 12:18:07','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53464
;

-- Aug 5, 2008 12:18:07 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53464
;

-- Aug 5, 2008 12:18:07 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='Sel_Product_ID', Name='Selected Product', Description=NULL, Help=NULL WHERE AD_Element_ID=53464
;

-- Aug 5, 2008 12:18:07 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='Sel_Product_ID', Name='Selected Product', Description=NULL, Help=NULL, AD_Element_ID=53464 WHERE UPPER(ColumnName)='SEL_PRODUCT_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:18:07 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='Sel_Product_ID', Name='Selected Product', Description=NULL, Help=NULL WHERE AD_Element_ID=53464 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:18:07 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Selected Product', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53464) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:18:07 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Selected Product', Name='Selected Product' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53464)
;

-- Aug 5, 2008 12:18:12 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Queuing Time', PrintName='Queuing Time',Updated=TO_DATE('2008-08-05 12:18:12','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53234
;

-- Aug 5, 2008 12:18:12 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53234
;

-- Aug 5, 2008 12:18:12 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='QueuingTime', Name='Queuing Time', Description=NULL, Help=NULL WHERE AD_Element_ID=53234
;

-- Aug 5, 2008 12:18:12 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QueuingTime', Name='Queuing Time', Description=NULL, Help=NULL, AD_Element_ID=53234 WHERE UPPER(ColumnName)='QUEUINGTIME' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:18:12 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='QueuingTime', Name='Queuing Time', Description=NULL, Help=NULL WHERE AD_Element_ID=53234 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:18:12 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Queuing Time', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53234) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:18:12 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Queuing Time', Name='Queuing Time' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53234)
;

-- Aug 5, 2008 12:19:14 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Tax Base', PrintName='Tax Base',Updated=TO_DATE('2008-08-05 12:19:14','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53357
;

-- Aug 5, 2008 12:19:14 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53357
;

-- Aug 5, 2008 12:19:14 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='C_TaxBase_ID', Name='Tax Base', Description=NULL, Help=NULL WHERE AD_Element_ID=53357
;

-- Aug 5, 2008 12:19:14 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='C_TaxBase_ID', Name='Tax Base', Description=NULL, Help=NULL, AD_Element_ID=53357 WHERE UPPER(ColumnName)='C_TAXBASE_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:19:14 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='C_TaxBase_ID', Name='Tax Base', Description=NULL, Help=NULL WHERE AD_Element_ID=53357 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:19:14 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Tax Base', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53357) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:19:14 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Tax Base', Name='Tax Base' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53357)
;

-- Aug 5, 2008 12:19:25 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Tax Definition', PrintName='Tax Definition',Updated=TO_DATE('2008-08-05 12:19:25','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53358
;

-- Aug 5, 2008 12:19:25 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53358
;

-- Aug 5, 2008 12:19:25 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='C_TaxDefinition_ID', Name='Tax Definition', Description=NULL, Help=NULL WHERE AD_Element_ID=53358
;

-- Aug 5, 2008 12:19:25 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='C_TaxDefinition_ID', Name='Tax Definition', Description=NULL, Help=NULL, AD_Element_ID=53358 WHERE UPPER(ColumnName)='C_TAXDEFINITION_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:19:25 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='C_TaxDefinition_ID', Name='Tax Definition', Description=NULL, Help=NULL WHERE AD_Element_ID=53358 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:19:25 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Tax Definition', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53358) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:19:25 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Tax Definition', Name='Tax Definition' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53358)
;

-- Aug 5, 2008 12:19:39 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Tax Type', PrintName='Tax Type',Updated=TO_DATE('2008-08-05 12:19:39','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53359
;

-- Aug 5, 2008 12:19:39 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53359
;

-- Aug 5, 2008 12:19:39 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='C_TaxType_ID', Name='Tax Type', Description=NULL, Help=NULL WHERE AD_Element_ID=53359
;

-- Aug 5, 2008 12:19:39 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='C_TaxType_ID', Name='Tax Type', Description=NULL, Help=NULL, AD_Element_ID=53359 WHERE UPPER(ColumnName)='C_TAXTYPE_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:19:39 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='C_TaxType_ID', Name='Tax Type', Description=NULL, Help=NULL WHERE AD_Element_ID=53359 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:19:39 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Tax Type', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53359) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:19:39 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Tax Type', Name='Tax Type' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53359)
;

-- Aug 5, 2008 12:19:40 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Max Taxable',Updated=TO_DATE('2008-08-05 12:19:40','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53360
;

-- Aug 5, 2008 12:19:40 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53360
;

-- Aug 5, 2008 12:19:40 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='MaxTaxable', Name='Max Taxable', Description=NULL, Help=NULL WHERE AD_Element_ID=53360
;

-- Aug 5, 2008 12:19:40 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='MaxTaxable', Name='Max Taxable', Description=NULL, Help=NULL, AD_Element_ID=53360 WHERE UPPER(ColumnName)='MAXTAXABLE' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:19:40 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='MaxTaxable', Name='Max Taxable', Description=NULL, Help=NULL WHERE AD_Element_ID=53360 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:19:40 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Max Taxable', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53360) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:19:40 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='MaxTaxable', Name='Max Taxable' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53360)
;

-- Aug 5, 2008 12:19:41 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Min Taxable',Updated=TO_DATE('2008-08-05 12:19:41','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53361
;

-- Aug 5, 2008 12:19:41 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53361
;

-- Aug 5, 2008 12:19:41 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='MinTaxable', Name='Min Taxable', Description=NULL, Help=NULL WHERE AD_Element_ID=53361
;

-- Aug 5, 2008 12:19:41 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='MinTaxable', Name='Min Taxable', Description=NULL, Help=NULL, AD_Element_ID=53361 WHERE UPPER(ColumnName)='MINTAXABLE' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:19:41 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='MinTaxable', Name='Min Taxable', Description=NULL, Help=NULL WHERE AD_Element_ID=53361 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:19:41 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Min Taxable', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53361) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:19:41 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='MinTaxable', Name='Min Taxable' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53361)
;

-- Aug 5, 2008 12:19:42 PM CDT
-- Terminology
UPDATE AD_Element SET PrintName='Max Taxable',Updated=TO_DATE('2008-08-05 12:19:42','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53360
;

-- Aug 5, 2008 12:19:42 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53360
;

-- Aug 5, 2008 12:19:42 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Max Taxable', Name='Max Taxable' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53360)
;

-- Aug 5, 2008 12:19:47 PM CDT
-- Terminology
UPDATE AD_Element SET PrintName='Min Taxable',Updated=TO_DATE('2008-08-05 12:19:47','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53361
;

-- Aug 5, 2008 12:19:47 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53361
;

-- Aug 5, 2008 12:19:47 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Min Taxable', Name='Min Taxable' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53361)
;

-- Aug 5, 2008 12:20:39 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Payroll Attribute Account',Updated=TO_DATE('2008-08-05 12:20:39','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53396
;

-- Aug 5, 2008 12:20:39 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53396
;

-- Aug 5, 2008 12:20:39 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='HR_Attribute_Acct', Name='Payroll Attribute Account', Description='Account for Employee Attribute', Help=NULL WHERE AD_Element_ID=53396
;

-- Aug 5, 2008 12:20:39 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Attribute_Acct', Name='Payroll Attribute Account', Description='Account for Employee Attribute', Help=NULL, AD_Element_ID=53396 WHERE UPPER(ColumnName)='HR_ATTRIBUTE_ACCT' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:20:39 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Attribute_Acct', Name='Payroll Attribute Account', Description='Account for Employee Attribute', Help=NULL WHERE AD_Element_ID=53396 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:20:39 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Payroll Attribute Account', Description='Account for Employee Attribute', Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53396) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:20:39 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Account Payroll Employee Attribute', Name='Payroll Attribute Account' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53396)
;

-- Aug 5, 2008 12:20:43 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Payroll Concept Account',Updated=TO_DATE('2008-08-05 12:20:43','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53404
;

-- Aug 5, 2008 12:20:43 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53404
;

-- Aug 5, 2008 12:20:43 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='HR_Concept_Acct_ID', Name='Payroll Concept Account', Description=NULL, Help=NULL WHERE AD_Element_ID=53404
;

-- Aug 5, 2008 12:20:43 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Concept_Acct_ID', Name='Payroll Concept Account', Description=NULL, Help=NULL, AD_Element_ID=53404 WHERE UPPER(ColumnName)='HR_CONCEPT_ACCT_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:20:43 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Concept_Acct_ID', Name='Payroll Concept Account', Description=NULL, Help=NULL WHERE AD_Element_ID=53404 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:20:43 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Payroll Concept Account', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53404) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:20:43 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Payroll Concept Account ID', Name='Payroll Concept Account' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53404)
;

-- Aug 5, 2008 12:21:06 PM CDT
-- Terminology
UPDATE AD_Element SET Description=NULL, PrintName='Payroll Attribute Account',Updated=TO_DATE('2008-08-05 12:21:06','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53396
;

-- Aug 5, 2008 12:21:06 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53396
;

-- Aug 5, 2008 12:21:06 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='HR_Attribute_Acct', Name='Payroll Attribute Account', Description=NULL, Help=NULL WHERE AD_Element_ID=53396
;

-- Aug 5, 2008 12:21:06 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Attribute_Acct', Name='Payroll Attribute Account', Description=NULL, Help=NULL, AD_Element_ID=53396 WHERE UPPER(ColumnName)='HR_ATTRIBUTE_ACCT' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:21:06 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='HR_Attribute_Acct', Name='Payroll Attribute Account', Description=NULL, Help=NULL WHERE AD_Element_ID=53396 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:21:06 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Payroll Attribute Account', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53396) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:21:06 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Payroll Attribute Account', Name='Payroll Attribute Account' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53396)
;

-- Aug 5, 2008 12:21:10 PM CDT
-- Terminology
UPDATE AD_Element SET PrintName='Payroll Concept Account',Updated=TO_DATE('2008-08-05 12:21:10','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53404
;

-- Aug 5, 2008 12:21:10 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53404
;

-- Aug 5, 2008 12:21:10 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Payroll Concept Account', Name='Payroll Concept Account' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53404)
;

-- Aug 5, 2008 12:21:35 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Max Value', PrintName='Max Value',Updated=TO_DATE('2008-08-05 12:21:35','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53399
;

-- Aug 5, 2008 12:21:35 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53399
;

-- Aug 5, 2008 12:21:35 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='MaxValue', Name='Max Value', Description=NULL, Help=NULL WHERE AD_Element_ID=53399
;

-- Aug 5, 2008 12:21:35 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='MaxValue', Name='Max Value', Description=NULL, Help=NULL, AD_Element_ID=53399 WHERE UPPER(ColumnName)='MAXVALUE' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:21:35 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='MaxValue', Name='Max Value', Description=NULL, Help=NULL WHERE AD_Element_ID=53399 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:21:35 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Max Value', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53399) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:21:35 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Max Value', Name='Max Value' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53399)
;

-- Aug 5, 2008 12:21:46 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Min Value', PrintName='Min Value',Updated=TO_DATE('2008-08-05 12:21:46','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53400
;

-- Aug 5, 2008 12:21:46 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53400
;

-- Aug 5, 2008 12:21:46 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='MinValue', Name='Min Value', Description=NULL, Help=NULL WHERE AD_Element_ID=53400
;

-- Aug 5, 2008 12:21:46 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='MinValue', Name='Min Value', Description=NULL, Help=NULL, AD_Element_ID=53400 WHERE UPPER(ColumnName)='MINVALUE' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:21:46 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='MinValue', Name='Min Value', Description=NULL, Help=NULL WHERE AD_Element_ID=53400 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:21:46 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Min Value', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53400) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:21:46 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Min Value', Name='Min Value' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53400)
;

-- Aug 5, 2008 12:22:32 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Order Max',Updated=TO_DATE('2008-08-05 12:22:32','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53264
;

-- Aug 5, 2008 12:22:32 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53264
;

-- Aug 5, 2008 12:22:32 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='Order_Max', Name='Order Max', Description=NULL, Help=NULL WHERE AD_Element_ID=53264
;

-- Aug 5, 2008 12:22:32 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='Order_Max', Name='Order Max', Description=NULL, Help=NULL, AD_Element_ID=53264 WHERE UPPER(ColumnName)='ORDER_MAX' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:22:32 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='Order_Max', Name='Order Max', Description=NULL, Help=NULL WHERE AD_Element_ID=53264 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:22:32 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Order Max', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53264) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:22:33 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Order Max', Name='Order Max' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53264)
;

-- Aug 5, 2008 12:23:58 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Replication Document', PrintName='Replication Document',Updated=TO_DATE('2008-08-05 12:23:58','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53366
;

-- Aug 5, 2008 12:23:58 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53366
;

-- Aug 5, 2008 12:23:59 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='AD_ReplicationDocument_ID', Name='Replication Document', Description=NULL, Help=NULL WHERE AD_Element_ID=53366
;

-- Aug 5, 2008 12:23:59 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='AD_ReplicationDocument_ID', Name='Replication Document', Description=NULL, Help=NULL, AD_Element_ID=53366 WHERE UPPER(ColumnName)='AD_REPLICATIONDOCUMENT_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:23:59 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='AD_ReplicationDocument_ID', Name='Replication Document', Description=NULL, Help=NULL WHERE AD_Element_ID=53366 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:23:59 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Replication Document', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53366) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:23:59 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Replication Document', Name='Replication Document' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53366)
;

-- Aug 5, 2008 12:24:11 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Embedded Format', PrintName='Embedded Format',Updated=TO_DATE('2008-08-05 12:24:11','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53371
;

-- Aug 5, 2008 12:24:11 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53371
;

-- Aug 5, 2008 12:24:11 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='EXP_EmbeddedFormat_ID', Name='Embedded Format', Description=NULL, Help=NULL WHERE AD_Element_ID=53371
;

-- Aug 5, 2008 12:24:11 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='EXP_EmbeddedFormat_ID', Name='Embedded Format', Description=NULL, Help=NULL, AD_Element_ID=53371 WHERE UPPER(ColumnName)='EXP_EMBEDDEDFORMAT_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:24:11 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='EXP_EmbeddedFormat_ID', Name='Embedded Format', Description=NULL, Help=NULL WHERE AD_Element_ID=53371 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:24:11 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Embedded Format', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53371) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:24:11 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Embedded Format', Name='Embedded Format' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53371)
;

-- Aug 5, 2008 12:24:24 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Format Line',Updated=TO_DATE('2008-08-05 12:24:24','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53370
;

-- Aug 5, 2008 12:24:24 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53370
;

-- Aug 5, 2008 12:24:24 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='EXP_FormatLine_ID', Name='Format Line', Description=NULL, Help=NULL WHERE AD_Element_ID=53370
;

-- Aug 5, 2008 12:24:24 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='EXP_FormatLine_ID', Name='Format Line', Description=NULL, Help=NULL, AD_Element_ID=53370 WHERE UPPER(ColumnName)='EXP_FORMATLINE_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:24:24 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='EXP_FormatLine_ID', Name='Format Line', Description=NULL, Help=NULL WHERE AD_Element_ID=53370 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:24:24 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Format Line', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53370) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:24:24 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='EXP_FormatLine_ID', Name='Format Line' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53370)
;

-- Aug 5, 2008 12:24:26 PM CDT
-- Terminology
UPDATE AD_Element SET PrintName='Format Line',Updated=TO_DATE('2008-08-05 12:24:26','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53370
;

-- Aug 5, 2008 12:24:26 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53370
;

-- Aug 5, 2008 12:24:26 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Format Line', Name='Format Line' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53370)
;

-- Aug 5, 2008 12:24:33 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Export Format', PrintName='Export Format',Updated=TO_DATE('2008-08-05 12:24:32','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53368
;

-- Aug 5, 2008 12:24:33 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53368
;

-- Aug 5, 2008 12:24:33 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='EXP_Format_ID', Name='Export Format', Description=NULL, Help=NULL WHERE AD_Element_ID=53368
;

-- Aug 5, 2008 12:24:33 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='EXP_Format_ID', Name='Export Format', Description=NULL, Help=NULL, AD_Element_ID=53368 WHERE UPPER(ColumnName)='EXP_FORMAT_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:24:33 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='EXP_Format_ID', Name='Export Format', Description=NULL, Help=NULL WHERE AD_Element_ID=53368 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:24:33 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Export Format', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53368) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:24:33 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Export Format', Name='Export Format' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53368)
;

-- Aug 5, 2008 12:24:43 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Processor Parameter', PrintName='Processor Parameter',Updated=TO_DATE('2008-08-05 12:24:43','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53378
;

-- Aug 5, 2008 12:24:43 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53378
;

-- Aug 5, 2008 12:24:43 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='EXP_ProcessorParameter_ID', Name='Processor Parameter', Description=NULL, Help=NULL WHERE AD_Element_ID=53378
;

-- Aug 5, 2008 12:24:43 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='EXP_ProcessorParameter_ID', Name='Processor Parameter', Description=NULL, Help=NULL, AD_Element_ID=53378 WHERE UPPER(ColumnName)='EXP_PROCESSORPARAMETER_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:24:43 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='EXP_ProcessorParameter_ID', Name='Processor Parameter', Description=NULL, Help=NULL WHERE AD_Element_ID=53378 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:24:43 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Processor Parameter', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53378) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:24:44 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Processor Parameter', Name='Processor Parameter' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53378)
;

-- Aug 5, 2008 12:24:53 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Processor', PrintName='Processor',Updated=TO_DATE('2008-08-05 12:24:53','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53367
;

-- Aug 5, 2008 12:24:53 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53367
;

-- Aug 5, 2008 12:24:53 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='EXP_Processor_ID', Name='Processor', Description=NULL, Help=NULL WHERE AD_Element_ID=53367
;

-- Aug 5, 2008 12:24:53 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='EXP_Processor_ID', Name='Processor', Description=NULL, Help=NULL, AD_Element_ID=53367 WHERE UPPER(ColumnName)='EXP_PROCESSOR_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:24:53 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='EXP_Processor_ID', Name='Processor', Description=NULL, Help=NULL WHERE AD_Element_ID=53367 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:24:53 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Processor', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53367) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:24:53 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Processor', Name='Processor' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53367)
;

-- Aug 5, 2008 12:25:02 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Export Processor', PrintName='Export Processor',Updated=TO_DATE('2008-08-05 12:25:02','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53367
;

-- Aug 5, 2008 12:25:02 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53367
;

-- Aug 5, 2008 12:25:02 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='EXP_Processor_ID', Name='Export Processor', Description=NULL, Help=NULL WHERE AD_Element_ID=53367
;

-- Aug 5, 2008 12:25:02 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='EXP_Processor_ID', Name='Export Processor', Description=NULL, Help=NULL, AD_Element_ID=53367 WHERE UPPER(ColumnName)='EXP_PROCESSOR_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:25:02 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='EXP_Processor_ID', Name='Export Processor', Description=NULL, Help=NULL WHERE AD_Element_ID=53367 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:25:02 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Export Processor', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53367) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:25:02 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Export Processor', Name='Export Processor' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53367)
;

-- Aug 5, 2008 12:25:14 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Export Processor Type',Updated=TO_DATE('2008-08-05 12:25:14','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53373
;

-- Aug 5, 2008 12:25:14 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53373
;

-- Aug 5, 2008 12:25:14 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='EXP_Processor_Type_ID', Name='Export Processor Type', Description=NULL, Help=NULL WHERE AD_Element_ID=53373
;

-- Aug 5, 2008 12:25:14 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='EXP_Processor_Type_ID', Name='Export Processor Type', Description=NULL, Help=NULL, AD_Element_ID=53373 WHERE UPPER(ColumnName)='EXP_PROCESSOR_TYPE_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:25:14 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='EXP_Processor_Type_ID', Name='Export Processor Type', Description=NULL, Help=NULL WHERE AD_Element_ID=53373 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:25:14 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Export Processor Type', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53373) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:25:15 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='EXP_Processor_Type_ID', Name='Export Processor Type' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53373)
;

-- Aug 5, 2008 12:25:15 PM CDT
-- Terminology
UPDATE AD_Element SET Description=NULL,Updated=TO_DATE('2008-08-05 12:25:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53367
;

-- Aug 5, 2008 12:25:15 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53367
;

-- Aug 5, 2008 12:25:15 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='EXP_Processor_ID', Name='Export Processor', Description=NULL, Help=NULL WHERE AD_Element_ID=53367
;

-- Aug 5, 2008 12:25:15 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='EXP_Processor_ID', Name='Export Processor', Description=NULL, Help=NULL, AD_Element_ID=53367 WHERE UPPER(ColumnName)='EXP_PROCESSOR_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:25:15 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='EXP_Processor_ID', Name='Export Processor', Description=NULL, Help=NULL WHERE AD_Element_ID=53367 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:25:15 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Export Processor', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53367) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:25:19 PM CDT
-- Terminology
UPDATE AD_Element SET PrintName='Export Processor Type',Updated=TO_DATE('2008-08-05 12:25:19','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53373
;

-- Aug 5, 2008 12:25:19 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53373
;

-- Aug 5, 2008 12:25:19 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Export Processor Type', Name='Export Processor Type' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53373)
;

-- Aug 5, 2008 12:25:33 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Import Processor Log', PrintName='Import Processor Log',Updated=TO_DATE('2008-08-05 12:25:33','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53384
;

-- Aug 5, 2008 12:25:33 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53384
;

-- Aug 5, 2008 12:25:33 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='IMP_ProcessorLog_ID', Name='Import Processor Log', Description=NULL, Help=NULL WHERE AD_Element_ID=53384
;

-- Aug 5, 2008 12:25:33 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='IMP_ProcessorLog_ID', Name='Import Processor Log', Description=NULL, Help=NULL, AD_Element_ID=53384 WHERE UPPER(ColumnName)='IMP_PROCESSORLOG_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:25:33 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='IMP_ProcessorLog_ID', Name='Import Processor Log', Description=NULL, Help=NULL WHERE AD_Element_ID=53384 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:25:33 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Import Processor Log', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53384) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:25:33 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Import Processor Log', Name='Import Processor Log' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53384)
;

-- Aug 5, 2008 12:25:47 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Import Processor Parameter', PrintName='Import Processor Parameter',Updated=TO_DATE('2008-08-05 12:25:47','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53383
;

-- Aug 5, 2008 12:25:47 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53383
;

-- Aug 5, 2008 12:25:47 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='IMP_ProcessorParameter_ID', Name='Import Processor Parameter', Description=NULL, Help=NULL WHERE AD_Element_ID=53383
;

-- Aug 5, 2008 12:25:47 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='IMP_ProcessorParameter_ID', Name='Import Processor Parameter', Description=NULL, Help=NULL, AD_Element_ID=53383 WHERE UPPER(ColumnName)='IMP_PROCESSORPARAMETER_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:25:47 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='IMP_ProcessorParameter_ID', Name='Import Processor Parameter', Description=NULL, Help=NULL WHERE AD_Element_ID=53383 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:25:47 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Import Processor Parameter', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53383) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:25:47 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Import Processor Parameter', Name='Import Processor Parameter' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53383)
;

-- Aug 5, 2008 12:26:02 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Import Processor', PrintName='Import Processor',Updated=TO_DATE('2008-08-05 12:26:02','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53381
;

-- Aug 5, 2008 12:26:02 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53381
;

-- Aug 5, 2008 12:26:02 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='IMP_Processor_ID', Name='Import Processor', Description=NULL, Help=NULL WHERE AD_Element_ID=53381
;

-- Aug 5, 2008 12:26:02 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='IMP_Processor_ID', Name='Import Processor', Description=NULL, Help=NULL, AD_Element_ID=53381 WHERE UPPER(ColumnName)='IMP_PROCESSOR_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:26:02 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='IMP_Processor_ID', Name='Import Processor', Description=NULL, Help=NULL WHERE AD_Element_ID=53381 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:26:02 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Import Processor', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53381) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:26:02 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Import Processor', Name='Import Processor' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53381)
;

-- Aug 5, 2008 12:26:12 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Import Processor Type', PrintName='Import Processor Type',Updated=TO_DATE('2008-08-05 12:26:12','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53382
;

-- Aug 5, 2008 12:26:12 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53382
;

-- Aug 5, 2008 12:26:12 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='IMP_Processor_Type_ID', Name='Import Processor Type', Description=NULL, Help=NULL WHERE AD_Element_ID=53382
;

-- Aug 5, 2008 12:26:12 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='IMP_Processor_Type_ID', Name='Import Processor Type', Description=NULL, Help=NULL, AD_Element_ID=53382 WHERE UPPER(ColumnName)='IMP_PROCESSOR_TYPE_ID' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:26:12 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='IMP_Processor_Type_ID', Name='Import Processor Type', Description=NULL, Help=NULL WHERE AD_Element_ID=53382 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:26:12 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Import Processor Type', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53382) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:26:13 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Import Processor Type', Name='Import Processor Type' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53382)
;

-- Aug 5, 2008 12:26:25 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Is Part Unique Index', PrintName='Is Part Unique Index',Updated=TO_DATE('2008-08-05 12:26:25','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53372
;

-- Aug 5, 2008 12:26:25 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53372
;

-- Aug 5, 2008 12:26:25 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='IsPartUniqueIndex', Name='Is Part Unique Index', Description=NULL, Help=NULL WHERE AD_Element_ID=53372
;

-- Aug 5, 2008 12:26:25 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='IsPartUniqueIndex', Name='Is Part Unique Index', Description=NULL, Help=NULL, AD_Element_ID=53372 WHERE UPPER(ColumnName)='ISPARTUNIQUEINDEX' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:26:25 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='IsPartUniqueIndex', Name='Is Part Unique Index', Description=NULL, Help=NULL WHERE AD_Element_ID=53372 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:26:25 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Is Part Unique Index', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53372) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:26:25 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Is Part Unique Index', Name='Is Part Unique Index' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53372)
;

-- Aug 5, 2008 12:26:28 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Java Class', PrintName='Java Class',Updated=TO_DATE('2008-08-05 12:26:28','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53380
;

-- Aug 5, 2008 12:26:28 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53380
;

-- Aug 5, 2008 12:26:28 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='JavaClass', Name='Java Class', Description=NULL, Help=NULL WHERE AD_Element_ID=53380
;

-- Aug 5, 2008 12:26:28 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='JavaClass', Name='Java Class', Description=NULL, Help=NULL, AD_Element_ID=53380 WHERE UPPER(ColumnName)='JAVACLASS' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:26:28 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='JavaClass', Name='Java Class', Description=NULL, Help=NULL WHERE AD_Element_ID=53380 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:26:28 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Java Class', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53380) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:26:29 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Java Class', Name='Java Class' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53380)
;

-- Aug 5, 2008 12:26:33 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Parameter Value', PrintName='Parameter Value',Updated=TO_DATE('2008-08-05 12:26:33','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53379
;

-- Aug 5, 2008 12:26:33 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53379
;

-- Aug 5, 2008 12:26:33 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='ParameterValue', Name='Parameter Value', Description=NULL, Help=NULL WHERE AD_Element_ID=53379
;

-- Aug 5, 2008 12:26:33 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='ParameterValue', Name='Parameter Value', Description=NULL, Help=NULL, AD_Element_ID=53379 WHERE UPPER(ColumnName)='PARAMETERVALUE' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:26:33 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='ParameterValue', Name='Parameter Value', Description=NULL, Help=NULL WHERE AD_Element_ID=53379 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:26:33 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Parameter Value', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53379) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:26:33 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Parameter Value', Name='Parameter Value' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53379)
;

-- Aug 5, 2008 12:26:36 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Password Info', PrintName='Password Info',Updated=TO_DATE('2008-08-05 12:26:36','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53377
;

-- Aug 5, 2008 12:26:36 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53377
;

-- Aug 5, 2008 12:26:36 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='PasswordInfo', Name='Password Info', Description=NULL, Help=NULL WHERE AD_Element_ID=53377
;

-- Aug 5, 2008 12:26:36 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PasswordInfo', Name='Password Info', Description=NULL, Help=NULL, AD_Element_ID=53377 WHERE UPPER(ColumnName)='PASSWORDINFO' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:26:36 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='PasswordInfo', Name='Password Info', Description=NULL, Help=NULL WHERE AD_Element_ID=53377 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:26:36 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Password Info', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53377) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:26:36 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Password Info', Name='Password Info' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53377)
;

-- Aug 5, 2008 12:26:49 PM CDT
-- Terminology
UPDATE AD_Element SET Name='Test Import Model', PrintName='Test Import Model',Updated=TO_DATE('2008-08-05 12:26:49','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Element_ID=53369
;

-- Aug 5, 2008 12:26:49 PM CDT
-- Terminology
UPDATE AD_Element_Trl SET IsTranslated='N' WHERE AD_Element_ID=53369
;

-- Aug 5, 2008 12:26:49 PM CDT
-- Terminology
UPDATE AD_Column SET ColumnName='TestImportModel', Name='Test Import Model', Description=NULL, Help=NULL WHERE AD_Element_ID=53369
;

-- Aug 5, 2008 12:26:49 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='TestImportModel', Name='Test Import Model', Description=NULL, Help=NULL, AD_Element_ID=53369 WHERE UPPER(ColumnName)='TESTIMPORTMODEL' AND IsCentrallyMaintained='Y' AND AD_Element_ID IS NULL
;

-- Aug 5, 2008 12:26:49 PM CDT
-- Terminology
UPDATE AD_Process_Para SET ColumnName='TestImportModel', Name='Test Import Model', Description=NULL, Help=NULL WHERE AD_Element_ID=53369 AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:26:49 PM CDT
-- Terminology
UPDATE AD_Field SET Name='Test Import Model', Description=NULL, Help=NULL WHERE AD_Column_ID IN (SELECT AD_Column_ID FROM AD_Column WHERE AD_Element_ID=53369) AND IsCentrallyMaintained='Y'
;

-- Aug 5, 2008 12:26:49 PM CDT
-- Terminology
UPDATE AD_PrintFormatItem pi SET PrintName='Test Import Model', Name='Test Import Model' WHERE IsCentrallyMaintained='Y' AND EXISTS (SELECT * FROM AD_Column c WHERE c.AD_Column_ID=pi.AD_Column_ID AND c.AD_Element_ID=53369)
;

