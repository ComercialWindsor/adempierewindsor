-- Nov 18, 2008 9:35:53 PM EET
-- [ 2311021 ] Window Shipper, tab Freight set proper Region validation
UPDATE AD_Column SET AD_Val_Rule_ID=153,Updated=TO_DATE('2008-11-18 21:35:53','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=9099
;

-- Nov 18, 2008 9:36:21 PM EET
-- [ 2311021 ] Window Shipper, tab Freight set proper Region validation
UPDATE AD_Column SET AD_Val_Rule_ID=155,Updated=TO_DATE('2008-11-18 21:36:21','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=9108
;
