-- 2/12/2008 11:11:17
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=40,IsDisplayed='Y' WHERE AD_Field_ID=53606
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=50,IsDisplayed='Y' WHERE AD_Field_ID=53566
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=60,IsDisplayed='Y' WHERE AD_Field_ID=53567
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=70,IsDisplayed='Y' WHERE AD_Field_ID=53568
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=80,IsDisplayed='Y' WHERE AD_Field_ID=53569
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=90,IsDisplayed='Y' WHERE AD_Field_ID=53570
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=100,IsDisplayed='Y' WHERE AD_Field_ID=53571
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=110,IsDisplayed='Y' WHERE AD_Field_ID=53572
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=120,IsDisplayed='Y' WHERE AD_Field_ID=53573
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=130,IsDisplayed='Y' WHERE AD_Field_ID=53574
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=140,IsDisplayed='Y' WHERE AD_Field_ID=53575
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=150,IsDisplayed='Y' WHERE AD_Field_ID=53576
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=160,IsDisplayed='Y' WHERE AD_Field_ID=53577
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=170,IsDisplayed='Y' WHERE AD_Field_ID=53578
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=180,IsDisplayed='Y' WHERE AD_Field_ID=53579
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=190,IsDisplayed='Y' WHERE AD_Field_ID=53580
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=200,IsDisplayed='Y' WHERE AD_Field_ID=53581
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=210,IsDisplayed='Y' WHERE AD_Field_ID=53582
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=220,IsDisplayed='Y' WHERE AD_Field_ID=53583
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=230,IsDisplayed='Y' WHERE AD_Field_ID=53584
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=240,IsDisplayed='Y' WHERE AD_Field_ID=53585
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=250,IsDisplayed='Y' WHERE AD_Field_ID=53586
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=260,IsDisplayed='Y' WHERE AD_Field_ID=53587
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=270,IsDisplayed='Y' WHERE AD_Field_ID=53588
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=280,IsDisplayed='Y' WHERE AD_Field_ID=53589
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=290,IsDisplayed='Y' WHERE AD_Field_ID=53590
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=300,IsDisplayed='Y' WHERE AD_Field_ID=53591
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=310,IsDisplayed='Y' WHERE AD_Field_ID=53592
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=320,IsDisplayed='Y' WHERE AD_Field_ID=53593
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=330,IsDisplayed='Y' WHERE AD_Field_ID=53594
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=340,IsDisplayed='Y' WHERE AD_Field_ID=53595
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=350,IsDisplayed='Y' WHERE AD_Field_ID=53596
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=360,IsDisplayed='Y' WHERE AD_Field_ID=53597
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=370,IsDisplayed='Y' WHERE AD_Field_ID=53598
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=380,IsDisplayed='Y' WHERE AD_Field_ID=53599
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=390,IsDisplayed='Y' WHERE AD_Field_ID=53600
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=400,IsDisplayed='Y' WHERE AD_Field_ID=53601
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=410,IsDisplayed='Y' WHERE AD_Field_ID=53602
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=420,IsDisplayed='Y' WHERE AD_Field_ID=53603
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=430,IsDisplayed='Y' WHERE AD_Field_ID=53604
;

-- 2/12/2008 11:11:18
-- [ 2227971 ] Product Planning window - overlapped fields
UPDATE AD_Field SET SeqNo=440,IsDisplayed='Y' WHERE AD_Field_ID=53605
;

