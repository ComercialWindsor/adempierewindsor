create index ad_changelog_speed on ad_changelog (ad_table_id, record_id);

