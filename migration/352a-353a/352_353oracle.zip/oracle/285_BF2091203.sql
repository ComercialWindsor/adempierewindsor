-- Sep 3, 2008 5:01:15 PM EEST
-- 
UPDATE AD_Tab SET IsInsertRecord='N', IsReadOnly='Y',Updated=TO_DATE('2008-09-03 17:01:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Tab_ID=53034
;

-- Sep 3, 2008 5:01:27 PM EEST
-- 
UPDATE AD_Field SET IsReadOnly='Y',Updated=TO_DATE('2008-09-03 17:01:27','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53635
;

-- Sep 3, 2008 5:01:29 PM EEST
-- 
UPDATE AD_Field SET IsReadOnly='Y',Updated=TO_DATE('2008-09-03 17:01:29','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53634
;

-- Sep 3, 2008 5:01:48 PM EEST
-- 
UPDATE AD_Field SET IsReadOnly='Y',Updated=TO_DATE('2008-09-03 17:01:48','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53623
;

-- Sep 3, 2008 5:01:49 PM EEST
-- 
UPDATE AD_Field SET IsReadOnly='Y',Updated=TO_DATE('2008-09-03 17:01:49','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53624
;

-- Sep 3, 2008 5:01:50 PM EEST
-- 
UPDATE AD_Field SET IsReadOnly='Y',Updated=TO_DATE('2008-09-03 17:01:50','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53625
;

-- Sep 3, 2008 5:01:51 PM EEST
-- 
UPDATE AD_Field SET IsReadOnly='Y',Updated=TO_DATE('2008-09-03 17:01:51','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53626
;

-- Sep 3, 2008 5:01:52 PM EEST
-- 
UPDATE AD_Field SET IsReadOnly='Y',Updated=TO_DATE('2008-09-03 17:01:52','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53627
;

-- Sep 3, 2008 5:01:53 PM EEST
-- 
UPDATE AD_Field SET IsReadOnly='Y',Updated=TO_DATE('2008-09-03 17:01:53','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53628
;

-- Sep 3, 2008 5:01:54 PM EEST
-- 
UPDATE AD_Field SET IsReadOnly='Y',Updated=TO_DATE('2008-09-03 17:01:54','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53629
;

-- Sep 3, 2008 5:01:55 PM EEST
-- 
UPDATE AD_Field SET IsReadOnly='Y',Updated=TO_DATE('2008-09-03 17:01:55','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53630
;

-- Sep 3, 2008 5:01:55 PM EEST
-- 
UPDATE AD_Field SET IsReadOnly='Y',Updated=TO_DATE('2008-09-03 17:01:55','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53631
;

-- Sep 3, 2008 5:01:56 PM EEST
-- 
UPDATE AD_Field SET IsReadOnly='Y',Updated=TO_DATE('2008-09-03 17:01:56','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53632
;

-- Sep 3, 2008 5:01:57 PM EEST
-- 
UPDATE AD_Field SET IsReadOnly='Y',Updated=TO_DATE('2008-09-03 17:01:57','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53633
;

-- Sep 3, 2008 5:01:58 PM EEST
-- 
UPDATE AD_Field SET IsReadOnly='Y',Updated=TO_DATE('2008-09-03 17:01:58','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53636
;

-- Sep 3, 2008 5:01:59 PM EEST
-- 
UPDATE AD_Field SET IsReadOnly='Y',Updated=TO_DATE('2008-09-03 17:01:59','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53637
;








-- Sep 3, 2008 5:05:25 PM EEST
-- 
UPDATE AD_Tab SET DisplayLogic='@IsPurchased@=Y',Updated=TO_DATE('2008-09-03 17:05:25','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Tab_ID=53031
;

