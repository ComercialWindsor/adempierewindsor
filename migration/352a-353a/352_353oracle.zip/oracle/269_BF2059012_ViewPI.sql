-- Aug 19, 2008 3:25:12 PM EST
-- BF2059012_ViewPI
UPDATE AD_Form SET Classname='org.adempiere.apps.graph.ViewPI',Updated=TO_DATE('2008-08-19 15:25:12','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Form_ID=119
;
