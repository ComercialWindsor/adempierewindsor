-- Jan 8, 2009 7:23:10 PM ECT
-- Standard Cost for Manufacturing
UPDATE AD_TreeNode SET Parent_ID=731, SeqNo=0, Updated=CURRENT_TIMESTAMP WHERE AD_Tree_ID=101 AND Node_ID=732
;

-- Jan 8, 2009 7:23:10 PM ECT
-- Standard Cost for Manufacturing
UPDATE AD_TreeNode SET Parent_ID=731, SeqNo=1, Updated=CURRENT_TIMESTAMP WHERE AD_Tree_ID=101 AND Node_ID=733
;

-- Jan 8, 2009 7:23:10 PM ECT
-- Standard Cost for Manufacturing
UPDATE AD_TreeNode SET Parent_ID=50008, SeqNo=0, Updated=CURRENT_TIMESTAMP WHERE AD_Tree_ID=101 AND Node_ID=50007
;

-- Jan 8, 2009 7:23:10 PM ECT
-- Standard Cost for Manufacturing
UPDATE AD_TreeNode SET Parent_ID=50008, SeqNo=1, Updated=CURRENT_TIMESTAMP WHERE AD_Tree_ID=101 AND Node_ID=50009
;

-- Jan 8, 2009 7:23:10 PM ECT
-- Standard Cost for Manufacturing
UPDATE AD_TreeNode SET Parent_ID=50008, SeqNo=2, Updated=CURRENT_TIMESTAMP WHERE AD_Tree_ID=101 AND Node_ID=50014
;

-- Jan 8, 2009 7:23:23 PM ECT
-- Standard Cost for Manufacturing
UPDATE C_ElementValue SET Value='83300',Updated=TO_TIMESTAMP('2009-01-08 19:23:23','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_ElementValue_ID=50014
;

-- Jan 8, 2009 7:23:23 PM ECT
-- Standard Cost for Manufacturing
UPDATE C_ValidCombination SET Combination='HQ-83300-_-_-_-_', Description='HQ-Overhead (Applied)-_-_-_-_',Updated=TO_TIMESTAMP('2009-01-08 19:23:23','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_ValidCombination_ID=50011
;

-- Jan 8, 2009 7:23:33 PM ECT
-- Standard Cost for Manufacturing
UPDATE AD_TreeNode SET Parent_ID=429, SeqNo=0, Updated=CURRENT_TIMESTAMP WHERE AD_Tree_ID=101 AND Node_ID=430
;

-- Jan 8, 2009 7:23:33 PM ECT
-- Standard Cost for Manufacturing
UPDATE AD_TreeNode SET Parent_ID=429, SeqNo=1, Updated=CURRENT_TIMESTAMP WHERE AD_Tree_ID=101 AND Node_ID=50010
;

-- Jan 8, 2009 7:23:33 PM ECT
-- Standard Cost for Manufacturing
UPDATE AD_TreeNode SET Parent_ID=429, SeqNo=2, Updated=CURRENT_TIMESTAMP WHERE AD_Tree_ID=101 AND Node_ID=50016
;

-- Jan 8, 2009 7:23:33 PM ECT
-- Standard Cost for Manufacturing
UPDATE AD_TreeNode SET Parent_ID=429, SeqNo=3, Updated=CURRENT_TIMESTAMP WHERE AD_Tree_ID=101 AND Node_ID=50011
;

-- Jan 8, 2009 7:23:33 PM ECT
-- Standard Cost for Manufacturing
UPDATE AD_TreeNode SET Parent_ID=429, SeqNo=4, Updated=CURRENT_TIMESTAMP WHERE AD_Tree_ID=101 AND Node_ID=431
;

-- Jan 8, 2009 7:23:33 PM ECT
-- Standard Cost for Manufacturing
UPDATE AD_TreeNode SET Parent_ID=429, SeqNo=5, Updated=CURRENT_TIMESTAMP WHERE AD_Tree_ID=101 AND Node_ID=781
;

-- Jan 8, 2009 7:23:33 PM ECT
-- Standard Cost for Manufacturing
UPDATE AD_TreeNode SET Parent_ID=429, SeqNo=6, Updated=CURRENT_TIMESTAMP WHERE AD_Tree_ID=101 AND Node_ID=780
;

-- Jan 8, 2009 7:23:33 PM ECT
-- Standard Cost for Manufacturing
UPDATE AD_TreeNode SET Parent_ID=429, SeqNo=7, Updated=CURRENT_TIMESTAMP WHERE AD_Tree_ID=101 AND Node_ID=778
;

-- Jan 8, 2009 7:23:33 PM ECT
-- Standard Cost for Manufacturing
UPDATE AD_TreeNode SET Parent_ID=429, SeqNo=8, Updated=CURRENT_TIMESTAMP WHERE AD_Tree_ID=101 AND Node_ID=432
;

-- Jan 8, 2009 7:23:33 PM ECT
-- Standard Cost for Manufacturing
UPDATE AD_TreeNode SET Parent_ID=429, SeqNo=9, Updated=CURRENT_TIMESTAMP WHERE AD_Tree_ID=101 AND Node_ID=433
;

-- Jan 8, 2009 7:23:33 PM ECT
-- Standard Cost for Manufacturing
UPDATE AD_TreeNode SET Parent_ID=429, SeqNo=10, Updated=CURRENT_TIMESTAMP WHERE AD_Tree_ID=101 AND Node_ID=434
;

-- Jan 8, 2009 7:23:33 PM ECT
-- Standard Cost for Manufacturing
UPDATE AD_TreeNode SET Parent_ID=429, SeqNo=11, Updated=CURRENT_TIMESTAMP WHERE AD_Tree_ID=101 AND Node_ID=435
;

-- Jan 8, 2009 7:23:33 PM ECT
-- Standard Cost for Manufacturing
UPDATE AD_TreeNode SET Parent_ID=429, SeqNo=12, Updated=CURRENT_TIMESTAMP WHERE AD_Tree_ID=101 AND Node_ID=438
;

-- Jan 8, 2009 7:23:33 PM ECT
-- Standard Cost for Manufacturing
UPDATE AD_TreeNode SET Parent_ID=429, SeqNo=13, Updated=CURRENT_TIMESTAMP WHERE AD_Tree_ID=101 AND Node_ID=634
;

-- Jan 8, 2009 7:23:33 PM ECT
-- Standard Cost for Manufacturing
UPDATE AD_TreeNode SET Parent_ID=429, SeqNo=14, Updated=CURRENT_TIMESTAMP WHERE AD_Tree_ID=101 AND Node_ID=443
;

-- Jan 8, 2009 7:23:33 PM ECT
-- Standard Cost for Manufacturing
UPDATE AD_TreeNode SET Parent_ID=429, SeqNo=15, Updated=CURRENT_TIMESTAMP WHERE AD_Tree_ID=101 AND Node_ID=446
;

-- Jan 8, 2009 8:21:42 PM ECT
-- Manufacturing Cost
UPDATE PP_Product_BOMLine SET QtyBOM=1.000000000000,Updated=TO_TIMESTAMP('2009-01-08 20:21:42','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE PP_Product_BOMLine_ID=50002
;

-- Jan 8, 2009 8:21:45 PM ECT
-- Manufacturing Cost
UPDATE PP_Product_BOMLine SET QtyBOM=1.000000000000,Updated=TO_TIMESTAMP('2009-01-08 20:21:45','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE PP_Product_BOMLine_ID=50003
;

-- Jan 8, 2009 8:22:37 PM ECT
-- Manufacturing Cost
UPDATE M_Cost SET CurrentCostPriceLL=13.39000000000000000000,Updated=TO_TIMESTAMP('2009-01-08 20:22:37','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Org_ID=0 AND C_AcctSchema_ID=101 AND M_AttributeSetInstance_ID=0 AND M_CostElement_ID=100 AND M_CostType_ID=100 AND M_Product_ID=133
;

-- Jan 8, 2009 8:22:38 PM ECT
-- Manufacturing Cost
UPDATE M_Cost SET CurrentCostPriceLL=53.560000000000000000000000,Updated=TO_TIMESTAMP('2009-01-08 20:22:38','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Org_ID=0 AND C_AcctSchema_ID=101 AND M_AttributeSetInstance_ID=0 AND M_CostElement_ID=100 AND M_CostType_ID=100 AND M_Product_ID=145
;

-- Jan 8, 2009 8:26:03 PM ECT
-- Manufacturing Cost
UPDATE M_Cost SET CurrentCostPrice=54.000000000000,Updated=TO_TIMESTAMP('2009-01-08 20:26:03','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Org_ID=0 AND C_AcctSchema_ID=101 AND M_AttributeSetInstance_ID=0 AND M_CostElement_ID=100 AND M_CostType_ID=100 AND M_Product_ID=134
;

-- Jan 8, 2009 8:26:19 PM ECT
-- Manufacturing Cost
UPDATE M_ProductPrice SET PriceList=60.000000000000,Updated=TO_TIMESTAMP('2009-01-08 20:26:19','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE M_PriceList_Version_ID=103 AND M_Product_ID=134
;

-- Jan 8, 2009 8:28:06 PM ECT
-- Manufacturing Cost
UPDATE M_Cost SET CurrentCostPrice=18.000000000000,Updated=TO_TIMESTAMP('2009-01-08 20:28:06','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Org_ID=0 AND C_AcctSchema_ID=101 AND M_AttributeSetInstance_ID=0 AND M_CostElement_ID=100 AND M_CostType_ID=100 AND M_Product_ID=135
;

-- Jan 8, 2009 8:30:12 PM ECT
-- Manufacturing Cost
UPDATE M_Cost SET CurrentCostPriceLL=125.560000000000000000000000,Updated=TO_TIMESTAMP('2009-01-08 20:30:12','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Org_ID=0 AND C_AcctSchema_ID=101 AND M_AttributeSetInstance_ID=0 AND M_CostElement_ID=100 AND M_CostType_ID=100 AND M_Product_ID=145
;

