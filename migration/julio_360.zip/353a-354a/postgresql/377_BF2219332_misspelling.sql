-- Dez 02, 2008 12:03:00 PM ECT
-- fix Correct Misspelling
update ad_process set Description='Invoice Report by Product Category per Month',Updated=TO_TIMESTAMP('2008-12-02 12:03:00','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 where ad_process_id=132
;
-- Dez 02, 2008 12:03:00 PM ECT
-- fix Correct Misspelling
update ad_process set Description='Invoice Report by Product Vendor per Month',Updated=TO_TIMESTAMP('2008-12-02 12:03:00','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 where ad_process_id=133
;
-- Dez 02, 2008 12:03:00 PM ECT
-- fix Correct Misspelling
update ad_process set Description='Invoice Report by Product Category per Week',Updated=TO_TIMESTAMP('2008-12-02 12:03:00','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 where ad_process_id=131
;
-- Dez 02, 2008 12:03:00 PM ECT
-- fix Correct Misspelling
update ad_process set Description='Invoice Report per Week',Updated=TO_TIMESTAMP('2008-12-02 12:03:00','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 where ad_process_id=130
;
-- Dez 02, 2008 12:03:00 PM ECT
-- fix Correct Misspelling
update ad_process set Description='Invoice Report per Month',Updated=TO_TIMESTAMP('2008-12-02 12:03:00','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 where ad_process_id=129
;
-- Dez 02, 2008 12:03:00 PM ECT
-- fix Correct Misspelling
update ad_process set Description='Invoice Report per Day',Updated=TO_TIMESTAMP('2008-12-02 12:03:00','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 where ad_process_id=128
;
-- Dez 02, 2008 12:03:00 PM ECT
-- fix Correct Misspelling
update ad_process set Description='Invoice Transactions by Accounting Date',Updated=TO_TIMESTAMP('2008-12-02 12:03:00','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 where ad_process_id=127
;
-- Dez 02, 2008 12:03:00 PM ECT
-- fix Correct Misspelling
update ad_process set Description='Invoice Report by Product per Month',Updated=TO_TIMESTAMP('2008-12-02 12:03:00','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 where ad_process_id=340
;
-- Dez 02, 2008 12:03:00 PM ECT
-- fix Correct Misspelling
update ad_process set Description='Invoice Report by Product per Quarter',Updated=TO_TIMESTAMP('2008-12-02 12:03:00','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 where ad_process_id=341
;

-- Jan 2, 2009 9:11:36 PM COT
UPDATE GL_Category SET Name='Manufacturing',Updated=TO_TIMESTAMP('2009-01-02 21:11:36','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE GL_Category_ID=50001
;

