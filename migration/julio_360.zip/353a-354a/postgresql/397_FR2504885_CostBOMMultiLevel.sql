-- 14.01.2009 14:44:43 EET
-- FR [ 2457781 ] Introduce NoVendorForProductException
UPDATE AD_Column SET AD_Reference_ID=37,Updated=TO_TIMESTAMP('2009-01-14 14:44:43','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Column_ID=56629
;

