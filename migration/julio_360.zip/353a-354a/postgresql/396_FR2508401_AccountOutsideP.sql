-- Jan 14, 2009 6:20:03 PM ECT
-- Outside Processing Account
UPDATE AD_Field SET DisplayLogic='@IsBOM@=''Y'' | @ProductType@=''S''',Updated=TO_TIMESTAMP('2009-01-14 18:20:03','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56542
;

-- Jan 14, 2009 6:20:10 PM ECT
-- Outside Processing Account
UPDATE AD_Field SET DisplayLogic='@IsBOM@=''Y'' | @ProductType@=''S''',Updated=TO_TIMESTAMP('2009-01-14 18:20:10','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56549
;

-- Jan 14, 2009 6:20:18 PM ECT
-- Outside Processing Account
UPDATE AD_Field SET DisplayLogic='@IsBOM@=''Y'' | @ProductType@=''S''',Updated=TO_TIMESTAMP('2009-01-14 18:20:18','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56544
;

-- Jan 14, 2009 6:20:21 PM ECT
-- Outside Processing Account
UPDATE AD_Field SET DisplayLogic='@IsBOM@=''Y'' | @ProductType@=''S''',Updated=TO_TIMESTAMP('2009-01-14 18:20:21','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56548
;

-- Jan 14, 2009 6:20:24 PM ECT
-- Outside Processing Account
UPDATE AD_Field SET DisplayLogic='@IsBOM@=''Y'' | @ProductType@=''S''',Updated=TO_TIMESTAMP('2009-01-14 18:20:24','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56547
;

-- Jan 14, 2009 6:20:28 PM ECT
-- Outside Processing Account
UPDATE AD_Field SET DisplayLogic='@IsBOM@=''Y'' | @ProductType@=''S''',Updated=TO_TIMESTAMP('2009-01-14 18:20:28','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=56545
;

