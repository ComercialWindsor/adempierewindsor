-- https://sourceforge.net/tracker2/?func=detail&atid=879332&aid=2478283&group_id=176962
UPDATE AD_Column SET DefaultValue = NULL WHERE AD_Column_ID = 7752;
