set define off;

-- 06.03.2009 08:58:57 EET
-- 
UPDATE AD_Process SET IsActive='N',Updated=TO_DATE('2009-03-06 08:58:56','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Process_ID=53054
;

-- 06.03.2009 08:58:57 EET
-- 
UPDATE AD_Menu SET Name='Product Costing', IsActive='N', Description='To watch the cost elements for every set of Product, Organization, Accounting Schema, Warehouse, Resource and Cost Type',Updated=TO_DATE('2009-03-06 08:58:57','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Menu_ID=53077
;

-- 06.03.2009 09:04:28 EET
-- 
UPDATE AD_Process SET IsActive='N',Updated=TO_DATE('2009-03-06 09:04:28','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Process_ID=53060
;

-- 06.03.2009 09:04:28 EET
-- 
UPDATE AD_Menu SET Name='Cost Workflow & Process Details', IsActive='N', Description='This report show every cost element to a BOM or Formula ',Updated=TO_DATE('2009-03-06 09:04:28','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Menu_ID=53080
;

