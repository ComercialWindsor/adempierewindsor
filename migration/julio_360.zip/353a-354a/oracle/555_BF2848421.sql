-- Sep 1, 2009 4:23:31 PM EEST
UPDATE AD_Column SET AD_Reference_ID=18, AD_Reference_Value_ID=132,Updated=TO_DATE('2009-09-01 16:23:31','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Column_ID=57588
;

-- Sep 1, 2009 4:24:34 PM EEST
UPDATE AD_Column SET AD_Reference_ID=18, AD_Reference_Value_ID=134,Updated=TO_DATE('2009-09-01 16:24:34','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Column_ID=57599
;

-- Sep 1, 2009 4:24:42 PM EEST
UPDATE AD_Column SET AD_Reference_ID=18, AD_Reference_Value_ID=137,Updated=TO_DATE('2009-09-01 16:24:42','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Column_ID=57600
;

-- Sep 1, 2009 4:24:50 PM EEST
UPDATE AD_Column SET AD_Reference_ID=13,Updated=TO_DATE('2009-09-01 16:24:50','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Column_ID=57611
;

-- Sep 1, 2009 4:24:53 PM EEST
UPDATE AD_Column SET AD_Reference_ID=13,Updated=TO_DATE('2009-09-01 16:24:53','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Column_ID=57612
;

