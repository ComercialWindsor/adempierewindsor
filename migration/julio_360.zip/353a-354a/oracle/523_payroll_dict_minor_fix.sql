-- Aug 10, 2009 4:18:22 PM COT
-- Minor payroll dictionary problem
UPDATE AD_Field SET IsCentrallyMaintained='Y',Updated=TO_DATE('2009-08-10 16:18:22','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=54838
;

