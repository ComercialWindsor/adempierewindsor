UPDATE AD_SYSTEM
   SET releaseno = '354a',
       VERSION = '2009-09-15'
 WHERE ad_system_id = 0 AND ad_client_id = 0;

