-- Jul 28, 2009 8:51:07 PM EST
-- BF2828321 Error inserting Forecast Lines
UPDATE AD_Column SET DefaultValue='@M_Warehouse_ID@', ReadOnlyLogic=NULL,Updated=TO_DATE('2009-07-28 20:51:07','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=53411
;
