-- Feb 9, 2009 12:43:12 PM COT
-- [2582181 ] Make BPLocation Name generation configurable
INSERT INTO AD_SysConfig (AD_Client_ID,AD_Org_ID,AD_SysConfig_ID,ConfigurationLevel,Created,CreatedBy,Description,EntityType,IsActive,Name,Updated,UpdatedBy,Value) VALUES (0,0,50017,'O',TO_DATE('2009-02-09 12:43:11','YYYY-MM-DD HH24:MI:SS'),100,'Define the start value for C_BPartner_Location.Name (possible values 0 to 4) - complete definition here http://adempiere.com/wiki/index.php/ManPageW_SystemConfigurator','D','Y','START_VALUE_BPLOCATION_NAME',TO_DATE('2009-02-09 12:43:11','YYYY-MM-DD HH24:MI:SS'),100,'0')
;

