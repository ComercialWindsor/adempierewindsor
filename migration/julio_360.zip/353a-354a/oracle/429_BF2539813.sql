-- Feb 17, 2009 5:20:59 PM ECT
-- Libero
UPDATE PP_Product_BOMLine SET ComponentType='CO',Updated=TO_DATE('2009-02-17 17:20:59','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE PP_Product_BOMLine_ID=102
;

