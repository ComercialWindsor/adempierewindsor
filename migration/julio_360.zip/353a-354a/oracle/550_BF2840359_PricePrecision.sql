-- Aug 29, 2009 10:19:32 PM EEST
-- BF [2840359] - currency precsion should be just an integer
UPDATE AD_Column SET AD_Reference_ID=11,Updated=TO_DATE('2009-08-29 22:19:32','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=56979
;

-- Aug 29, 2009 10:25:24 PM EEST
-- BF [2840359] - currency precsion should be just an integer
UPDATE AD_Column SET AD_Reference_ID=11,Updated=TO_DATE('2009-08-29 22:25:24','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=13051
;

