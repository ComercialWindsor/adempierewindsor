-- 03-sep-2009 20:52:21 COT
-- FR1786994-2Pack can handle translations now
INSERT INTO AD_SysConfig (AD_Client_ID,AD_Org_ID,AD_SysConfig_ID,ConfigurationLevel,Created,CreatedBy,Description,EntityType,IsActive,Name,Updated,UpdatedBy,Value) VALUES (0,0,50031,'S',TO_DATE('2009-09-03 20:52:17','YYYY-MM-DD HH24:MI:SS'),100,'Define if 2pack handle translations or not','D','Y','2PACK_HANDLE_TRANSLATIONS',TO_DATE('2009-09-03 20:52:17','YYYY-MM-DD HH24:MI:SS'),100,'N')
;

