-- Jun 16, 2009 10:35:30 AM ECT
-- Fix Inventory Move Print
UPDATE AD_PrintFormatItem SET SeqNo=0,IsPrinted='N' WHERE AD_PrintFormatItem_ID=1968
;

