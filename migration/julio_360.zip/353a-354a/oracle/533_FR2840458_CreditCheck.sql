-- Aug 19, 2009 12:05:23 PM COT
-- FR 2840458 - Credit checking problem
INSERT INTO AD_SysConfig (AD_Client_ID,AD_Org_ID,AD_SysConfig_ID,ConfigurationLevel,Created,CreatedBy,Description,EntityType,IsActive,Name,Updated,UpdatedBy,Value) VALUES (0,0,50029,'O',TO_DATE('2009-08-19 12:05:21','YYYY-MM-DD HH24:MI:SS'),100,'Check credit on Cash POS Order','D','Y','CHECK_CREDIT_ON_CASH_POS_ORDER',TO_DATE('2009-08-19 12:05:21','YYYY-MM-DD HH24:MI:SS'),100,'Y')
;

-- Aug 19, 2009 12:05:38 PM COT
-- FR 2840458 - Credit checking problem
INSERT INTO AD_SysConfig (AD_Client_ID,AD_Org_ID,AD_SysConfig_ID,ConfigurationLevel,Created,CreatedBy,Description,EntityType,IsActive,Name,Updated,UpdatedBy,Value) VALUES (0,0,50030,'O',TO_DATE('2009-08-19 12:05:37','YYYY-MM-DD HH24:MI:SS'),100,'Check credit on Prepay Order','D','Y','CHECK_CREDIT_ON_PREPAY_ORDER',TO_DATE('2009-08-19 12:05:37','YYYY-MM-DD HH24:MI:SS'),100,'Y')
;

