-- Aug 2, 2009 6:29:22 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:29:22','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2589
;

-- Aug 2, 2009 6:29:29 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:29:29','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=1324
;

-- Aug 2, 2009 6:29:50 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:29:50','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=7826
;

-- Aug 2, 2009 6:29:59 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:29:59','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=7825
;

-- Aug 2, 2009 6:32:46 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:32:46','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=6560
;

-- Aug 2, 2009 6:32:58 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:32:58','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=7038
;

-- Aug 2, 2009 6:35:17 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:35:17','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=12745
;

-- Aug 2, 2009 6:35:25 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:35:25','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13644
;

-- Aug 2, 2009 6:35:32 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:35:32','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13645
;

-- Aug 2, 2009 6:35:39 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:35:39','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13691
;

-- Aug 2, 2009 6:35:45 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:35:45','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13650
;

-- Aug 2, 2009 6:35:51 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:35:51','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13651
;

-- Aug 2, 2009 6:37:51 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:37:51','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=3457
;

-- Aug 2, 2009 6:37:56 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:37:56','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=3446
;

-- Aug 2, 2009 6:38:00 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:38:00','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=7039
;

-- Aug 2, 2009 6:38:05 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:38:05','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=7824
;

-- Aug 2, 2009 6:38:09 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:38:09','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=7823
;

-- Aug 2, 2009 6:38:32 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:38:32','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=6506
;

-- Aug 2, 2009 6:38:56 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:38:56','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=12174
;

-- Aug 2, 2009 6:39:01 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:39:01','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13652
;

-- Aug 2, 2009 6:39:05 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:39:05','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13653
;

-- Aug 2, 2009 6:39:09 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:39:09','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13690
;

-- Aug 2, 2009 6:39:14 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:39:14','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13658
;

-- Aug 2, 2009 6:39:19 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:39:19','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13659
;

-- Aug 2, 2009 6:40:40 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:40:40','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2764
;

-- Aug 2, 2009 6:40:44 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:40:44','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2768
;

-- Aug 2, 2009 6:41:00 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:41:00','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=6935
;

-- Aug 2, 2009 6:41:04 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:41:04','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=7794
;

-- Aug 2, 2009 6:41:08 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:41:08','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=7795
;

-- Aug 2, 2009 6:41:22 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:41:22','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=8657
;

-- Aug 2, 2009 6:42:41 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:42:41','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10485
;

-- Aug 2, 2009 6:42:54 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:42:54','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13700
;

-- Aug 2, 2009 6:42:59 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:42:59','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=53257
;

-- Aug 2, 2009 6:43:06 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:43:06','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=53258
;

-- Aug 2, 2009 6:43:28 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:43:28','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=12746
;

-- Aug 2, 2009 6:43:33 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:43:33','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13660
;

-- Aug 2, 2009 6:43:38 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:43:38','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13661
;

-- Aug 2, 2009 6:43:42 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:43:42','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13692
;

-- Aug 2, 2009 6:43:46 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:43:46','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13666
;

-- Aug 2, 2009 6:43:50 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:43:50','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13667
;

-- Aug 2, 2009 6:44:42 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:44:42','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=8243
;

-- Aug 2, 2009 6:44:47 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:44:47','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=8265
;

-- Aug 2, 2009 6:46:00 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:46:00','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=3323
;

-- Aug 2, 2009 6:46:06 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:46:06','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=3327
;

-- Aug 2, 2009 6:46:10 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:46:10','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=6936
;

-- Aug 2, 2009 6:46:15 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:46:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=7796
;

-- Aug 2, 2009 6:46:19 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:46:19','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=7797
;

-- Aug 2, 2009 6:46:31 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:46:31','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10486
;

-- Aug 2, 2009 6:46:36 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:46:36','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=6532
;

-- Aug 2, 2009 6:46:46 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:46:46','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=3900
;

-- Aug 2, 2009 6:47:26 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:47:26','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=12747
;

-- Aug 2, 2009 6:47:30 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:47:30','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13668
;

-- Aug 2, 2009 6:47:33 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:47:33','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13669
;

-- Aug 2, 2009 6:47:37 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:47:37','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13693
;

-- Aug 2, 2009 6:47:41 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:47:41','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13674
;

-- Aug 2, 2009 6:47:45 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:47:45','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13675
;

-- Aug 2, 2009 6:47:52 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:47:52','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=8266
;

-- Aug 2, 2009 6:47:56 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:47:56','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=8244
;

-- Aug 2, 2009 6:48:02 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:48:02','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=8267
;

-- Aug 2, 2009 6:50:23 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:50:23','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=7802
;

-- Aug 2, 2009 6:50:26 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:50:26','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=7803
;

-- Aug 2, 2009 6:50:31 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:50:31','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=7805
;

-- Aug 2, 2009 6:50:35 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:50:35','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=7801
;

-- Aug 2, 2009 6:50:39 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:50:39','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=7800
;

-- Aug 2, 2009 6:50:47 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:50:47','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10347
;

-- Aug 2, 2009 6:50:51 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:50:51','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=9236
;

-- Aug 2, 2009 6:51:02 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:51:02','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=9235
;

-- Aug 2, 2009 6:51:10 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:51:10','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10531
;

-- Aug 2, 2009 6:51:26 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:51:26','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=5146
;

-- Aug 2, 2009 6:51:47 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:51:47','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13685
;

-- Aug 2, 2009 6:51:52 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:51:52','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13683
;

-- Aug 2, 2009 6:51:56 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:51:56','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13686
;

-- Aug 2, 2009 6:52:07 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:52:07','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13687
;

-- Aug 2, 2009 6:52:12 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:52:12','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13684
;

-- Aug 2, 2009 6:52:17 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:52:17','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13695
;

-- Aug 2, 2009 6:52:22 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:52:22','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13688
;

-- Aug 2, 2009 6:52:26 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:52:26','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13689
;

-- Aug 2, 2009 6:56:27 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:56:27','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=7829
;

-- Aug 2, 2009 6:56:30 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:56:30','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=7830
;

-- Aug 2, 2009 6:56:34 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:56:34','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=7832
;

-- Aug 2, 2009 6:56:38 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:56:38','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=7828
;

-- Aug 2, 2009 6:56:41 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:56:41','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=7827
;

-- Aug 2, 2009 6:56:49 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:56:49','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10369
;

-- Aug 2, 2009 6:56:54 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:56:54','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=9463
;

-- Aug 2, 2009 6:56:59 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:56:59','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=9462
;

-- Aug 2, 2009 6:57:06 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:57:06','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10568
;

-- Aug 2, 2009 6:57:11 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 18:57:11','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=5143
;

-- Aug 2, 2009 6:57:38 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:57:38','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13678
;

-- Aug 2, 2009 6:57:41 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:57:41','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13676
;

-- Aug 2, 2009 6:57:46 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:57:46','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13679
;

-- Aug 2, 2009 6:57:50 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:57:50','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13680
;

-- Aug 2, 2009 6:57:55 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:57:55','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13677
;

-- Aug 2, 2009 6:57:59 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:57:59','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13694
;

-- Aug 2, 2009 6:58:03 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:58:03','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13681
;

-- Aug 2, 2009 6:58:08 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=104,Updated=TO_DATE('2009-08-02 18:58:08','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=13682
;

-- Aug 2, 2009 7:02:07 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 19:02:07','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10529
;

-- Aug 2, 2009 7:02:15 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 19:02:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=54055
;

-- Aug 2, 2009 7:02:19 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 19:02:19','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=9223
;

-- Aug 2, 2009 7:02:24 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 19:02:24','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=9222
;

-- Aug 2, 2009 7:02:30 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 19:02:30','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=9224
;

-- Aug 2, 2009 7:02:35 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 19:02:35','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=9221
;

-- Aug 2, 2009 7:02:40 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 19:02:40','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2727
;

-- Aug 2, 2009 7:02:46 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=101,Updated=TO_DATE('2009-08-02 19:02:46','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=5144
;

-- Aug 2, 2009 7:05:02 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=102,Updated=TO_DATE('2009-08-02 19:05:02','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=9225
;

-- Aug 2, 2009 7:05:07 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=102,Updated=TO_DATE('2009-08-02 19:05:07','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=9227
;

-- Aug 2, 2009 7:05:11 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=102,Updated=TO_DATE('2009-08-02 19:05:11','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=9226
;

-- Aug 2, 2009 7:05:15 PM EEST
-- FR-2831174 [Set proper Field Group]
UPDATE AD_Field SET AD_FieldGroup_ID=102,Updated=TO_DATE('2009-08-02 19:05:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2738
;


