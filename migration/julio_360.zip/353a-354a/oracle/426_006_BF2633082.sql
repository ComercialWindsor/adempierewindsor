-- Feb 26, 2009 9:40:56 AM EET
-- 
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53992
;

-- Feb 26, 2009 9:40:56 AM EET
-- 
UPDATE AD_Field SET SeqNo=170,IsDisplayed='Y' WHERE AD_Field_ID=53994
;

-- Feb 26, 2009 9:40:56 AM EET
-- 
UPDATE AD_Field SET SeqNo=190,IsDisplayed='Y' WHERE AD_Field_ID=53995
;

-- Feb 26, 2009 9:40:56 AM EET
-- 
UPDATE AD_Field SET SeqNo=200,IsDisplayed='Y' WHERE AD_Field_ID=53996
;

-- Feb 26, 2009 9:40:56 AM EET
-- 
UPDATE AD_Field SET SeqNo=210,IsDisplayed='Y' WHERE AD_Field_ID=53997
;

-- Feb 26, 2009 9:40:56 AM EET
-- 
UPDATE AD_Field SET SeqNo=220,IsDisplayed='Y' WHERE AD_Field_ID=53998
;

-- Feb 26, 2009 9:40:56 AM EET
-- 
UPDATE AD_Field SET SeqNo=230,IsDisplayed='Y' WHERE AD_Field_ID=53973
;

-- Feb 26, 2009 9:40:56 AM EET
-- 
UPDATE AD_Field SET SeqNo=240,IsDisplayed='Y' WHERE AD_Field_ID=53971
;

-- Feb 26, 2009 9:40:56 AM EET
-- 
UPDATE AD_Field SET SeqNo=250,IsDisplayed='Y' WHERE AD_Field_ID=53972
;

-- Feb 26, 2009 9:40:56 AM EET
-- 
UPDATE AD_Field SET SeqNo=260,IsDisplayed='Y' WHERE AD_Field_ID=53967
;

-- Feb 26, 2009 9:40:56 AM EET
-- 
UPDATE AD_Field SET SeqNo=270,IsDisplayed='Y' WHERE AD_Field_ID=53968
;

-- Feb 26, 2009 9:40:56 AM EET
-- 
UPDATE AD_Field SET SeqNo=280,IsDisplayed='Y' WHERE AD_Field_ID=53966
;

-- Feb 26, 2009 9:40:56 AM EET
-- 
UPDATE AD_Field SET SeqNo=290,IsDisplayed='Y' WHERE AD_Field_ID=54001
;

-- Feb 26, 2009 9:40:56 AM EET
-- 
UPDATE AD_Field SET SeqNo=300,IsDisplayed='Y' WHERE AD_Field_ID=53980
;

-- Feb 26, 2009 9:40:56 AM EET
-- 
UPDATE AD_Field SET SeqNo=310,IsDisplayed='Y' WHERE AD_Field_ID=53999
;

-- Feb 26, 2009 9:40:56 AM EET
-- 
UPDATE AD_Field SET SeqNo=320,IsDisplayed='Y' WHERE AD_Field_ID=53975
;

-- Feb 26, 2009 9:40:56 AM EET
-- 
UPDATE AD_Field SET SeqNo=330,IsDisplayed='Y' WHERE AD_Field_ID=54002
;

-- Feb 26, 2009 9:41:44 AM EET
-- 
UPDATE AD_Field SET IsSameLine='N', DisplayLogic=NULL,Updated=TO_DATE('2009-02-26 09:41:44','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53994
;

-- Feb 26, 2009 9:41:50 AM EET
-- 
UPDATE AD_Field SET DisplayLogic=NULL,Updated=TO_DATE('2009-02-26 09:41:50','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53993
;

