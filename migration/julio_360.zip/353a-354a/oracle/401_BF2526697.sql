-- Jan 21, 2009 1:25:48 PM COT
-- Product Substitute and Related tabs broken
UPDATE AD_Tab SET AD_Column_ID=1782,Updated=TO_DATE('2009-01-21 13:25:48','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Tab_ID=181
;

UPDATE AD_Tab SET AD_Column_ID=10857,Updated=TO_DATE('2009-01-21 13:25:51','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Tab_ID=630
;

UPDATE AD_Column SET IsParent='Y', IsUpdateable='N',Updated=TO_DATE('2009-01-21 13:27:04','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=1783
;

UPDATE AD_Column SET IsParent='Y', IsUpdateable='N',Updated=TO_DATE('2009-01-21 13:27:20','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=10852
;

UPDATE AD_Column SET IsParent='Y', IsUpdateable='N',Updated=TO_DATE('2009-01-21 13:27:28','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=10853
;

