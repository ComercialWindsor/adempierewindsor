-- 10-Jun-2009 15:20:18 BST
-- FR 2803341 - Deprecate Cash Journal
INSERT INTO AD_SysConfig (AD_Client_ID,AD_Org_ID,AD_SysConfig_ID,ConfigurationLevel,Created,CreatedBy,Description,EntityType,IsActive,Name,Updated,UpdatedBy,Value) VALUES (0,0,50028,'C',TO_DATE('2009-06-10 15:20:16','YYYY-MM-DD HH24:MI:SS'),100,'Record Cash as a Payment (True) or Cash Journal (False)','D','Y','CASH_AS_PAYMENT',TO_DATE('2009-06-10 15:20:16','YYYY-MM-DD HH24:MI:SS'),100,'Y')
;

