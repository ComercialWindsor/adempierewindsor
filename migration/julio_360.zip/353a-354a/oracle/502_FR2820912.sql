-- Jul 13, 2009 9:11:02 PM CEST
-- [2820912] Disable Import Processor
UPDATE IMP_Processor SET IsActive='N',Updated=TO_DATE('2009-07-13 21:11:01','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE IMP_Processor_ID=50000
;

-- Jul 13, 2009 9:11:05 PM CEST
-- [2820912] Disable Import Processor
UPDATE IMP_Processor SET IsActive='N',Updated=TO_DATE('2009-07-13 21:11:05','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE IMP_Processor_ID=50001
;

