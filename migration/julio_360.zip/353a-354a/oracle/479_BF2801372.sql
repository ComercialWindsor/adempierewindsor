-- Jun 6, 2009 7:13:11 AM EST
-- BF2801372 NO Data found for C_BPartner_ID=50006
DELETE FROM AD_WF_EventAudit WHERE AD_WF_EventAudit_ID=50006
;

-- Jun 6, 2009 7:13:11 AM EST
-- BF2801372 NO Data found for C_BPartner_ID=50006
DELETE FROM AD_WF_Activity WHERE AD_WF_Activity_ID=50006
;

-- Jun 6, 2009 7:13:11 AM EST
-- BF2801372 NO Data found for C_BPartner_ID=50006
DELETE FROM AD_WF_Process WHERE AD_WF_Process_ID=50006
;

