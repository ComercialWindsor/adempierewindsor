-- Aug 5, 2008 10:34:58 AM CDT
-- Manufaturing
UPDATE AD_Ref_List SET Name='Fixed Order Quantity', Value='FOQ',Updated=TO_TIMESTAMP('2008-08-05 10:34:58','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Ref_List_ID=53272
;

-- Aug 5, 2008 10:34:58 AM CDT
-- Manufaturing
UPDATE AD_Ref_List_Trl SET IsTranslated='N' WHERE AD_Ref_List_ID=53272
;

