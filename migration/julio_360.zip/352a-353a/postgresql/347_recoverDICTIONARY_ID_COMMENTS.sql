-- Dec 8, 2008 9:36:58 PM COT
UPDATE AD_SysConfig SET Value='I forgot to set the DICTIONARY_ID_COMMENTS System Configurator',Updated=TO_TIMESTAMP('2008-12-08 21:36:58','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_SysConfig_ID=50003
;

