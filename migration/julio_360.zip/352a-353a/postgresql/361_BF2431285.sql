-- Dec 15, 2008 6:21:13 PM EET
-- [ 2431285 ] Discount Schema - Wrong tab level
UPDATE AD_Tab SET TabLevel=1,Updated=TO_TIMESTAMP('2008-12-15 18:21:13','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Tab_ID=406
;