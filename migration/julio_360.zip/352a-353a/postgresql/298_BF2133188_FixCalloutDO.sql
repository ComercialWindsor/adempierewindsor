
-- Sep 27, 2008 7:46:26 PM CDT
-- Fix Call out Distribution Order
UPDATE AD_Column SET Callout='org.eevolution.model.CalloutDistributionOrder.qty',Updated=TO_TIMESTAMP('2008-09-27 19:46:26','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=53928
;

-- Sep 27, 2008 7:46:42 PM CDT
-- Fix Call out Distribution Order
UPDATE AD_Column SET Callout='org.eevolution.model.CalloutDistributionOrder.qty',Updated=TO_TIMESTAMP('2008-09-27 19:46:42','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=53954
;

-- Sep 27, 2008 7:46:44 PM CDT
-- Fix Call out Distribution Order
UPDATE AD_Column SET Callout='org.eevolution.model.CalloutDistributionOrder.qty',Updated=TO_TIMESTAMP('2008-09-27 19:46:44','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=53948
;

-- Sep 27, 2008 7:46:50 PM CDT
-- Fix Call out Distribution Order
UPDATE AD_Column SET Callout='org.eevolution.model.CalloutDistributionOrder.qty',Updated=TO_TIMESTAMP('2008-09-27 19:46:50','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=53947
;

-- Sep 27, 2008 7:46:53 PM CDT
-- Fix Call out Distribution Order
UPDATE AD_Column SET Callout=NULL,Updated=TO_TIMESTAMP('2008-09-27 19:46:53','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=53946
;

