-- Aug 21, 2008 3:09:16 PM EEST
-- 
UPDATE AD_Column SET FieldLength=255,Updated=TO_TIMESTAMP('2008-08-21 15:09:16','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Column_ID=4656
;

-- Aug 21, 2008 3:09:19 PM EEST
-- 
insert into t_alter_column values('ad_process','Classname','VARCHAR(255)',null,'NULL')
;

-- Aug 21, 2008 3:10:08 PM EEST
-- 
UPDATE AD_Column SET AD_Reference_ID=10,Updated=TO_TIMESTAMP('2008-08-21 15:10:08','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Column_ID=50182
;

