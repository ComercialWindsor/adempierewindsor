-- Aug 22, 2008 12:46:29 PM CDT
-- Distribution
UPDATE AD_Process_Para SET IsRange='N',Updated=TO_TIMESTAMP('2008-08-22 12:46:29','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Process_Para_ID=53218
;

-- Aug 22, 2008 12:46:56 PM CDT
-- Distribution
UPDATE AD_Process_Para SET DefaultValue='''Y''',Updated=TO_TIMESTAMP('2008-08-22 12:46:56','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Process_Para_ID=53219
;

-- Aug 22, 2008 12:47:18 PM CDT
-- Distribution
UPDATE AD_Process_Para SET DefaultValue='''Y''',Updated=TO_TIMESTAMP('2008-08-22 12:47:18','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Process_Para_ID=53240
;

-- Aug 22, 2008 12:56:36 PM CDT
-- Distribution
UPDATE AD_Process_Para SET IsRange='N',Updated=TO_TIMESTAMP('2008-08-22 12:56:36','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Process_Para_ID=484
;

-- Aug 22, 2008 1:00:58 PM CDT
-- Distribution
UPDATE AD_Process_Para SET DefaultValue='''Y''', DisplayLogic=NULL,Updated=TO_TIMESTAMP('2008-08-22 13:00:58','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Process_Para_ID=53241
;

-- Aug 22, 2008 1:02:08 PM CDT
-- Distribution
UPDATE AD_Process_Para SET DefaultValue='''Y''',Updated=TO_TIMESTAMP('2008-08-22 13:02:08','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Process_Para_ID=53220
;

-- Aug 22, 2008 1:02:23 PM CDT
-- Distribution
UPDATE AD_Process_Para SET DefaultValue='''Y''',Updated=TO_TIMESTAMP('2008-08-22 13:02:23','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Process_Para_ID=486
;

