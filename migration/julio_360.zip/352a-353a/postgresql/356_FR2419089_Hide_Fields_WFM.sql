-- Dec 11, 2008 9:04:56 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53302
;

-- Dec 11, 2008 9:04:56 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53301
;

-- Dec 11, 2008 9:04:56 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=140,IsDisplayed='Y' WHERE AD_Field_ID=53303
;

-- Dec 11, 2008 9:04:56 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=150,IsDisplayed='Y' WHERE AD_Field_ID=53304
;

-- Dec 11, 2008 9:06:42 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53439
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53438
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53440
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53437
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53450
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53441
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53452
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=130,IsDisplayed='Y' WHERE AD_Field_ID=53442
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=140,IsDisplayed='Y' WHERE AD_Field_ID=53443
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=150,IsDisplayed='Y' WHERE AD_Field_ID=53444
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=160,IsDisplayed='Y' WHERE AD_Field_ID=53445
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=170,IsDisplayed='Y' WHERE AD_Field_ID=53446
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=180,IsDisplayed='Y' WHERE AD_Field_ID=53447
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=190,IsDisplayed='Y' WHERE AD_Field_ID=53448
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=200,IsDisplayed='Y' WHERE AD_Field_ID=53449
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=210,IsDisplayed='Y' WHERE AD_Field_ID=53451
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=220,IsDisplayed='Y' WHERE AD_Field_ID=53453
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=230,IsDisplayed='Y' WHERE AD_Field_ID=53454
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=240,IsDisplayed='Y' WHERE AD_Field_ID=53455
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=250,IsDisplayed='Y' WHERE AD_Field_ID=53456
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=260,IsDisplayed='Y' WHERE AD_Field_ID=53457
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=270,IsDisplayed='Y' WHERE AD_Field_ID=53458
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=280,IsDisplayed='Y' WHERE AD_Field_ID=53459
;

-- Dec 11, 2008 9:06:43 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=290,IsDisplayed='Y' WHERE AD_Field_ID=53460
;

-- Dec 11, 2008 9:10:09 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53388
;

-- Dec 11, 2008 9:10:09 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53397
;

-- Dec 11, 2008 9:10:09 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53398
;

-- Dec 11, 2008 9:10:09 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53396
;

-- Dec 11, 2008 9:10:09 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53399
;

-- Dec 11, 2008 9:10:09 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53411
;

-- Dec 11, 2008 9:10:09 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53412
;

-- Dec 11, 2008 9:10:09 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53379
;

-- Dec 11, 2008 9:10:09 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53385
;

-- Dec 11, 2008 9:10:09 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53389
;

-- Dec 11, 2008 9:10:09 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53392
;

-- Dec 11, 2008 9:10:09 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53395
;

-- Dec 11, 2008 9:10:09 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53391
;

-- Dec 11, 2008 9:10:09 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53384
;

-- Dec 11, 2008 9:10:09 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53394
;

-- Dec 11, 2008 9:10:09 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53390
;

-- Dec 11, 2008 9:10:09 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53393
;

-- Dec 11, 2008 9:10:09 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53382
;

-- Dec 11, 2008 9:10:10 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53404
;

-- Dec 11, 2008 9:10:10 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=130,IsDisplayed='Y' WHERE AD_Field_ID=53380
;

-- Dec 11, 2008 9:10:10 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=140,IsDisplayed='Y' WHERE AD_Field_ID=53381
;

-- Dec 11, 2008 9:10:10 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=150,IsDisplayed='Y' WHERE AD_Field_ID=53383
;

-- Dec 11, 2008 9:10:10 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=160,IsDisplayed='Y' WHERE AD_Field_ID=53386
;

-- Dec 11, 2008 9:10:10 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=170,IsDisplayed='Y' WHERE AD_Field_ID=53387
;

-- Dec 11, 2008 9:10:10 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=180,IsDisplayed='Y' WHERE AD_Field_ID=53400
;

-- Dec 11, 2008 9:10:10 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=190,IsDisplayed='Y' WHERE AD_Field_ID=53401
;

-- Dec 11, 2008 9:10:10 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=200,IsDisplayed='Y' WHERE AD_Field_ID=53402
;

-- Dec 11, 2008 9:10:10 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=210,IsDisplayed='Y' WHERE AD_Field_ID=53403
;

-- Dec 11, 2008 9:10:10 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=220,IsDisplayed='Y' WHERE AD_Field_ID=53405
;

-- Dec 11, 2008 9:10:10 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=230,IsDisplayed='Y' WHERE AD_Field_ID=53406
;

-- Dec 11, 2008 9:10:10 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=240,IsDisplayed='Y' WHERE AD_Field_ID=53407
;

-- Dec 11, 2008 9:10:10 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=250,IsDisplayed='Y' WHERE AD_Field_ID=53408
;

-- Dec 11, 2008 9:10:10 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=260,IsDisplayed='Y' WHERE AD_Field_ID=53409
;

-- Dec 11, 2008 9:10:10 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=270,IsDisplayed='Y' WHERE AD_Field_ID=53410
;

-- Dec 11, 2008 9:25:11 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=180,IsDisplayed='Y' WHERE AD_Field_ID=53404
;

-- Dec 11, 2008 9:25:11 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=190,IsDisplayed='Y' WHERE AD_Field_ID=53400
;

-- Dec 11, 2008 9:25:11 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=200,IsDisplayed='Y' WHERE AD_Field_ID=53401
;

-- Dec 11, 2008 9:25:11 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=210,IsDisplayed='Y' WHERE AD_Field_ID=53402
;

-- Dec 11, 2008 9:25:11 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=220,IsDisplayed='Y' WHERE AD_Field_ID=53403
;

-- Dec 11, 2008 9:25:11 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=230,IsDisplayed='Y' WHERE AD_Field_ID=53405
;

-- Dec 11, 2008 9:25:11 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=240,IsDisplayed='Y' WHERE AD_Field_ID=53406
;

-- Dec 11, 2008 9:25:11 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=250,IsDisplayed='Y' WHERE AD_Field_ID=53407
;

-- Dec 11, 2008 9:25:11 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=260,IsDisplayed='Y' WHERE AD_Field_ID=53408
;

-- Dec 11, 2008 9:25:11 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=270,IsDisplayed='Y' WHERE AD_Field_ID=53409
;

-- Dec 11, 2008 9:25:11 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=280,IsDisplayed='Y' WHERE AD_Field_ID=53410
;

-- Dec 11, 2008 9:25:31 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=220,IsDisplayed='Y' WHERE AD_Field_ID=53452
;

-- Dec 11, 2008 9:25:31 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=230,IsDisplayed='Y' WHERE AD_Field_ID=53453
;

-- Dec 11, 2008 9:25:31 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=240,IsDisplayed='Y' WHERE AD_Field_ID=53454
;

-- Dec 11, 2008 9:25:31 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=250,IsDisplayed='Y' WHERE AD_Field_ID=53455
;

-- Dec 11, 2008 9:25:31 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=260,IsDisplayed='Y' WHERE AD_Field_ID=53456
;

-- Dec 11, 2008 9:25:31 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=270,IsDisplayed='Y' WHERE AD_Field_ID=53457
;

-- Dec 11, 2008 9:25:31 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=280,IsDisplayed='Y' WHERE AD_Field_ID=53458
;

-- Dec 11, 2008 9:25:31 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=290,IsDisplayed='Y' WHERE AD_Field_ID=53459
;

-- Dec 11, 2008 9:25:31 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=300,IsDisplayed='Y' WHERE AD_Field_ID=53460
;

-- Dec 11, 2008 9:43:44 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET DefaultValue='EE01',Updated=TO_TIMESTAMP('2008-12-11 09:43:44','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53423
;

-- Dec 11, 2008 9:47:59 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=0,IsDisplayed='N' WHERE AD_Field_ID=53422
;

-- Dec 11, 2008 9:47:59 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET SeqNo=90,IsDisplayed='Y' WHERE AD_Field_ID=53423
;

-- Dec 11, 2008 9:55:37 AM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET DefaultValue='M',Updated=TO_TIMESTAMP('2008-12-11 09:55:37','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=53433
;

-- Dec 11, 2008 4:51:54 PM ECT
-- Hide Fields that do not necessary for Manufacturing
UPDATE AD_Field SET DefaultValue='160', IsReadOnly='Y',Updated=TO_TIMESTAMP('2008-12-11 16:51:54','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=54001
;

