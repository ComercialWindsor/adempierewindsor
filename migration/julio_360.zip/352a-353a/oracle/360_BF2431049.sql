-- 15.12.2008 16:46:02 EET
-- 
UPDATE AD_Field SET IsMandatory='Y',Updated=TO_DATE('2008-12-15 16:46:02','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=5584
;

-- 15.12.2008 16:46:08 EET
-- 
UPDATE AD_Field SET IsMandatory='Y',Updated=TO_DATE('2008-12-15 16:46:08','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Field_ID=5579
;

