-- [ 2339528 ] Proper access level U_Web_Properties
UPDATE AD_Table SET AccessLevel='7',Updated=TO_DATE('2008-11-24 19:21:43','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Table_ID=52001
;

-- [ 2339528 ] Proper access level U_Web_Properties
UPDATE AD_Table SET AD_Window_ID=52002,Updated=TO_DATE('2008-11-24 19:31:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Table_ID=52001
;

