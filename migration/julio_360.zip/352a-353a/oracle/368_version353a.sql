UPDATE AD_SYSTEM
   SET releaseno = '353a',
       VERSION = '2008-12-21'
 WHERE ad_system_id = 0 AND ad_client_id = 0;

